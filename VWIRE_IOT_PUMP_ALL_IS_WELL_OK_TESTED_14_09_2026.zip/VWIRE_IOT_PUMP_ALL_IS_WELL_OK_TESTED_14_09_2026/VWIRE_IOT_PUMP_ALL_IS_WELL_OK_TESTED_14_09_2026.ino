/*
  ============================================================
       VWIRE 3-DEVICE PUMP CONTROLLER
       CUSTOM ESP32 CAPTIVE PORTAL
       ESP32 BOARD VERSION 2.0.3
  ============================================================

  VWire Devices:
    V0 = START       GPIO19
    V1 = STOP        GPIO21
    V2 = AUTO MODE   GPIO22

  Local:
    AUTO BUTTON     GPIO23 -> GND
    FLOAT SENSOR    GPIO27 -> GND
    BOOT BUTTON     GPIO0  -> GND
    WIFI LED        GPIO2

  Relay:
    ACTIVE LOW

  Features:
    - Custom captive portal using WebServer + DNSServer
    - Nearby WiFi scan
    - Select WiFi SSID
    - Enter WiFi password
    - No WiFi SSID/password hard-coded
    - START pulse configurable 1-5 seconds
    - STOP pulse fixed 2 seconds
    - Float STOP immediately
    - Float remains active -> STOP every 5 seconds
    - AUTO MODE saved in NVS
    - AUTO ON before power failure -> START after 60 seconds
    - AUTO power-reset timer works WITHOUT WiFi/VWire
    - BOOT button opens configuration portal
    - WiFi credentials stored in NVS
    - WiFi reconnect in background
  ============================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <Vwire.h>


// ============================================================
//                    VWIRE CREDENTIALS
// ============================================================

const char* AUTH_TOKEN = "iot_bcfyqkccPHgD22ta2CwlDbnOvmkyPgnj";
const char* DEVICE_ID  = "VU-9XNFAM";


// ============================================================
//                    PIN CONFIGURATION
// ============================================================

#define START_RELAY_PIN 19
#define STOP_RELAY_PIN  21
#define AUTO_RELAY_PIN  22

#define AUTO_BUTTON_PIN 23
#define FLOAT_PIN       27

#define LED_PIN         2
#define BOOT_BUTTON_PIN 0


// ============================================================
//                    RELAY LOGIC
// ============================================================

#define RELAY_ON  LOW
#define RELAY_OFF HIGH


// ============================================================
//                    TIMING
// ============================================================

// STOP relay fixed pulse
#define STOP_PULSE_TIME 2000UL

// AUTO start after power reset
#define AUTO_START_DELAY 60000UL

// Float repeated STOP delay
#define FLOAT_STOP_DELAY 5000UL

// Default START pulse
#define DEFAULT_START_TIME 2000UL

// Allowed START pulse range
#define MIN_START_TIME 1000UL
#define MAX_START_TIME 5000UL


// ============================================================
//                    CAPTIVE PORTAL
// ============================================================

WebServer server(80);
DNSServer dnsServer;

const byte DNS_PORT = 53;

IPAddress apIP(192, 168, 4, 1);

const char* AP_SSID = "VWire-Pump-Setup";
const char* AP_PASSWORD = "12345678";


// ============================================================
//                    NVS
// ============================================================

Preferences prefs;


// ============================================================
//                    WIFI SETTINGS
// ============================================================

String savedSSID = "";
String savedPassword = "";

bool configMode = false;

bool bootButtonPressed = false;
unsigned long bootButtonStart = 0;


// ============================================================
//                    PUMP VARIABLES
// ============================================================

bool autoMode = false;


// ============================================================
//                    START PULSE
// ============================================================

bool startPulseActive = false;
unsigned long startPulseEnd = 0;


// ============================================================
//                    STOP PULSE
// ============================================================

bool stopPulseActive = false;
unsigned long stopPulseEnd = 0;


// ============================================================
//                    START PULSE CONFIG
// ============================================================

unsigned long startPulseTime = DEFAULT_START_TIME;


// ============================================================
//                    AUTO POWER RESET
// ============================================================

bool bootAutoStartPending = false;
unsigned long bootAutoStartTime = 0;


// ============================================================
//                    FLOAT SENSOR
// ============================================================

bool floatActive = false;
unsigned long nextFloatStopTime = 0;


// ============================================================
//                    AUTO BUTTON
// ============================================================

bool lastButtonReading = HIGH;
bool buttonState = HIGH;

unsigned long lastDebounceTime = 0;

#define DEBOUNCE_TIME 50UL


// ============================================================
//                    WIFI LED
// ============================================================

unsigned long lastBlinkTime = 0;
unsigned long lastReconnectTime = 0;

bool ledState = LOW;


// ============================================================
//                    CONFIG PAGE
// ============================================================

String makePage(String message = "")
{
  String html;

  html += "<!DOCTYPE html>";
  html += "<html>";
  html += "<head>";

  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";
  html += "<meta charset='UTF-8'>";

  html += "<title>VWire Pump Setup</title>";

  html += "<style>";

  html += "body{";
  html += "font-family:Arial,sans-serif;";
  html += "background:#f2f4f7;";
  html += "margin:0;";
  html += "padding:15px;";
  html += "}";

  html += ".card{";
  html += "max-width:500px;";
  html += "margin:auto;";
  html += "background:white;";
  html += "padding:22px;";
  html += "border-radius:18px;";
  html += "box-shadow:0 4px 20px rgba(0,0,0,.12);";
  html += "}";

  html += "h1{";
  html += "text-align:center;";
  html += "margin-top:5px;";
  html += "}";

  html += ".sub{";
  html += "text-align:center;";
  html += "color:#666;";
  html += "}";

  html += "label{";
  html += "font-weight:bold;";
  html += "display:block;";
  html += "margin-top:18px;";
  html += "}";

  html += "select,input{";
  html += "width:100%;";
  html += "box-sizing:border-box;";
  html += "padding:13px;";
  html += "margin-top:7px;";
  html += "border:1px solid #ccc;";
  html += "border-radius:10px;";
  html += "font-size:16px;";
  html += "}";

  html += "button{";
  html += "width:100%;";
  html += "padding:14px;";
  html += "margin-top:15px;";
  html += "border:0;";
  html += "border-radius:10px;";
  html += "font-size:16px;";
  html += "font-weight:bold;";
  html += "cursor:pointer;";
  html += "}";

  html += ".save{";
  html += "background:#111;";
  html += "color:white;";
  html += "}";

  html += ".scan{";
  html += "background:#e7e9ed;";
  html += "color:#111;";
  html += "}";

  html += ".danger{";
  html += "background:#eee;";
  html += "color:#b00020;";
  html += "}";

  html += ".info{";
  html += "background:#eef5ff;";
  html += "padding:12px;";
  html += "border-radius:10px;";
  html += "margin-top:15px;";
  html += "}";

  html += ".success{";
  html += "background:#eaf8ed;";
  html += "padding:12px;";
  html += "border-radius:10px;";
  html += "margin-top:15px;";
  html += "}";

  html += "</style>";

  html += "</head>";
  html += "<body>";

  html += "<div class='card'>";

  html += "<h1>⚙️ VWire Pump</h1>";
  html += "<div class='sub'>WiFi & Pump Configuration</div>";

  if (message.length() > 0)
  {
    html += "<div class='success'>";
    html += message;
    html += "</div>";
  }


  // ==========================================================
  // WIFI SECTION
  // ==========================================================

  html += "<form action='/save' method='POST'>";

  html += "<label>📶 WiFi Network</label>";

  html += "<select name='ssid' id='ssid' onchange='document.getElementById(\"manualSSID\").value=this.value'>";

  html += "<option value=''>Select WiFi Network</option>";

  int n = WiFi.scanNetworks();

  if (n > 0)
  {
    for (int i = 0; i < n; i++)
    {
      String ssid = WiFi.SSID(i);

      if (ssid.length() == 0)
        continue;

      html += "<option value='";
      html += ssid;
      html += "'";

      if (ssid == savedSSID)
        html += " selected";

      html += ">";

      html += ssid;

      html += " (";
      html += String(WiFi.RSSI(i));
      html += " dBm)";

      html += "</option>";
    }
  }

  html += "</select>";

  html += "<button type='button' class='scan' onclick='location.reload()'>";
  html += "🔍 SCAN NEARBY WIFI";
  html += "</button>";

  html += "<label>✍️ Manual WiFi SSID</label>";
  html += "<input type='text' id='manualSSID' name='manualSSID' value='";
  html += savedSSID;
  html += "' placeholder='Enter WiFi SSID manually'>";
  html += "<div class='info'>If your WiFi is not shown in the nearby scan, enter the WiFi name (SSID) manually here.</div>";


  // ==========================================================
  // WIFI PASSWORD
  // ==========================================================

  html += "<label>🔐 WiFi Password</label>";

  html += "<input type='password' name='password' placeholder='Enter WiFi password'>";


  // ==========================================================
  // START TIME
  // ==========================================================

  html += "<label>⏱ START Relay Pulse Time</label>";

  html += "<select name='startTime'>";

  for (int sec = 1; sec <= 5; sec++)
  {
    unsigned long value = sec * 1000UL;

    html += "<option value='";
    html += String(value);
    html += "'";

    if (startPulseTime == value)
      html += " selected";

    html += ">";

    html += String(sec);

    html += " second";

    if (sec > 1)
      html += "s";

    html += "</option>";
  }

  html += "</select>";


  // ==========================================================
  // INFO
  // ==========================================================

  html += "<div class='info'>";

  html += "START: GPIO19<br>";
  html += "STOP: GPIO21 (fixed 2 sec)<br>";
  html += "AUTO: GPIO22<br>";
  html += "FLOAT: GPIO27<br>";
  html += "AUTO Button: GPIO23";

  html += "</div>";


  // ==========================================================
  // SAVE
  // ==========================================================

  html += "<button type='submit' class='save'>";
  html += "💾 SAVE & RESTART";
  html += "</button>";

  html += "</form>";


  // ==========================================================
  // RESET WIFI
  // ==========================================================

  html += "<form action='/reset' method='POST'>";

  html += "<button type='submit' class='danger'>";
  html += "🗑 CLEAR WIFI & RESET";
  html += "</button>";

  html += "</form>";


  html += "</div>";

  html += "</body>";
  html += "</html>";

  return html;
}


// ============================================================
//                    LOAD SETTINGS
// ============================================================

void loadWiFiSettings()
{
  prefs.begin("pump", false);

  savedSSID =
    prefs.getString("ssid", "");

  savedPassword =
    prefs.getString("pass", "");

  startPulseTime =
    prefs.getULong(
      "startTime",
      DEFAULT_START_TIME
    );


  // Safety limit

  if (
    startPulseTime < MIN_START_TIME ||
    startPulseTime > MAX_START_TIME
  )
  {
    startPulseTime = DEFAULT_START_TIME;
  }


  // Restore AUTO state

  autoMode =
    prefs.getBool("auto", false);


  Serial.println();
  Serial.println("===== SAVED SETTINGS =====");

  Serial.print("SSID: ");

  if (savedSSID.length() > 0)
    Serial.println(savedSSID);
  else
    Serial.println("(NOT SET)");

  Serial.print("START pulse: ");
  Serial.print(startPulseTime / 1000);
  Serial.println(" sec");

  Serial.print("AUTO mode: ");
  Serial.println(
    autoMode ? "ON" : "OFF"
  );

  Serial.println("==========================");
}


// ============================================================
//              ARM AUTO POWER RESET TIMER
// ============================================================

void armBootAutoStart()
{
  /*
     IMPORTANT FIX

     The AUTO timer is armed immediately after NVS is loaded.

     It does NOT wait for:
       - WiFi connection
       - VWire connection
       - VWire.run()

     Therefore AUTO operation remains local.
  */

  if (autoMode)
  {
    bootAutoStartPending = true;

    bootAutoStartTime = millis();

    Serial.println();
    Serial.println(
      "=========================================="
    );

    Serial.println(
      "AUTO MODE WAS ON BEFORE POWER RESET"
    );

    Serial.println(
      "LOCAL AUTO START TIMER ARMED"
    );

    Serial.println(
      "PUMP WILL START AFTER 60 SECONDS"
    );

    Serial.println(
      "WiFi/VWire NOT REQUIRED"
    );

    Serial.println(
      "=========================================="
    );
  }
  else
  {
    bootAutoStartPending = false;

    Serial.println();
    Serial.println(
      "AUTO MODE OFF - NO POWER RESET START"
    );
  }
}


// ============================================================
//                    START CONFIG PORTAL
// ============================================================

void startConfigPortal()
{
  configMode = true;

  Serial.println();
  Serial.println(
    "======================================"
  );

  Serial.println(
    "      VWIRE CONFIGURATION MODE"
  );

  Serial.println(
    "======================================"
  );


  WiFi.disconnect(true, true);

  delay(300);

  WiFi.mode(WIFI_AP_STA);

  WiFi.softAPConfig(
    apIP,
    apIP,
    IPAddress(255, 255, 255, 0)
  );

  WiFi.softAP(AP_SSID, AP_PASSWORD);

  delay(500);


  dnsServer.start(
    DNS_PORT,
    "*",
    apIP
  );


  // ==========================================================
  // ROOT
  // ==========================================================

  server.on(
    "/",
    HTTP_GET,
    []()
    {
      server.send(
        200,
        "text/html",
        makePage()
      );
    }
  );


  // ==========================================================
  // SAVE
  // ==========================================================

  server.on(
    "/save",
    HTTP_POST,
    []()
    {
      String selectedSSID =
        server.arg("ssid");

      String manualSSID =
        server.arg("manualSSID");

      manualSSID.trim();

      String newSSID = manualSSID;

      // Manual SSID has priority. If it is empty, use scanned SSID.
      if (newSSID.length() == 0)
        newSSID = selectedSSID;

      String newPassword =
        server.arg("password");

      String newStart =
        server.arg("startTime");


      if (newSSID.length() == 0)
      {
        server.send(
          200,
          "text/html",
          makePage(
            "⚠️ Please select a WiFi network or enter the SSID manually."
          )
        );

        return;
      }


      unsigned long newStartTime =
        newStart.toInt();


      if (
        newStartTime < MIN_START_TIME ||
        newStartTime > MAX_START_TIME
      )
      {
        newStartTime =
          DEFAULT_START_TIME;
      }


      prefs.putString(
        "ssid",
        newSSID
      );

      prefs.putString(
        "pass",
        newPassword
      );

      prefs.putULong(
        "startTime",
        newStartTime
      );


      savedSSID = newSSID;
      savedPassword = newPassword;
      startPulseTime = newStartTime;


      Serial.println();
      Serial.println(
        "WiFi configuration saved."
      );


      server.send(
        200,
        "text/html",
        "<html><body>"
        "<h2>Saved!</h2>"
        "<p>ESP32 will restart now...</p>"
        "</body></html>"
      );


      delay(1000);

      ESP.restart();
    }
  );


  // ==========================================================
  // RESET
  // ==========================================================

  server.on(
    "/reset",
    HTTP_POST,
    []()
    {
      prefs.clear();

      savedSSID = "";
      savedPassword = "";

      startPulseTime =
        DEFAULT_START_TIME;

      autoMode = false;
      bootAutoStartPending = false;


      server.send(
        200,
        "text/html",
        "<html><body>"
        "<h2>WiFi settings cleared.</h2>"
        "<p>ESP32 will restart...</p>"
        "</body></html>"
      );


      delay(1000);

      ESP.restart();
    }
  );


  // ==========================================================
  // CAPTIVE PORTAL REDIRECT
  // ==========================================================

  server.onNotFound(
    []()
    {
      server.sendHeader(
        "Location",
        "http://192.168.4.1/",
        true
      );

      server.send(
        302,
        "text/plain",
        ""
      );
    }
  );


  server.begin();


  Serial.println();
  Serial.println("AP SSID:");
  Serial.println(AP_SSID);

  Serial.println("Open:");
  Serial.println("http://192.168.4.1");

  Serial.println();
}


// ============================================================
//                    CONFIG PORTAL LOOP
// ============================================================

void configPortalLoop()
{
  // Keep the configuration page responsive.
  dnsServer.processNextRequest();
  server.handleClient();
}


// ============================================================
//                    CONNECT WIFI
// ============================================================

bool connectToSavedWiFi()
{
  if (savedSSID.length() == 0)
  {
    Serial.println(
      "No saved WiFi credentials."
    );

    return false;
  }


  Serial.println();
  Serial.println(
    "Connecting to saved WiFi..."
  );

  Serial.print("SSID: ");
  Serial.println(savedSSID);


  if (configMode)
    WiFi.mode(WIFI_AP_STA);
  else
    WiFi.mode(WIFI_STA);

  WiFi.begin(
    savedSSID.c_str(),
    savedPassword.c_str()
  );


  unsigned long startTime =
    millis();


  while (
    WiFi.status() != WL_CONNECTED &&
    millis() - startTime < 20000
  )
  {
    delay(250);

    Serial.print(".");
  }


  Serial.println();


  if (WiFi.status() == WL_CONNECTED)
  {
    Serial.println();
    Serial.println(
      "WiFi connected!"
    );

    Serial.print(
      "IP Address: "
    );

    Serial.println(
      WiFi.localIP()
    );

    return true;
  }


  Serial.println();
  Serial.println(
    "WiFi connection failed."
  );

  return false;
}


// ============================================================
//                    START PUMP
// ============================================================

void startPump()
{
  // ----------------------------------------------------------
  // SAFETY: FLOAT ACTIVE = NO START
  // ----------------------------------------------------------

  if (digitalRead(FLOAT_PIN) == LOW)
  {
    Serial.println();
    Serial.println(
      "START BLOCKED - FLOAT ACTIVE"
    );

    return;
  }


  Serial.println();
  Serial.println(
    ">>> PUMP START"
  );


  // STOP OFF

  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_OFF
  );

  stopPulseActive = false;


  // START ON

  digitalWrite(
    START_RELAY_PIN,
    RELAY_ON
  );

  startPulseActive = true;

  startPulseEnd =
    millis() + startPulseTime;


  Serial.print(
    "START relay time: "
  );

  Serial.print(
    startPulseTime / 1000
  );

  Serial.println(
    " seconds"
  );
}


// ============================================================
//                    STOP PUMP
// ============================================================

void stopPump()
{
  Serial.println();
  Serial.println(
    ">>> PUMP STOP"
  );


  // Cancel pending AUTO START

  bootAutoStartPending = false;


  // START OFF

  digitalWrite(
    START_RELAY_PIN,
    RELAY_OFF
  );

  startPulseActive = false;


  // STOP ON

  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_ON
  );

  stopPulseActive = true;

  stopPulseEnd =
    millis() + STOP_PULSE_TIME;
}


// ============================================================
//                    UPDATE PUMP PULSES
// ============================================================

void updatePumpPulses()
{
  unsigned long now =
    millis();


  // ----------------------------------------------------------
  // START PULSE
  // ----------------------------------------------------------

  if (
    startPulseActive &&
    (long)(now - startPulseEnd) >= 0
  )
  {
    digitalWrite(
      START_RELAY_PIN,
      RELAY_OFF
    );

    startPulseActive = false;

    Serial.println(
      "START relay OFF"
    );
  }


  // ----------------------------------------------------------
  // STOP PULSE
  // ----------------------------------------------------------

  if (
    stopPulseActive &&
    (long)(now - stopPulseEnd) >= 0
  )
  {
    digitalWrite(
      STOP_RELAY_PIN,
      RELAY_OFF
    );

    stopPulseActive = false;

    Serial.println(
      "STOP relay OFF"
    );
  }
}


// ============================================================
//                    AUTO MODE
// ============================================================

void setAutoMode(bool state)
{
  autoMode = state;


  // Save AUTO Mode

  prefs.putBool(
    "auto",
    autoMode
  );


  // AUTO relay / indicator

  digitalWrite(
    AUTO_RELAY_PIN,
    autoMode
      ? RELAY_ON
      : RELAY_OFF
  );


  Serial.print(
    "AUTO MODE -> "
  );

  Serial.println(
    autoMode
      ? "ON"
      : "OFF"
  );


  // Update VWire dashboard

  /*
     This is safe even if VWire is offline.
     The local AUTO state is already saved in NVS.
  */

  if (WiFi.status() == WL_CONNECTED)
  {
    Vwire.virtualSend(
      V2,
      autoMode ? 1 : 0
    );
  }


  // ----------------------------------------------------------
  // AUTO OFF = CANCEL POWER RESET START
  // ----------------------------------------------------------

  if (!autoMode)
  {
    bootAutoStartPending = false;

    Serial.println(
      "Pending AUTO START cancelled."
    );
  }
}


// ============================================================
//                    VWIRE START
// ============================================================

VWIRE_RECEIVE(V0)
{
  int value =
    param.asInt();


  Serial.print(
    "V0 START -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );


  if (value == 1)
  {
    startPump();
  }
}


// ============================================================
//                    VWIRE STOP
// ============================================================

VWIRE_RECEIVE(V1)
{
  int value =
    param.asInt();


  Serial.print(
    "V1 STOP -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );


  if (value == 1)
  {
    stopPump();
  }
}


// ============================================================
//                    VWIRE AUTO
// ============================================================

VWIRE_RECEIVE(V2)
{
  int value =
    param.asInt();


  Serial.print(
    "V2 AUTO -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );


  setAutoMode(
    value == 1
  );
}


// ============================================================
//                    VWIRE CONNECTED
// ============================================================

VWIRE_CONNECTED()
{
  Serial.println();
  Serial.println(
    "Connected to VWire!"
  );


  // Restore dashboard AUTO state

  Vwire.virtualSend(
    V2,
    autoMode ? 1 : 0
  );
}


// ============================================================
//                    VWIRE DISCONNECTED
// ============================================================

VWIRE_DISCONNECTED()
{
  Serial.println(
    "Disconnected from VWire!"
  );
}


// ============================================================
//                    LOCAL AUTO BUTTON
// ============================================================

void checkAutoButton()
{
  bool reading =
    digitalRead(
      AUTO_BUTTON_PIN
    );


  if (
    reading !=
    lastButtonReading
  )
  {
    lastDebounceTime =
      millis();
  }


  if (
    millis() - lastDebounceTime >
    DEBOUNCE_TIME
  )
  {
    if (
      reading != buttonState
    )
    {
      buttonState = reading;


      if (buttonState == LOW)
      {
        Serial.println(
          "Local AUTO button pressed"
        );


        setAutoMode(
          !autoMode
        );
      }
    }
  }


  lastButtonReading =
    reading;
}


// ============================================================
//                    FLOAT SENSOR
// ============================================================

void checkFloatSensor()
{
  bool currentFloat =
    (
      digitalRead(
        FLOAT_PIN
      ) == LOW
    );


  // ----------------------------------------------------------
  // FLOAT BECAME ACTIVE
  // ----------------------------------------------------------

  if (
    currentFloat &&
    !floatActive
  )
  {
    floatActive = true;


    Serial.println();
    Serial.println(
      "================================"
    );

    Serial.println(
      "WATER FLOAT ACTIVE"
    );

    Serial.println(
      "FLOAT -> STOP"
    );

    Serial.println(
      "================================"
    );


    // Cancel AUTO START

    bootAutoStartPending =
      false;


    // Immediate STOP

    stopPump();


    // Next STOP after 5 seconds

    nextFloatStopTime =
      millis() +
      FLOAT_STOP_DELAY;
  }


  // ----------------------------------------------------------
  // FLOAT STILL ACTIVE
  // ----------------------------------------------------------

  else if (
    currentFloat &&
    floatActive
  )
  {
    unsigned long now =
      millis();


    if (
      (long)(
        now -
        nextFloatStopTime
      ) >= 0
    )
    {
      Serial.println();
      Serial.println(
        "FLOAT STILL ACTIVE -> STOP AGAIN"
      );


      stopPump();


      nextFloatStopTime =
        now +
        FLOAT_STOP_DELAY;
    }
  }


  // ----------------------------------------------------------
  // FLOAT BECAME INACTIVE
  // ----------------------------------------------------------

  else if (
    !currentFloat &&
    floatActive
  )
  {
    floatActive = false;

    nextFloatStopTime = 0;


    Serial.println();
    Serial.println(
      "FLOAT INACTIVE"
    );

    Serial.println(
      "Float timer reset"
    );
  }
}


// ============================================================
//                 POWER RESET AUTO START
// ============================================================

void checkBootAutoStart()
{
  if (!bootAutoStartPending)
    return;


  // ----------------------------------------------------------
  // AUTO TURNED OFF
  // ----------------------------------------------------------

  if (!autoMode)
  {
    bootAutoStartPending =
      false;

    return;
  }


  // ----------------------------------------------------------
  // FLOAT ACTIVE
  // ----------------------------------------------------------

  if (
    digitalRead(FLOAT_PIN) == LOW
  )
  {
    bootAutoStartPending =
      false;


    Serial.println(
      "AUTO START cancelled - FLOAT ACTIVE"
    );

    return;
  }


  // ----------------------------------------------------------
  // CHECK 60 SECOND TIMER
  // ----------------------------------------------------------

  unsigned long elapsed =
    millis() -
    bootAutoStartTime;


  if (
    elapsed >=
    AUTO_START_DELAY
  )
  {
    bootAutoStartPending =
      false;


    Serial.println();
    Serial.println(
      "================================"
    );

    Serial.println(
      "60 SECOND DELAY COMPLETED"
    );

    Serial.println(
      "AUTO MODE = ON"
    );

    Serial.println(
      "AUTOMATIC PUMP START"
    );

    Serial.println(
      "================================"
    );


    startPump();
  }
}


// ============================================================
//                    WIFI LED
// ============================================================

void updateWiFiLED()
{
  unsigned long now =
    millis();


  if (
    WiFi.status() ==
    WL_CONNECTED
  )
  {
    digitalWrite(
      LED_PIN,
      HIGH
    );
  }
  else
  {
    if (
      now - lastBlinkTime >=
      500
    )
    {
      lastBlinkTime =
        now;


      ledState =
        !ledState;


      digitalWrite(
        LED_PIN,
        ledState
      );
    }
  }
}


// ============================================================
//                    SETUP
// ============================================================

void setup()
{
  Serial.begin(115200);

  delay(300);


  Serial.println();
  Serial.println(
    "=========================================="
  );

  Serial.println(
    " VWIRE 3 DEVICE PUMP CONTROLLER"
  );

  Serial.println(
    " CUSTOM WIFI CAPTIVE PORTAL"
  );

  Serial.println(
    " AUTO POWER RESET FIXED"
  );

  Serial.println(
    "=========================================="
  );


  // ==========================================================
  // GPIO
  // ==========================================================

  pinMode(
    LED_PIN,
    OUTPUT
  );

  pinMode(
    START_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    STOP_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    AUTO_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    AUTO_BUTTON_PIN,
    INPUT_PULLUP
  );

  pinMode(
    FLOAT_PIN,
    INPUT_PULLUP
  );

  pinMode(
    BOOT_BUTTON_PIN,
    INPUT_PULLUP
  );


  // ==========================================================
  // RELAYS OFF FIRST
  // ==========================================================

  digitalWrite(
    START_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    AUTO_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    LED_PIN,
    LOW
  );


  // ==========================================================
  // LOAD NVS
  // ==========================================================

  loadWiFiSettings();


  // ==========================================================
  // RESTORE AUTO OUTPUT
  // ==========================================================

  digitalWrite(
    AUTO_RELAY_PIN,
    autoMode
      ? RELAY_ON
      : RELAY_OFF
  );


  // ==========================================================
  // IMPORTANT FIX:
  //
  // ARM AUTO TIMER IMMEDIATELY AFTER NVS LOAD.
  //
  // DO NOT WAIT FOR WIFI.
  // ==========================================================

  armBootAutoStart();


  // ==========================================================
  // CHECK BOOT BUTTON
  // ==========================================================

  Serial.println();
  Serial.println(
    "Hold BOOT button for 3 seconds"
  );

  Serial.println(
    "to open WiFi configuration."
  );


  unsigned long bootCheckStart =
    millis();


  while (
    millis() -
    bootCheckStart <
    3500
  )
  {
    if (
      digitalRead(
        BOOT_BUTTON_PIN
      ) == LOW
    )
    {
      bootButtonPressed = true;


      Serial.println(
        "BOOT button detected..."
      );


      break;
    }


    /*
       Keep the power-reset AUTO timer
       alive even during the 3.5 sec
       BOOT button detection period.
    */

    updatePumpPulses();

    checkBootAutoStart();

    checkFloatSensor();

    delay(10);
  }


  // ==========================================================
  // CONFIG MODE
  // ==========================================================

  if (bootButtonPressed)
  {
    startConfigPortal();

    return;
  }


  // ==========================================================
  // NO WIFI SAVED
  // ==========================================================

  if (
    savedSSID.length() == 0
  )
  {
    Serial.println();
    Serial.println(
      "No WiFi saved."
    );

    /*
       Configuration portal is opened,
       but LOCAL pump AUTO logic continues
       inside configPortalLoop().
    */

    startConfigPortal();

    return;
  }


  // ==========================================================
  // CONNECT TO SAVED WIFI
  // ==========================================================

  bool wifiOK =
    connectToSavedWiFi();


  // ==========================================================
  // CONNECTION FAILED
  //
  // IMPORTANT:
  // DO NOT ENTER CONFIG PORTAL AUTOMATICALLY.
  //
  // Local pump logic must continue.
  // ==========================================================

  if (!wifiOK)
  {
    Serial.println();
    Serial.println(
      "Could not connect to saved WiFi."
    );

    Serial.println(
      "Starting WiFi configuration AP."
    );

    Serial.println(
      "AP remains available while WiFi is disconnected."
    );

    Serial.println(
      "AUTO function remains active."
    );

    startConfigPortal();
  }


  // ==========================================================
  // FLOAT AT BOOT
  // ==========================================================

  if (
    digitalRead(
      FLOAT_PIN
    ) == LOW
  )
  {
    Serial.println();
    Serial.println(
      "FLOAT ACTIVE AT BOOT"
    );


    bootAutoStartPending =
      false;


    floatActive = true;


    stopPump();


    nextFloatStopTime =
      millis() +
      FLOAT_STOP_DELAY;
  }


  // ==========================================================
  // VWIRE
  // ==========================================================

  WiFi.mode(WIFI_STA);


  Vwire.logTo(Serial);


  Vwire.config(
    AUTH_TOKEN,
    DEVICE_ID
  );


  /*
     Start VWire normally.

     If WiFi is unavailable, local pump logic
     does NOT depend on VWire.
  */

  Vwire.begin(
    savedSSID.c_str(),
    savedPassword.c_str()
  );
}


// ============================================================
//                    LOOP
// ============================================================

void loop()
{
  unsigned long now = millis();

  // ==========================================================
  // WIFI CONFIGURATION PORTAL
  //
  // The AP stays available whenever configMode is active.
  // It does NOT block local pump logic or VWire operation.
  // ==========================================================

  if (configMode)
  {
    configPortalLoop();
  }

  // ==========================================================
  // PUMP PULSES
  // ==========================================================

  updatePumpPulses();

  // ==========================================================
  // POWER RESET AUTO START
  // ==========================================================

  checkBootAutoStart();

  // ==========================================================
  // LOCAL AUTO BUTTON
  // ==========================================================

  checkAutoButton();

  // ==========================================================
  // FLOAT
  // ==========================================================

  checkFloatSensor();

  // ==========================================================
  // WIFI / VWIRE
  // ==========================================================

  if (WiFi.status() == WL_CONNECTED)
  {
    digitalWrite(LED_PIN, HIGH);
    Vwire.run();
  }
  else
  {
    // --------------------------------------------------------
    // WIFI LED BLINK
    // --------------------------------------------------------

    if (now - lastBlinkTime >= 500)
    {
      lastBlinkTime = now;
      ledState = !ledState;
      digitalWrite(LED_PIN, ledState);
    }

    // --------------------------------------------------------
    // ALWAYS KEEP CONFIGURATION AP AVAILABLE
    // WHEN STA WIFI IS NOT CONNECTED
    // --------------------------------------------------------

    if (!configMode)
    {
      Serial.println();
      Serial.println("WiFi is disconnected.");
      Serial.println("Starting WiFi configuration AP...");
      startConfigPortal();
    }

    // --------------------------------------------------------
    // WIFI RECONNECT
    // --------------------------------------------------------

    if (now - lastReconnectTime >= 10000)
    {
      lastReconnectTime = now;

      if (savedSSID.length() > 0)
      {
        Serial.println();
        Serial.println("WiFi disconnected. Reconnecting...");

        if (configMode)
          WiFi.mode(WIFI_AP_STA);
        else
          WiFi.mode(WIFI_STA);

        WiFi.begin(
          savedSSID.c_str(),
          savedPassword.c_str()
        );
      }
      else
      {
        Serial.println("No saved WiFi credentials.");
      }
    }
  }
}
