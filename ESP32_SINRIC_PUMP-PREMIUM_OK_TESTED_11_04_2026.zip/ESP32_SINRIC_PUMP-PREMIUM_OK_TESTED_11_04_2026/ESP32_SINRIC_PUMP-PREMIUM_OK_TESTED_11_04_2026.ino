/*
  PumpController_Final_Fresh_BY_VIKASH_KUMAR_11_04_2026
  --------------------------------------------------
  ESP32 BOARD VERSION...2.0.3 THIS IS ALL IN ONE IOT SINRIC PRO AND LOCAL WEBPAGE PUMP CONTROL NORMAL MOTOR AND SUMBIRSIBBLE MOTOR BOTH MOTOR SELECT BY WEBPAGE                                                  
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "4100bfe8-ea8a-464d-b268-97fb70ae2912"
#define APP_SECRET    "4090f94e-62d1-4226-93e8-bed0586df4d7-8a7015a4-76a4-4cc1-a47f-c9df04a7c7d9"
#define DEVICE_ID_1   "69d5e200a221de78792ef92e"
#define DEVICE_ID_2   "69d5e24d52800e7ce3616dcb"
#define DEVICE_ID_3   "69d5e22ca221de78792ef956"

// ------------------- Pins -------------------
#define RELAY1_PIN      19 // This is for motor start relay name in sinric app (MOTOR)
#define RELAY2_PIN      21 // This is for motor stop relay name in sinric app (PUMP OFF)
#define AUTO_MODE_LED   22 // This used for auto mode enable disable internally name in sinric app (AUTO MODE)
#define WIFI_LED_PIN    2  // for wifi indicator led
#define MANUAL_BTN_PIN  27 // this is for float sensor when water tank overfloww pump off automatically 
#define AUTO_TOGGLE_BTN 23 // this is for auto mode enable disable mannual push button to GND 
#define BOOT_BTN_PIN    0  // Boot button press for 10 second reset wifi and default local wifi page name password 

// ------------------- Constants -------------------
#define HOLD_TIME       5000
#define PULSE_TIME      2000
#define AUTO_DELAY      60000
#define DNS_PORT        53
#define WIFI_RETRY_MS   5000

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
bool bootBtnPressed = false;
bool apModeActive = false;

// Mode Tracking Logic
bool isTriggerMode = true; // TRUE = Pulse (Submersible), FALSE = Toggle (Normal)
bool r1_state = false;
bool r2_state = false;

unsigned long btnPressStart = 0;
unsigned long bootBtnStart = 0;
unsigned long lastReconnectAttempt = 0;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

int relayPulseMs = PULSE_TIME; 
int wifiScanCount = 0;

IPAddress apIP(192, 168, 4, 1);
IPAddress netMsk(255, 255, 255, 0);

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
}

void pulseRelay(int pin, int timeMs = PULSE_TIME) {
  if (isTriggerMode) {
    digitalWrite(pin, LOW);
    delay(relayPulseMs); 
    digitalWrite(pin, HIGH);
    Serial.printf("Relay %d pulsed for %d ms (Trigger Mode)\n", pin, relayPulseMs);
  } else {
    if (pin == RELAY1_PIN) {
      r1_state = !r1_state;
      digitalWrite(pin, r1_state ? LOW : HIGH);
    } else if (pin == RELAY2_PIN) {
      r2_state = !r2_state;
      digitalWrite(pin, r2_state ? LOW : HIGH);
    }
    Serial.printf("Relay %d Toggled (Toggle Mode)\n", pin);
  }
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();

  preferences.begin("settings", true);
  isTriggerMode = preferences.getBool("isTrigger", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void saveOpMode(bool trigger) {
  preferences.begin("settings", false);
  preferences.putBool("isTrigger", trigger);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false); preferences.clear(); preferences.end();
  preferences.begin("ap", false);   preferences.clear(); preferences.end();
  preferences.begin("settings", false); preferences.clear(); preferences.end();
}

void loadRelayPulseTime() {
  preferences.begin("settings", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();
  if (relayPulseMs < 1000 || relayPulseMs > 5000)
    relayPulseMs = PULSE_TIME;
}

void saveRelayPulseTime(int ms) {
  preferences.begin("settings", false);
  preferences.putInt("pulseMs", ms);
  preferences.end();
}

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Power Reset: Auto Mode is ON. Waiting 60s...");
    delay(AUTO_DELAY); 
    pulseRelay(RELAY1_PIN);
    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      if (isTriggerMode) { delay(300); sw1.sendPowerStateEvent(false); }
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) pulseRelay(RELAY1_PIN);
  else if (deviceId == DEVICE_ID_2) pulseRelay(RELAY2_PIN);
  else if (deviceId == DEVICE_ID_3) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
}

// ================= WiFi Scan =================
String escapeHTML(const String &s) {
  String r = s;
  r.replace("&","&amp;"); r.replace("<","&lt;"); r.replace(">","&gt;");
  r.replace("\"","&quot;"); r.replace("'","&#39;");
  return r;
}

void scanWiFiOnce() {
  WiFi.scanDelete();
  wifiScanCount = WiFi.scanNetworks();
}

String buildWifiOptions(String current) {
  String opt = "";
  for (int i = 0; i < wifiScanCount; i++) {
    String s = WiFi.SSID(i);
    opt += "<option value='" + escapeHTML(s) + "'";
    if (s == current) opt += " selected";
    opt += ">" + escapeHTML(s) + "</option>";
  }
  return opt;
}

// ================= CAPTIVE PORTAL HANDLERS =================
bool isCaptive() {
  if (!server.hostHeader().equals(apIP.toString()) && !server.hostHeader().endsWith(".local")) return true;
  return false;
}

void handleNotFound() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", ""); 
  } else {
    server.send(404, "text/plain", "Not Found");
  }
}

// ================= Web Page =================
void handleControlPage() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", "");
    return;
  }

  String curApName = ap_name.length() ? ap_name : DEFAULT_AP_NAME;
  String curApPass = ap_pass.length() ? ap_pass : DEFAULT_AP_PASS;
  String curWifi   = wifi_ssid;

  String html = "<!doctype html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<meta name='theme-color' content='#0f172a'><title>Pump Controller</title>";
  html += "<style>";
  html += ":root{--bg:#07111f;--panel:rgba(10,19,35,0.82);--panel-soft:rgba(15,25,45,0.72);--line:rgba(255,255,255,0.12);--text:#e8eefc;--muted:#9fb0d1;--accent:#56c2ff;--accent-2:#7c5cff;--success:#23c483;--danger:#ff6b6b;--warn:#ffbf47;--shadow:0 24px 60px rgba(0,0,0,0.35);}";
  html += "*{box-sizing:border-box;}";
  html += "body{margin:0;font-family:'Segoe UI Variable','Segoe UI',Tahoma,sans-serif;background:radial-gradient(circle at top left,#12325b 0%,#07111f 45%,#02060d 100%);color:var(--text);min-height:100vh;}";
  html += "body:before,body:after{content:'';position:fixed;border-radius:50%;filter:blur(12px);opacity:0.38;pointer-events:none;}";
  html += "body:before{width:240px;height:240px;background:#2dd4bf;top:-70px;left:-80px;}";
  html += "body:after{width:280px;height:280px;background:#8b5cf6;right:-110px;top:110px;}";
  html += ".shell{max-width:980px;margin:0 auto;padding:20px 14px 28px;position:relative;z-index:1;}";
  html += ".hero{background:linear-gradient(135deg,rgba(86,194,255,0.22),rgba(124,92,255,0.18));border:1px solid rgba(255,255,255,0.16);box-shadow:var(--shadow);border-radius:28px;padding:24px 20px 20px;overflow:hidden;position:relative;}";
  html += ".hero:before{content:'';position:absolute;inset:0;background:linear-gradient(120deg,rgba(255,255,255,0.12),transparent 45%);pointer-events:none;}";
  html += ".eyebrow{display:inline-block;padding:7px 12px;border-radius:999px;background:rgba(255,255,255,0.12);border:1px solid rgba(255,255,255,0.14);font-size:11px;letter-spacing:1.6px;font-weight:700;text-transform:uppercase;color:#dbe8ff;}";
  html += "h1{margin:14px 0 8px;font-size:30px;line-height:1.1;font-weight:800;letter-spacing:0.2px;}";
  html += ".hero p{margin:0;color:#d2ddf8;font-size:14px;line-height:1.6;max-width:620px;}";
  html += ".pill-row{display:flex;flex-wrap:wrap;gap:10px;margin-top:18px;}";
  html += ".pill{padding:10px 14px;border-radius:999px;background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.12);font-size:13px;font-weight:600;color:#eef4ff;}";
  html += ".pill.success{background:rgba(35,196,131,0.16);border-color:rgba(35,196,131,0.28);}";
  html += ".pill.warn{background:rgba(255,191,71,0.16);border-color:rgba(255,191,71,0.30);}";
  html += ".pill.info{background:rgba(86,194,255,0.16);border-color:rgba(86,194,255,0.28);}";
  html += ".grid{display:grid;grid-template-columns:1.08fr 0.92fr;gap:16px;margin-top:16px;}";
  html += ".card{background:var(--panel);backdrop-filter:blur(18px);border:1px solid var(--line);box-shadow:var(--shadow);border-radius:24px;padding:18px;}";
  html += ".card h2{margin:0 0 6px;font-size:19px;}";
  html += ".card p{margin:0 0 14px;color:var(--muted);font-size:13px;line-height:1.5;}";
  html += ".stack{display:grid;gap:12px;}";
  html += ".field-label{display:block;margin:2px 0 7px;font-size:12px;font-weight:700;letter-spacing:0.6px;text-transform:uppercase;color:#b8c7e6;}";
  html += "input,select,button{width:100%;border-radius:16px;border:1px solid rgba(255,255,255,0.10);font-size:15px;transition:transform .18s ease,box-shadow .18s ease,background .18s ease,border-color .18s ease;}";
  html += "input,select{padding:14px 15px;background:rgba(255,255,255,0.07);color:var(--text);outline:none;appearance:none;}";
  html += "input::placeholder{color:#93a6cb;}";
  html += "select{background-image:linear-gradient(45deg,transparent 50%,#c9d8f7 50%),linear-gradient(135deg,#c9d8f7 50%,transparent 50%);background-position:calc(100% - 22px) calc(50% - 3px),calc(100% - 16px) calc(50% - 3px);background-size:6px 6px,6px 6px;background-repeat:no-repeat;padding-right:40px;}";
  html += "option{color:#08111f;}";
  html += "input:focus,select:focus{border-color:rgba(86,194,255,0.58);box-shadow:0 0 0 3px rgba(86,194,255,0.14);}";
  html += ".split{display:grid;grid-template-columns:1fr 1fr;gap:12px;}";
  html += ".pass-wrap{position:relative;}";
  html += ".toggle-visibility{position:absolute;right:10px;top:50%;transform:translateY(-50%);border:none;background:rgba(255,255,255,0.08);color:#dce7ff;width:auto;padding:8px 10px;border-radius:12px;font-size:12px;font-weight:700;cursor:pointer;}";
  html += ".toggle-visibility:hover{background:rgba(255,255,255,0.16);}";
  html += ".save-btn,.action-btn{border:none;cursor:pointer;font-weight:700;letter-spacing:0.2px;}";
  html += ".save-btn{padding:15px 18px;background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff;box-shadow:0 16px 30px rgba(86,194,255,0.20);}";
  html += ".save-btn:hover,.action-btn:hover{transform:translateY(-1px);}";
  html += ".mode-card{padding:16px;border-radius:20px;background:var(--panel-soft);border:1px solid rgba(255,255,255,0.08);}";
  html += ".quick-grid{display:grid;gap:12px;}";
  html += ".action-btn{padding:16px 18px;text-align:left;color:#fff;box-shadow:0 16px 28px rgba(0,0,0,0.22);}";
  html += ".action-btn span{display:block;font-size:12px;font-weight:600;opacity:0.84;margin-top:4px;}";
  html += ".start{background:linear-gradient(135deg,#1aa36f,#2bd58f);}";
  html += ".stop{background:linear-gradient(135deg,#e14b4b,#ff7b6b);}";
  html += ".auto-on{background:linear-gradient(135deg,#1783e7,#6b7cff);}";
  html += ".auto-off{background:linear-gradient(135deg,#e0a10d,#ffcc66);color:#101623;}";
  html += ".status-panel{padding:16px;border-radius:20px;background:linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.04));border:1px solid rgba(255,255,255,0.08);}";
  html += ".status-row{display:flex;justify-content:space-between;gap:12px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.08);font-size:14px;}";
  html += ".status-row:last-child{border-bottom:none;padding-bottom:0;}";
  html += ".status-key{color:#afc0e1;}";
  html += ".status-val{font-weight:700;text-align:right;}";
  html += ".footer-note{margin-top:12px;color:#92a6cb;font-size:12px;line-height:1.5;}";
  html += "@media (max-width:760px){.shell{padding:14px 10px 20px;}.hero{padding:20px 16px 18px;}h1{font-size:26px;}.grid,.split{grid-template-columns:1fr;}.card{padding:16px;}.action-btn{text-align:center;}.action-btn span{margin-top:6px;}}";
  html += "</style>";
  html += "<script>";
  html += "function toggleField(id,btnId){var x=document.getElementById(id);var b=document.getElementById(btnId);var show=x.type==='password';x.type=show?'text':'password';b.innerHTML=show?'Hide':'Show';}";
  html += "function flashRedirect(btn,url){btn.style.opacity='0.78';btn.style.transform='scale(0.98)';setTimeout(function(){location.href=url;},160);}";
  html += "</script></head><body>";

  html += "<div class='shell'>";
  html += "<div class='hero'>";
  html += "<span class='eyebrow'>Local Premium Dashboard</span>";
  html += "<h1>Pump Controller</h1>";
  html += "<p>Fast local control for motor start and stop, WiFi setup, AP configuration, and automation mode without changing your existing backend behavior.</p>";
  html += "<div class='pill-row'>";
  html += "<div class='pill info'>Mode: " + String(isTriggerMode ? "Trigger / Submersible" : "Toggle / Normal") + "</div>";
  html += "<div class='pill " + String(autoMode ? "success" : "warn") + "'>Auto Mode: " + String(autoMode ? "Enabled" : "Disabled") + "</div>";
  html += "<div class='pill " + String(WiFi.status()==WL_CONNECTED ? "success" : "warn") + "'>WiFi: " + String(WiFi.status()==WL_CONNECTED ? "Connected" : "Not Connected") + "</div>";
  html += "</div></div>";

  html += "<div class='grid'>";
  html += "<div class='card'>";
  html += "<h2>Configuration</h2>";
  html += "<p>All existing settings remain identical. This section only refreshes the look and layout of the local page.</p>";
  html += "<div class='stack'>";
  html += "<div class='mode-card'><span class='field-label'>Operation Mode</span>";
  html += "<form action='/setMode' method='POST'>";
  html += "<select name='mode' onchange='this.form.submit()'>";
  html += "<option value='trigger'" + String(isTriggerMode ? " selected" : "") + ">Trigger Mode (Submersible Motor)</option>";
  html += "<option value='toggle'" + String(!isTriggerMode ? " selected" : "") + ">Toggle Mode (Normal Motor)</option>";
  html += "</select></form></div>";

  html += "<form action='/save' method='POST' class='stack'>";
  html += "<div><span class='field-label'>Local WiFi AP Settings</span>";
  html += "<div class='split'>";
  html += "<input name='apname' placeholder='AP Name' value='"+escapeHTML(curApName)+"'>";
  html += "<div class='pass-wrap'><input id='ap_pwd' name='apass' type='password' placeholder='AP Password' value='"+escapeHTML(curApPass)+"'><button class='toggle-visibility' type='button' id='ap_toggle' onclick=\"toggleField('ap_pwd','ap_toggle')\">Show</button></div>";
  html += "</div></div>";

  html += "<div><span class='field-label'>Home WiFi Settings</span>";
  html += "<select name='ssid_select' onchange='document.getElementById(\"ssidin\").value=this.value'><option value=''>-- Select Nearby WiFi --</option>" + buildWifiOptions(curWifi) + "</select>";
  html += "<input id='ssidin' name='ssid' placeholder='WiFi SSID' value='"+escapeHTML(curWifi)+"'>";
  html += "<div class='pass-wrap'><input id='pwd' name='pass' type='password' placeholder='WiFi Password'><button class='toggle-visibility' type='button' id='wifi_toggle' onclick=\"toggleField('pwd','wifi_toggle')\">Show</button></div></div>";

  html += "<div><span class='field-label'>Relay Pulse Time</span><select name='pulse'>";
  for (int i = 1; i <= 5; i++) {
    int ms = i * 1000;
    html += "<option value='"+String(ms)+"'";
    if (relayPulseMs == ms) html += " selected";
    html += ">"+String(i)+" Second</option>";
  }
  html += "</select></div>";
  html += "<button class='save-btn'>Save Settings (AP + WiFi)</button></form>";
  html += "</div></div>";

  html += "<div class='card'>";
  html += "<h2>Manual Quick Control</h2>";
  html += "<p>Instant button access with clearer emphasis for start, stop, and auto mode actions.</p>";

  String b1 = "START PUMP ";
  String b2 = "STOP PUMP ";

  html += "<div class='quick-grid'>";
  html += "<button class='action-btn start' onclick=\"flashRedirect(this,'/relay1')\">"+b1+"<span>Manual relay action for pump start</span></button>";
  html += "<button class='action-btn stop' onclick=\"flashRedirect(this,'/relay2')\">"+b2+"<span>Manual relay action for pump stop</span></button>";
  html += autoMode
    ? "<button class='action-btn auto-off' onclick=\"flashRedirect(this,'/auto/off')\">Disable Auto Mode<span>Turn off automatic control from local panel</span></button>"
    : "<button class='action-btn auto-on' onclick=\"flashRedirect(this,'/auto/on')\">Enable Auto Mode<span>Turn on automatic control from local panel</span></button>";
  html += "</div>";

  html += "<div class='status-panel'>";
  html += "<div class='status-row'><span class='status-key'>Auto Mode</span><span class='status-val'>"+String(autoMode?"Enabled":"Disabled")+"</span></div>";
  html += "<div class='status-row'><span class='status-key'>WiFi Status</span><span class='status-val'>"+String(WiFi.status()==WL_CONNECTED?"Connected":"Not Connected")+"</span></div>";
  html += "<div class='status-row'><span class='status-key'>Motor Logic</span><span class='status-val'>"+String(isTriggerMode?"Trigger Pulse":"Toggle Output")+"</span></div>";
  html += "<div class='status-row'><span class='status-key'>Pulse Time</span><span class='status-val'>"+String(relayPulseMs/1000)+" Sec</span></div>";
  html += "</div>";
  html += "<div class='footer-note'>Designed for cleaner readability on both mobile and desktop while preserving your saved settings, relay behavior, and all existing request handlers.</div>";
  html += "</div>";

  html += "</div></div></body></html>";
  server.send(200,"text/html",html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(isTriggerMode ? true : r1_state); 
    if (isTriggerMode) { delay(300); sw1.sendPowerStateEvent(false); }
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    // --- WEB STOP BUTTON ALWAYS SENDS OFF EVENT ---
    sw2.sendPowerStateEvent(false); 
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleSetMode() {
  if (server.hasArg("mode")) {
    isTriggerMode = (server.arg("mode") == "trigger");
    saveOpMode(isTriggerMode);
    digitalWrite(RELAY1_PIN, HIGH); digitalWrite(RELAY2_PIN, HIGH);
    r1_state = false; r2_state = false;
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOn() {
  autoMode=true;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,HIGH);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(true);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOff() {
  autoMode=false;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,LOW);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(false);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void registerWebHandlers() {
  server.on("/", handleControlPage);
  server.on("/generate_204", handleControlPage); 
  server.on("/fwlink", handleControlPage);        
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);
  server.on("/setMode", HTTP_POST, handleSetMode);
  server.on("/save", HTTP_POST, [](){
    if (server.hasArg("apname")) saveApCredentials(server.arg("apname"), server.arg("apass"));
    if (server.hasArg("ssid")) saveWifiCredentials(server.arg("ssid"), server.arg("pass"));
    if (server.hasArg("ssid_select") && server.arg("ssid_select").length()) saveWifiCredentials(server.arg("ssid_select"), server.arg("pass"));
    if (server.hasArg("pulse")) saveRelayPulseTime(server.arg("pulse").toInt());
    server.send(200,"text/html","<h2>Saved! Restarting...</h2>");
    delay(1500); ESP.restart();
  });
  server.onNotFound(handleNotFound); 
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  pinMode(AUTO_TOGGLE_BTN, INPUT_PULLUP);
  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadSavedSettings();
  loadRelayPulseTime();
  
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(apIP, apIP, netMsk);
  WiFi.softAP(ap_name.length()?ap_name.c_str():DEFAULT_AP_NAME, ap_pass.length()?ap_pass.c_str():DEFAULT_AP_PASS);
  WiFi.setSleep(false); 

  dnsServer.start(DNS_PORT, "*", apIP);
  registerWebHandlers();
  server.begin();
  apModeActive = true;

  if (wifi_ssid.length()) WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
  
  ArduinoOTA.begin();
  setupSinricPro();
  restoreAutoMode(); 
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();
  if (apModeActive) dnsServer.processNextRequest();

  if (digitalRead(AUTO_TOGGLE_BTN) == LOW) {
    autoMode = !autoMode;
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    if (WiFi.status()==WL_CONNECTED) {
      SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
      sw3.sendPowerStateEvent(autoMode);
    }
    delay(200); while(digitalRead(AUTO_TOGGLE_BTN)==LOW) delay(10);
  }

  if (digitalRead(MANUAL_BTN_PIN)==LOW) {
    if (!btnPressed) { btnPressed=true; btnPressStart=millis(); }
    else if (millis()-btnPressStart>=HOLD_TIME) {
      pulseRelay(RELAY2_PIN);
      if (WiFi.status()==WL_CONNECTED) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        // --- MANUAL BUTTON ALWAYS SENDS ON EVENT ---
        sw2.sendPowerStateEvent(true);
        if (isTriggerMode) { delay(300); sw2.sendPowerStateEvent(false); }
      }
      btnPressed=false; while(digitalRead(MANUAL_BTN_PIN)==LOW) delay(10);
    }
  } else btnPressed=false;

  if (digitalRead(BOOT_BTN_PIN)==LOW) {
    if (!bootBtnPressed) { bootBtnPressed=true; bootBtnStart=millis(); }
    else if (millis()-bootBtnStart>=HOLD_TIME) {
      clearAllCredentials(); delay(500); ESP.restart();
    }
  } else bootBtnPressed=false;

  if (WiFi.status()!=WL_CONNECTED && millis()-lastReconnectAttempt>10000) {
    if (wifi_ssid.length()) WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    lastReconnectAttempt=millis();
  }
  digitalWrite(WIFI_LED_PIN, (WiFi.status() == WL_CONNECTED) ? HIGH : LOW);
}
