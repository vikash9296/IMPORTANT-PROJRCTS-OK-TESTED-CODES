/**********************************************************************************
 * TITLE: Telegram + Manual (Switch) control 4 Relays (Captive Portal + Reset Button)

 * FEATURE: Flash Memory (Preferences) + Custom WebServer + Auto-Reconnect
 /**********************************************************************************
 * TITLE: Telegram + Manual (Switch) control 4 Relays using ESP32 with Real time feedback
 * DEVELOPER: VIKASH_KUMAR
 * FEATURE: Flash Memory (Preferences) to resume state after power cut/reset
 * * Preferences--> Aditional boards Manager URLs : 
 * https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_dev_index.json, http://arduino.esp8266.com/stable/package_esp8266com_index.json
 * * Download Board ESP32 (3.2.0) : https://github.com/espressif/arduino-esp32
 *
 * Download the libraries 
 * UniversalTelegramBot Library (1.3.0)
 * AceButton Library (1.10.1)
 * Preferences Library (Inbuilt for ESP32)
 ********************************************************************************************************************************************************************/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <AceButton.h>
#include <Preferences.h> 
#include <WebServer.h>
#include <DNSServer.h>

using namespace ace_button;

// ESP32 Dev Module V1 के लिए LED फिक्स
#define LED_BUILTIN 2 
#define BOOT_BUTTON 0 // WiFi Reset के लिए Boot Button

// Credentials Variables (Preferences से लोड होंगे)
String ssid = "";
String password = "";
const char* botToken = "8505405029:AAFYLJWiHHBRaafUUeomEzNGZRqhgt0ayIE"; 
const long chatID = 1672325307;  

WiFiClientSecure client;
UniversalTelegramBot bot(botToken, client);
Preferences preferences; 

// Captive Portal Objects
WebServer server(80);
DNSServer dnsServer;
const byte DNS_PORT = 53;

// Relay and Switch Pins
const int relayPins[4] = {23, 22, 21, 19};   // Active LOW relay pins
const int switchPins[4] = {13, 12, 14, 27};  // Latching switches pins

bool relayStates[4] = {false, false, false, false}; // Stores relay states

// टाइमर वेरिएबल्स
unsigned long lastTimeBotRan;
unsigned long lastReconnectAttempt = 0;
unsigned long lastBlinkTime = 0;
unsigned long buttonPressStartTime = 0; // Reset बटन के लिए

// AceButton setup
ButtonConfig config1; AceButton button1(&config1);
ButtonConfig config2; AceButton button2(&config2);
ButtonConfig config3; AceButton button3(&config3);
ButtonConfig config4; AceButton button4(&config4);

// Forward Declarations
void button1Handler(AceButton*, uint8_t, uint8_t);
void button2Handler(AceButton*, uint8_t, uint8_t);
void button3Handler(AceButton*, uint8_t, uint8_t);
void button4Handler(AceButton*, uint8_t, uint8_t);
void handleNewMessages(int);

// --- WiFi Config WebPage ---
void handleRoot() {
  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font-family:sans-serif;text-align:center;padding:20px;}input{width:90%;padding:10px;margin:10px 0;border-radius:5px;border:1px solid #ccc;}</style></head><body>";
  html += "<h2>WiFi Config</h2><form action='/save' method='POST'>";
  html += "SSID:<br><input type='text' name='s' placeholder='WiFi Name'><br>";
  html += "Password:<br><input type='password' name='p' placeholder='Password'><br>";
  html += "<input type='submit' value='Save Settings' style='background:#007bff;color:white;'></form></body></html>";
  server.send(200, "text/html", html);
}

void handleSave() {
  ssid = server.arg("s");
  password = server.arg("p");
  preferences.putString("ssid", ssid);
  preferences.putString("pass", password);
  server.send(200, "text/html", "Settings Saved! Restarting...");
  delay(2000);
  ESP.restart();
}

void setup() {
    Serial.begin(115200);
    pinMode(BOOT_BUTTON, INPUT_PULLUP);
    
    // Preferences शुरू करें
    preferences.begin("storage", false);

    // मेमोरी से पुरानी स्थिति लोड करें
    relayStates[0] = preferences.getBool("state1", false);
    relayStates[1] = preferences.getBool("state2", false);
    relayStates[2] = preferences.getBool("state3", false);
    relayStates[3] = preferences.getBool("state4", false);

    // WiFi Credentials लोड करें
    ssid = preferences.getString("ssid", "");
    password = preferences.getString("pass", "");

    // Initialize Relays and Resume Previous States
    for (int i = 0; i < 4; i++) {
        pinMode(relayPins[i], OUTPUT);
        digitalWrite(relayPins[i], relayStates[i] ? LOW : HIGH); 
        pinMode(switchPins[i], INPUT_PULLUP);
    }
    
    pinMode(LED_BUILTIN, OUTPUT);

    // Connect WiFi or Start Portal
    if (ssid == "") {
        WiFi.softAP("ESP32_WiFi_Config");
        dnsServer.start(DNS_PORT, "*", WiFi.softAPIP());
        server.on("/", handleRoot);
        server.on("/save", handleSave);
        server.onNotFound(handleRoot); // Redirect to portal
        server.begin();
        Serial.println("AP Mode: ESP32_WiFi_Config");
    } else {
        WiFi.mode(WIFI_STA);
        WiFi.begin(ssid.c_str(), password.c_str());
        Serial.println("Connecting to WiFi...");
    }

    client.setInsecure();

    // AceButton Handlers
    config1.setEventHandler(button1Handler); config2.setEventHandler(button2Handler);
    config3.setEventHandler(button3Handler); config4.setEventHandler(button4Handler);

    button1.init(switchPins[0]); button2.init(switchPins[1]);
    button3.init(switchPins[2]); button4.init(switchPins[3]);

    delay(200);
}

void loop() {
    // --- 10 Second WiFi Reset Logic ---
    if (digitalRead(BOOT_BUTTON) == LOW) {
        if (buttonPressStartTime == 0) buttonPressStartTime = millis();
        digitalWrite(LED_BUILTIN, HIGH); 
        if (millis() - buttonPressStartTime > 10000) {
            preferences.putString("ssid", "");
            preferences.putString("pass", "");
            Serial.println("WiFi Erased! Restarting...");
            for(int i=0; i<10; i++){ digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN)); delay(100); }
            ESP.restart();
        }
    } else { buttonPressStartTime = 0; }

    // --- Config Mode (if no WiFi saved) ---
    if (ssid == "") {
        dnsServer.processNextRequest();
        server.handleClient();
        if (millis() - lastBlinkTime > 100) { digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN)); lastBlinkTime = millis(); }
        return; 
    }

    button1.check(); button2.check(); button3.check(); button4.check();

    if (WiFi.status() == WL_CONNECTED) {
        digitalWrite(LED_BUILTIN, HIGH); 
        if (millis() > lastTimeBotRan + 1000) {
            int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
            while (numNewMessages) {
                handleNewMessages(numNewMessages);
                numNewMessages = bot.getUpdates(bot.last_message_received + 1);
            }
            lastTimeBotRan = millis();
        }
    } 
    else {
        if (millis() - lastBlinkTime > 500) { digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN)); lastBlinkTime = millis(); }
        if (millis() - lastReconnectAttempt > 10000) {
            WiFi.disconnect();
            WiFi.begin(ssid.c_str(), password.c_str());
            lastReconnectAttempt = millis();
        }
    }
}

// Telegram Message Logic (Same as Original)
void handleNewMessages(int numNewMessages) {
    for (int i = 0; i < numNewMessages; i++) {
        String chat_id = String(bot.messages[i].chat_id);
        if (chat_id.toInt() != chatID) continue; 
        String text = bot.messages[i].text;

        if (text == "/relay1_on") { relayStates[0] = true; digitalWrite(relayPins[0], LOW); preferences.putBool("state1", true); bot.sendMessage(chat_id, "Relay 1 is ON", ""); } 
        else if (text == "/relay1_off") { relayStates[0] = false; digitalWrite(relayPins[0], HIGH); preferences.putBool("state1", false); bot.sendMessage(chat_id, "Relay 1 is OFF", ""); } 
        else if (text == "/relay2_on") { relayStates[1] = true; digitalWrite(relayPins[1], LOW); preferences.putBool("state2", true); bot.sendMessage(chat_id, "Relay 2 is ON", ""); } 
        else if (text == "/relay2_off") { relayStates[1] = false; digitalWrite(relayPins[1], HIGH); preferences.putBool("state2", false); bot.sendMessage(chat_id, "Relay 2 is OFF", ""); } 
        else if (text == "/relay3_on") { relayStates[2] = true; digitalWrite(relayPins[2], LOW); preferences.putBool("state3", true); bot.sendMessage(chat_id, "Relay 3 is ON", ""); } 
        else if (text == "/relay3_off") { relayStates[2] = false; digitalWrite(relayPins[2], HIGH); preferences.putBool("state3", false); bot.sendMessage(chat_id, "Relay 3 is OFF", ""); } 
        else if (text == "/relay4_on") { relayStates[3] = true; digitalWrite(relayPins[3], LOW); preferences.putBool("state4", true); bot.sendMessage(chat_id, "Relay 4 is ON", ""); } 
        else if (text == "/relay4_off") { relayStates[3] = false; digitalWrite(relayPins[3], HIGH); preferences.putBool("state4", false); bot.sendMessage(chat_id, "Relay 4 is OFF", ""); } 
        else if (text == "/relay_state") {
            String statusMsg = "Current Relay Status:\n";
            for (int j = 0; j < 4; j++) { statusMsg += "Relay " + String(j + 1) + ": " + (relayStates[j] ? "ON\n" : "OFF\n"); }
            bot.sendMessage(chat_id, statusMsg, "");
        }
    }
}

// AceButton Handlers (Same as Original)
void button1Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) { relayStates[0] = true; digitalWrite(relayPins[0], LOW); preferences.putBool("state1", true); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 1: ON (Switch)", ""); } 
    else if (eventType == AceButton::kEventReleased) { relayStates[0] = false; digitalWrite(relayPins[0], HIGH); preferences.putBool("state1", false); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 1: OFF (Switch)", ""); }
}
void button2Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) { relayStates[1] = true; digitalWrite(relayPins[1], LOW); preferences.putBool("state2", true); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 2: ON (Switch)", ""); } 
    else if (eventType == AceButton::kEventReleased) { relayStates[1] = false; digitalWrite(relayPins[1], HIGH); preferences.putBool("state2", false); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 2: OFF (Switch)", ""); }
}
void button3Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) { relayStates[2] = true; digitalWrite(relayPins[2], LOW); preferences.putBool("state3", true); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 3: ON (Switch)", ""); } 
    else if (eventType == AceButton::kEventReleased) { relayStates[2] = false; digitalWrite(relayPins[2], HIGH); preferences.putBool("state3", false); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 3: OFF (Switch)", ""); }
}
void button4Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) { relayStates[3] = true; digitalWrite(relayPins[3], LOW); preferences.putBool("state4", true); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 4: ON (Switch)", ""); } 
    else if (eventType == AceButton::kEventReleased) { relayStates[3] = false; digitalWrite(relayPins[3], HIGH); preferences.putBool("state4", false); if (WiFi.status() == WL_CONNECTED) bot.sendMessage(String(chatID), "Relay 4: OFF (Switch)", ""); }
}