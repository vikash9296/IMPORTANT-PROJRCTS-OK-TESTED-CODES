/*
  PumpController_Final_Fresh_BY_VIKASH_KUMAR_01_01_2026
  --------------------------------------------------
  ESP32 BOARD VERSION...2.0.3 THIS IS ALL IN ONE IOT SINRIC PRO AND LOCAL WEBPAGE PUMP CONTROL NORMAL MOTOR AND SUMBIRSIBBLE MOTOR BOTH MOTOR SELECT BY WEBPAGE                                                  
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "4100bfe8-ea8a-464d-b268-97fb70ae2912"
#define APP_SECRET    "4090f94e-62d1-4226-93e8-bed0586df4d7-8a7015a4-76a4-4cc1-a47f-c9df04a7c7d9"
#define DEVICE_ID_1   "69d5e200a221de78792ef92e"
#define DEVICE_ID_2   "69d5e24d52800e7ce3616dcb"
#define DEVICE_ID_3   "69d5e22ca221de78792ef956"

// ------------------- Pins -------------------
#define RELAY1_PIN      19 // This is for motor start relay name in sinric app (MOTOR)
#define RELAY2_PIN      21 // This is for motor stop relay name in sinric app (PUMP OFF)
#define AUTO_MODE_LED   22 // This used for auto mode enable disable internally name in sinric app (AUTO MODE)
#define WIFI_LED_PIN    2  // for wifi indicator led
#define MANUAL_BTN_PIN  27 // this is for float sensor when water tank overfloww pump off automatically 
#define AUTO_TOGGLE_BTN 23 // this is for auto mode enable disable mannual push button to GND 
#define BOOT_BTN_PIN    0  // Boot button press for 10 second reset wifi and default local wifi page name password 

// ------------------- Constants -------------------
#define HOLD_TIME       5000
#define PULSE_TIME      2000
#define AUTO_DELAY      60000
#define DNS_PORT        53
#define WIFI_RETRY_MS   5000

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
bool bootBtnPressed = false;
bool apModeActive = false;

// Mode Tracking Logic
bool isTriggerMode = true; // TRUE = Pulse (Submersible), FALSE = Toggle (Normal)
bool r1_state = false;
bool r2_state = false;

unsigned long btnPressStart = 0;
unsigned long bootBtnStart = 0;
unsigned long lastReconnectAttempt = 0;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

int relayPulseMs = PULSE_TIME; 
int wifiScanCount = 0;

IPAddress apIP(192, 168, 4, 1);
IPAddress netMsk(255, 255, 255, 0);

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
}

void pulseRelay(int pin, int timeMs = PULSE_TIME) {
  if (isTriggerMode) {
    digitalWrite(pin, LOW);
    delay(relayPulseMs); 
    digitalWrite(pin, HIGH);
    Serial.printf("Relay %d pulsed for %d ms (Trigger Mode)\n", pin, relayPulseMs);
  } else {
    if (pin == RELAY1_PIN) {
      r1_state = !r1_state;
      digitalWrite(pin, r1_state ? LOW : HIGH);
    } else if (pin == RELAY2_PIN) {
      r2_state = !r2_state;
      digitalWrite(pin, r2_state ? LOW : HIGH);
    }
    Serial.printf("Relay %d Toggled (Toggle Mode)\n", pin);
  }
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();

  preferences.begin("settings", true);
  isTriggerMode = preferences.getBool("isTrigger", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void saveOpMode(bool trigger) {
  preferences.begin("settings", false);
  preferences.putBool("isTrigger", trigger);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false); preferences.clear(); preferences.end();
  preferences.begin("ap", false);   preferences.clear(); preferences.end();
  preferences.begin("settings", false); preferences.clear(); preferences.end();
}

void loadRelayPulseTime() {
  preferences.begin("settings", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();
  if (relayPulseMs < 1000 || relayPulseMs > 5000)
    relayPulseMs = PULSE_TIME;
}

void saveRelayPulseTime(int ms) {
  preferences.begin("settings", false);
  preferences.putInt("pulseMs", ms);
  preferences.end();
}

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Power Reset: Auto Mode is ON. Waiting 60s...");
    delay(AUTO_DELAY); 
    pulseRelay(RELAY1_PIN);
    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      if (isTriggerMode) { delay(300); sw1.sendPowerStateEvent(false); }
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) pulseRelay(RELAY1_PIN);
  else if (deviceId == DEVICE_ID_2) pulseRelay(RELAY2_PIN);
  else if (deviceId == DEVICE_ID_3) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
}

// ================= WiFi Scan =================
String escapeHTML(const String &s) {
  String r = s;
  r.replace("&","&amp;"); r.replace("<","&lt;"); r.replace(">","&gt;");
  r.replace("\"","&quot;"); r.replace("'","&#39;");
  return r;
}

void scanWiFiOnce() {
  WiFi.scanDelete();
  wifiScanCount = WiFi.scanNetworks();
}

String buildWifiOptions(String current) {
  String opt = "";
  for (int i = 0; i < wifiScanCount; i++) {
    String s = WiFi.SSID(i);
    opt += "<option value='" + escapeHTML(s) + "'";
    if (s == current) opt += " selected";
    opt += ">" + escapeHTML(s) + "</option>";
  }
  return opt;
}

// ================= CAPTIVE PORTAL HANDLERS =================
bool isCaptive() {
  if (!server.hostHeader().equals(apIP.toString()) && !server.hostHeader().endsWith(".local")) return true;
  return false;
}

void handleNotFound() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", ""); 
  } else {
    server.send(404, "text/plain", "Not Found");
  }
}

// ================= Web Page =================
void handleControlPage() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", "");
    return;
  }

  String curApName = ap_name.length() ? ap_name : DEFAULT_AP_NAME;
  String curApPass = ap_pass.length() ? ap_pass : DEFAULT_AP_PASS;
  String curWifi   = wifi_ssid;

  String html = "<!doctype html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>";
  html += "body{font-family:'Segoe UI',Arial,sans-serif;text-align:center;background:#f0f4f8;margin:0;padding:15px;color:#333;}";
  html += ".container{max-width:400px;margin:auto;background:white;padding:25px;border-radius:20px;box-shadow:0 10px 25px rgba(0,0,0,0.1);}";
  html += "h1{color:#1a73e8;font-size:24px;margin-bottom:20px;}";
  html += "h3{font-size:16px;color:#5f6368;margin-top:20px;border-bottom:1px solid #eee;padding-bottom:8px;}";
  html += "button,input,select{padding:14px;margin:8px 0;width:100%;font-size:16px;border:1px solid #ddd;border-radius:12px;box-sizing:border-box;transition:0.3s;}";
  html += "button{border:none;cursor:pointer;font-weight:600;}";
  html += "button:active{transform:scale(0.98);}";
  html += ".btn-save{background:#1a73e8;color:white;}";
  html += ".btn-start{background:#34a853;color:white;}";
  html += ".btn-stop{background:#ea4335;color:white;}";
  html += ".btn-auto{background:#fbbc04;color:black;}";
  html += ".pass-wrapper{position:relative;width:100%;}";
  html += ".eye-toggle{position:absolute;right:15px;top:22px;cursor:pointer;color:#1a73e8;font-size:18px;}";
  html += ".status-info{background:#e8f0fe;padding:10px;border-radius:10px;margin-top:15px;font-size:14px;}";
  html += "</style>";
  html += "<script>";
  html += "function togglePass(){var x=document.getElementById('pwd');var e=document.getElementById('eye');if(x.type==='password'){x.type='text';e.innerHTML='&#128064;';}else{x.type='password';e.innerHTML='&#128065;';}}";
  html += "function flashRedirect(btn, url){btn.style.opacity='0.5';setTimeout(function(){location.href=url;},150);}";
  html += "</script></head><body>";

  html += "<div class='container'><h1>Pump Controller</h1>";

  html += "<h3>Operation Mode</h3>";
  html += "<form action='/setMode' method='POST'>";
  html += "<select name='mode' onchange='this.form.submit()'>";
  html += "<option value='trigger'" + String(isTriggerMode ? " selected" : "") + ">Trigger Mode (Submersible)</option>";
  html += "<option value='toggle'" + String(!isTriggerMode ? " selected" : "") + ">Toggle Mode (Normal Motor)</option>";
  html += "</select></form>";

  html += "<h3>Local Wifi AP Settings</h3>";
  html += "<form action='/save' method='POST'>";
  html += "<input name='apname' placeholder='AP Name' value='"+escapeHTML(curApName)+"'>";
  html += "<input name='apass' placeholder='AP Password' value='"+escapeHTML(curApPass)+"'>";

  html += "<h3>Home WiFi Settings</h3>";
  html += "<select name='ssid_select' onchange='document.getElementById(\"ssidin\").value=this.value'><option value=''>-- Select Nearby WiFi --</option>" + buildWifiOptions(curWifi) + "</select>";
  html += "<input id='ssidin' name='ssid' placeholder='WiFi SSID' value='"+escapeHTML(curWifi)+"'>";
  
  // Password with View/Hide Toggle
  html += "<div class='pass-wrapper'><input id='pwd' name='pass' type='password' placeholder='WiFi Password'><span id='eye' class='eye-toggle' onclick='togglePass()'>&#128065;</span></div>";

  html += "<h3>Relay Pulse Time</h3><select name='pulse'>";
  for (int i = 1; i <= 5; i++) {
    int ms = i * 1000;
    html += "<option value='"+String(ms)+"'";
    if (relayPulseMs == ms) html += " selected";
    html += ">"+String(i)+" Second</option>";
  }
  html += "</select>";
  html += "<button class='btn-save'>Save Settings (AP + WiFi)</button></form><hr>";

  html += "<h3>Manual Quick Control</h3>";
  
  String b1 = "START PUMP (D19)";
  String b2 = "STOP PUMP (D21)";

  html += "<button class='btn-start' onclick=\"flashRedirect(this,'/relay1')\">"+b1+"</button>";
  html += "<button class='btn-stop' onclick=\"flashRedirect(this,'/relay2')\">"+b2+"</button>";

  html += autoMode ? "<button class='btn-auto' onclick=\"flashRedirect(this,'/auto/off')\">Disable Auto Mode</button>"
                   : "<button class='btn-auto' style='background:#1a73e8;color:white;' onclick=\"flashRedirect(this,'/auto/on')\">Enable Auto Mode</button>";

  html += "<div class='status-info'><b>Auto Mode:</b> "+String(autoMode?"Enabled":"Disabled")+"<br>";
  html += "<b>WiFi:</b> "+String(WiFi.status()==WL_CONNECTED?"Connected":"Not Connected")+"</div>";
  html += "</div></body></html>";
  server.send(200,"text/html",html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(isTriggerMode ? true : r1_state); 
    if (isTriggerMode) { delay(300); sw1.sendPowerStateEvent(false); }
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    // --- WEB STOP BUTTON ALWAYS SENDS OFF EVENT ---
    sw2.sendPowerStateEvent(false); 
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleSetMode() {
  if (server.hasArg("mode")) {
    isTriggerMode = (server.arg("mode") == "trigger");
    saveOpMode(isTriggerMode);
    digitalWrite(RELAY1_PIN, HIGH); digitalWrite(RELAY2_PIN, HIGH);
    r1_state = false; r2_state = false;
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOn() {
  autoMode=true;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,HIGH);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(true);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void handleAutoOff() {
  autoMode=false;
  preferences.begin("settings",false);
  preferences.putBool("autoMode",false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED,LOW);
  if (WiFi.status()==WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(false);
  }
  server.sendHeader("Location","/",true);
  server.send(302,"");
}

void registerWebHandlers() {
  server.on("/", handleControlPage);
  server.on("/generate_204", handleControlPage); 
  server.on("/fwlink", handleControlPage);        
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);
  server.on("/setMode", HTTP_POST, handleSetMode);
  server.on("/save", HTTP_POST, [](){
    if (server.hasArg("apname")) saveApCredentials(server.arg("apname"), server.arg("apass"));
    if (server.hasArg("ssid")) saveWifiCredentials(server.arg("ssid"), server.arg("pass"));
    if (server.hasArg("ssid_select") && server.arg("ssid_select").length()) saveWifiCredentials(server.arg("ssid_select"), server.arg("pass"));
    if (server.hasArg("pulse")) saveRelayPulseTime(server.arg("pulse").toInt());
    server.send(200,"text/html","<h2>Saved! Restarting...</h2>");
    delay(1500); ESP.restart();
  });
  server.onNotFound(handleNotFound); 
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  pinMode(AUTO_TOGGLE_BTN, INPUT_PULLUP);
  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadSavedSettings();
  loadRelayPulseTime();
  
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(apIP, apIP, netMsk);
  WiFi.softAP(ap_name.length()?ap_name.c_str():DEFAULT_AP_NAME, ap_pass.length()?ap_pass.c_str():DEFAULT_AP_PASS);
  WiFi.setSleep(false); 

  dnsServer.start(DNS_PORT, "*", apIP);
  registerWebHandlers();
  server.begin();
  apModeActive = true;

  if (wifi_ssid.length()) WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
  
  ArduinoOTA.begin();
  setupSinricPro();
  restoreAutoMode(); 
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();
  if (apModeActive) dnsServer.processNextRequest();

  if (digitalRead(AUTO_TOGGLE_BTN) == LOW) {
    autoMode = !autoMode;
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    if (WiFi.status()==WL_CONNECTED) {
      SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
      sw3.sendPowerStateEvent(autoMode);
    }
    delay(200); while(digitalRead(AUTO_TOGGLE_BTN)==LOW) delay(10);
  }

  if (digitalRead(MANUAL_BTN_PIN)==LOW) {
    if (!btnPressed) { btnPressed=true; btnPressStart=millis(); }
    else if (millis()-btnPressStart>=HOLD_TIME) {
      pulseRelay(RELAY2_PIN);
      if (WiFi.status()==WL_CONNECTED) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        // --- MANUAL BUTTON ALWAYS SENDS ON EVENT ---
        sw2.sendPowerStateEvent(true);
        if (isTriggerMode) { delay(300); sw2.sendPowerStateEvent(false); }
      }
      btnPressed=false; while(digitalRead(MANUAL_BTN_PIN)==LOW) delay(10);
    }
  } else btnPressed=false;

  if (digitalRead(BOOT_BTN_PIN)==LOW) {
    if (!bootBtnPressed) { bootBtnPressed=true; bootBtnStart=millis(); }
    else if (millis()-bootBtnStart>=HOLD_TIME) {
      clearAllCredentials(); delay(500); ESP.restart();
    }
  } else bootBtnPressed=false;

  if (WiFi.status()!=WL_CONNECTED && millis()-lastReconnectAttempt>10000) {
    if (wifi_ssid.length()) WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    lastReconnectAttempt=millis();
  }
  digitalWrite(WIFI_LED_PIN, (WiFi.status() == WL_CONNECTED) ? HIGH : LOW);
}