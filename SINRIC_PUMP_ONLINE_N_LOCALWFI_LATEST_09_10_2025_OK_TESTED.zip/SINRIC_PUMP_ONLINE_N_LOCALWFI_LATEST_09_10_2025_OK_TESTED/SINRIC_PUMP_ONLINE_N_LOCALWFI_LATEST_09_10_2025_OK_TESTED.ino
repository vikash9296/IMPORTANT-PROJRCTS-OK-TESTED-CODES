// ================== Libraries ==================
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "c7303938-59fa-4ad2-a3de-e62d9bae9cec"
#define APP_SECRET    "c41c8855-b93b-496c-bf27-43f0f72c2dc8-4e754444-82cd-4acb-bb2c-c9cfe22b9b13"
#define DEVICE_ID_1   "6889cacbedeca866fe96e2ee"
#define DEVICE_ID_2   "6889caffddd2551252ba8a70"
#define DEVICE_3_ID   "6890c55fedeca866fe994705"

// ------------------- Pins -------------------
#define RELAY1_PIN     19
#define RELAY2_PIN     21
#define AUTO_MODE_LED  22
#define WIFI_LED_PIN   2
#define MANUAL_BTN_PIN 27

// ------------------- Constants -------------------
#define HOLD_TIME      5000    // 5 sec hold for manual button
#define PULSE_TIME     2000    // 2 sec relay pulse
#define AUTO_DELAY     40000   // 40 sec auto mode delay
#define DNS_PORT       53

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
unsigned long btnPressStart = 0;
unsigned long lastReconnectAttempt = 0;
unsigned long reconnectInterval = 10000;
bool apModeActive = false;

String ssid, password;

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH); // OFF (active-low)
}

void pulseRelay(int pin, int time = PULSE_TIME) {
  digitalWrite(pin, LOW);
  delay(time);
  digitalWrite(pin, HIGH);
  Serial.printf("Relay %d pulsed for %d ms\n", pin, time);
}

// ================= Preferences =================
void restoreAutoMode() {
  preferences.begin("settings", false);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Auto Mode ON → Waiting 40s, then triggering Relay1...");
    delay(AUTO_DELAY);
    pulseRelay(RELAY1_PIN);
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) pulseRelay(RELAY1_PIN);
  else if (deviceId == DEVICE_ID_2) pulseRelay(RELAY2_PIN);
  else if (deviceId == DEVICE_3_ID) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    Serial.printf("Auto Mode %s\n", autoMode ? "Enabled" : "Disabled");
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_3_ID];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
  Serial.println("SinricPro connected.");
}

// ================= Web Page =================
void handleControlPage() {
  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>body{font-family:Arial;text-align:center;background:#eef2ff;}button,input{padding:14px;margin:8px;width:80%;font-size:18px;border:none;border-radius:10px;}h1{color:#002b80;}</style>";
  html += "</head><body><h1>Pump Controller</h1><h3>WiFi Setup</h3>";
  html += "<form action='/save' method='POST'>";
  html += "<input name='ssid' placeholder='WiFi SSID'><br>";
  html += "<input name='pass' type='password' placeholder='WiFi Password'><br>";
  html += "<button style='background:#007BFF;color:white;'>Save WiFi</button></form><hr>";
  html += "<h3>Manual Local Wifi Control</h3>";
  html += "<button style='background:#4CAF50;color:white;' onclick=\"location.href='/relay1'\">Start Pump</button><br>";
  html += "<button style='background:#f44336;color:white;' onclick=\"location.href='/relay2'\">Stop Pump</button><br>";
  html += autoMode ? "<button style='background:#2196F3;color:white;' onclick=\"location.href='/auto/off'\">Disable Auto Mode</button>"
                   : "<button style='background:#2196F3;color:white;' onclick=\"location.href='/auto/on'\">Enable Auto Mode</button>";
  html += "<p><b>Auto Mode:</b> " + String(autoMode ? "Enabled" : "Disabled") + "</p>";
  html += "<p>WiFi: " + String(WiFi.status() == WL_CONNECTED ? "Connected" : "AP Mode") + "</p>";
  html += "</body></html>";
  server.send(200, "text/html", html);
}

void handleRelay1() { pulseRelay(RELAY1_PIN); server.sendHeader("Location", "/", true); server.send(302, ""); }
void handleRelay2() { pulseRelay(RELAY2_PIN); server.sendHeader("Location", "/", true); server.send(302, ""); }
void handleAutoOn()  { autoMode = true; preferences.begin("settings", false); preferences.putBool("autoMode", true); preferences.end(); digitalWrite(AUTO_MODE_LED, HIGH); server.sendHeader("Location", "/", true); server.send(302, ""); }
void handleAutoOff() { autoMode = false; preferences.begin("settings", false); preferences.putBool("autoMode", false); preferences.end(); digitalWrite(AUTO_MODE_LED, LOW); server.sendHeader("Location", "/", true); server.send(302, ""); }

void registerWebHandlers() {
  // Captive portal triggers (Android, iOS, Windows)
  server.on("/generate_204", []() { handleControlPage(); });
  server.on("/hotspot-detect.html", []() { handleControlPage(); });
  server.on("/connecttest.txt", []() { handleControlPage(); });

  // Normal control routes
  server.on("/", handleControlPage);
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);

  server.on("/save", HTTP_POST, []() {
    if (server.hasArg("ssid") && server.hasArg("pass")) {
      ssid = server.arg("ssid");
      password = server.arg("pass");
      preferences.begin("wifi", false);
      preferences.putString("ssid", ssid);
      preferences.putString("pass", password);
      preferences.end();
      server.send(200, "text/html", "<h2 style='color:blue;'>Saved! Restarting...</h2>");
      delay(2000);
      ESP.restart();
    } else {
      server.send(400, "text/html", "<h2 style='color:red;'>Missing SSID or Password!</h2>");
    }
  });

  // Redirect all unknown paths to main page
  server.onNotFound([]() {
    String hostHeader = server.hostHeader();
    if (!isIp(hostHeader)) {
      server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString(), true);
      server.send(302, "text/plain", "");
      return;
    }
    handleControlPage();
  });
}

// ================= AP Mode =================
// Modified: AP will be started in STA+AP mode so AP stays ON even after connecting to router
void startAPMode() {
  // Use AP+STA mode to keep local AP active while also allowing station (router) connection
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP("PumpController_AP", "12345678");
  IPAddress IP = WiFi.softAPIP();
  dnsServer.start(DNS_PORT, "*", IP);
  registerWebHandlers();
  server.begin();
  apModeActive = true;                 // AP is active and should be processed in loop
  digitalWrite(WIFI_LED_PIN, LOW);
  Serial.println("⚙️ Captive portal started at: " + IP.toString());
}

// ================= WiFi Handling =================
void WiFiEvent(WiFiEvent_t event) {
  switch (event) {
    case SYSTEM_EVENT_STA_CONNECTED:
      Serial.println("Connected to WiFi!");
      break;
    case SYSTEM_EVENT_STA_GOT_IP:
      Serial.print("Got IP: ");
      Serial.println(WiFi.localIP());
      digitalWrite(WIFI_LED_PIN, HIGH);
      // NOTE: do NOT disable apModeActive here — local AP stays ON always
      break;
    case SYSTEM_EVENT_STA_DISCONNECTED:
      Serial.println("WiFi disconnected!");
      digitalWrite(WIFI_LED_PIN, LOW);
      WiFi.reconnect();
      break;
    default:
      break;
  }
}

// ================= WiFi Connect =================
void connectToWiFi() {
  preferences.begin("wifi", false);
  ssid = preferences.getString("ssid", "");
  password = preferences.getString("pass", "");
  preferences.end();

  // Always start AP + STA so local AP remains available
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP("PumpController_AP", "12345678");
  IPAddress IP = WiFi.softAPIP();
  dnsServer.start(DNS_PORT, "*", IP);

  // register handlers & start server regardless so portal always accessible
  registerWebHandlers();
  server.begin();

  if (ssid != "" && password != "") {
    WiFi.onEvent(WiFiEvent);
    Serial.printf("Connecting to %s ...\n", ssid.c_str());
    WiFi.begin(ssid.c_str(), password.c_str());

    unsigned long startAttemptTime = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - startAttemptTime < 10000) {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("Wi-Fi connected!");
    // keep AP active (do not stop it)
    apModeActive = true; // keep processing dnsServer requests so captive portal works
  } else {
    Serial.println("Wi-Fi failed. AP (captve portal) remains active.");
    apModeActive = true;
  }
}

// ================= OTA =================
void setupOTA() {
  ArduinoOTA.setHostname("PumpController_OTA");
  ArduinoOTA.begin();
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  digitalWrite(WIFI_LED_PIN, LOW);
  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);

  restoreAutoMode();
  connectToWiFi();
  WiFi.setAutoReconnect(true);

  setupOTA();
  setupSinricPro();
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();
  if (apModeActive) dnsServer.processNextRequest();

  // Manual button long-press (Stop Pump)
  if (digitalRead(MANUAL_BTN_PIN) == LOW) {
    if (!btnPressed) {
      btnPressed = true;
      btnPressStart = millis();
    } else if (millis() - btnPressStart >= HOLD_TIME) {
      Serial.println("Manual button held 5s → Trigger Relay2 (Stop)");
      pulseRelay(RELAY2_PIN);
      if (WiFi.status() == WL_CONNECTED) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        sw2.sendPowerStateEvent(true);
        delay(300);
        sw2.sendPowerStateEvent(false);
      }
      btnPressed = false;
      while (digitalRead(MANUAL_BTN_PIN) == LOW) delay(10);
    }
  } else btnPressed = false;

  // Reconnect logic
  if (WiFi.status() != WL_CONNECTED && !apModeActive && millis() - lastReconnectAttempt > reconnectInterval) {
    Serial.println("WiFi lost, retrying...");
    WiFi.reconnect();
    lastReconnectAttempt = millis();
  }

  // SinricPro reconnect
  if (WiFi.status() == WL_CONNECTED && !SinricPro.isConnected() && millis() - lastReconnectAttempt > reconnectInterval) {
    Serial.println("Reconnecting SinricPro...");
    SinricPro.begin(APP_KEY, APP_SECRET);
    lastReconnectAttempt = millis();
  }
}
