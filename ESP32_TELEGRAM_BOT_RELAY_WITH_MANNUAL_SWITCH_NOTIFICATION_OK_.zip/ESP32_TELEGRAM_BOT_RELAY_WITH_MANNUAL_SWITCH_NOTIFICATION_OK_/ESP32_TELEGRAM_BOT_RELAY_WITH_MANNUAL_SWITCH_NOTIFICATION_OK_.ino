/**********************************************************************************
 * TITLE: Telegram + Manual (Switch) control 4 Relays using ESP32 with Real time feedback
 * DEVELOPER: VIKASH_KUMAR
 * * Preferences--> Aditional boards Manager URLs : 
 * https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_dev_index.json, http://arduino.esp8266.com/stable/package_esp8266com_index.json
 * * Download Board ESP32 (3.2.0) : https://github.com/espressif/arduino-esp32
 *
 * Download the libraries 
 * UniversalTelegramBot Library (1.3.0):  https://github.com/witnessmenow/Universal-Arduino-Telegram-Bot
 * AceButton Library (1.10.1): https://github.com/bxparks/AceButton
 **********************************************************************************/

#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <UniversalTelegramBot.h>
#include <AceButton.h>

using namespace ace_button;

// ESP32 Dev Module V1 के लिए LED फिक्स
#define LED_BUILTIN 2 

// Wi-Fi and Telegram Credentials
const char* ssid = "ElectroConnect";  // WiFi Name
const char* password = "vikash9296";  // WiFi Password
const char* botToken = "8505405029:AAFYLJWiHHBRaafUUeomEzNGZRqhgt0ayIE"; 
const long chatID = 1672325307;  

WiFiClientSecure client;
UniversalTelegramBot bot(botToken, client);

// Relay and Switch Pins
const int relayPins[4] = {23, 22, 21, 19};   // Active LOW relay pins
const int switchPins[4] = {13, 12, 14, 27};  // Latching switches pins

bool relayStates[4] = {false, false, false, false}; // Stores relay states

// टाइमर वेरिएबल्स (WiFi और Bot के लिए)
unsigned long lastTimeBotRan;
unsigned long lastReconnectAttempt = 0;
unsigned long lastBlinkTime = 0;

// AceButton setup
ButtonConfig config1;
AceButton button1(&config1);
ButtonConfig config2;
AceButton button2(&config2);
ButtonConfig config3;
AceButton button3(&config3);
ButtonConfig config4;
AceButton button4(&config4);

// Forward Declarations (Functions)
void button1Handler(AceButton*, uint8_t, uint8_t);
void button2Handler(AceButton*, uint8_t, uint8_t);
void button3Handler(AceButton*, uint8_t, uint8_t);
void button4Handler(AceButton*, uint8_t, uint8_t);

void handleNewMessages(int);

void setup() {
    Serial.begin(115200);
    
    // Initialize Relays (Active LOW)
    for (int i = 0; i < 4; i++) {
        pinMode(relayPins[i], OUTPUT);
        digitalWrite(relayPins[i], HIGH); // Ensure relays are off at startup
        pinMode(switchPins[i], INPUT_PULLUP);
    }
    
    pinMode(LED_BUILTIN, OUTPUT); // LED setup

    // Connect to Wi-Fi
    WiFi.begin(ssid, password);
    Serial.print("Connecting to WiFi...");
    
    int attempt = 0;
    while (WiFi.status() != WL_CONNECTED && attempt < 20) {
        delay(500);
        Serial.print(".");
        attempt++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\nConnected to WiFi!");
        digitalWrite(LED_BUILTIN, HIGH); 
    } else {
        Serial.println("\nWiFi connection failed, will retry in loop.");
    }

    client.setInsecure();  // Skip SSL verification for Telegram

    // Initialize AceButton Event Handlers
    config1.setEventHandler(button1Handler);
    config2.setEventHandler(button2Handler);
    config3.setEventHandler(button3Handler);
    config4.setEventHandler(button4Handler);

    button1.init(switchPins[0]);
    button2.init(switchPins[1]);
    button3.init(switchPins[2]);
    button4.init(switchPins[3]);

    delay(200);
}

// Handle Telegram Messages Logic
void handleNewMessages(int numNewMessages) {
    for (int i = 0; i < numNewMessages; i++) {
        String chat_id = String(bot.messages[i].chat_id);
        if (chat_id.toInt() != chatID) continue; 

        String text = bot.messages[i].text;
        Serial.println("Received command: " + text);

        if (text == "/relay1_on") {
            relayStates[0] = true;
            digitalWrite(relayPins[0], LOW);
            bot.sendMessage(chat_id, "Relay 1 is ON", "");
        } 
        else if (text == "/relay1_off") {
            relayStates[0] = false;
            digitalWrite(relayPins[0], HIGH);
            bot.sendMessage(chat_id, "Relay 1 is OFF", "");
        } 
        else if (text == "/relay2_on") {
            relayStates[1] = true;
            digitalWrite(relayPins[1], LOW);
            bot.sendMessage(chat_id, "Relay 2 is ON", "");
        } 
        else if (text == "/relay2_off") {
            relayStates[1] = false;
            digitalWrite(relayPins[1], HIGH);
            bot.sendMessage(chat_id, "Relay 2 is OFF", "");
        } 
        else if (text == "/relay3_on") {
            relayStates[2] = true;
            digitalWrite(relayPins[2], LOW);
            bot.sendMessage(chat_id, "Relay 3 is ON", "");
        } 
        else if (text == "/relay3_off") {
            relayStates[2] = false;
            digitalWrite(relayPins[2], HIGH);
            bot.sendMessage(chat_id, "Relay 3 is OFF", "");
        } 
        else if (text == "/relay4_on") {
            relayStates[3] = true;
            digitalWrite(relayPins[3], LOW);
            bot.sendMessage(chat_id, "Relay 4 is ON", "");
        } 
        else if (text == "/relay4_off") {
            relayStates[3] = false;
            digitalWrite(relayPins[3], HIGH);
            bot.sendMessage(chat_id, "Relay 4 is OFF", "");
        } 
        else if (text == "/relay_state") {
            String statusMsg = "Current Relay Status:\n";
            for (int j = 0; j < 4; j++) {
                statusMsg += "Relay " + String(j + 1) + ": " + (relayStates[j] ? "ON\n" : "OFF\n");
            }
            bot.sendMessage(chat_id, statusMsg, "");
        } 
        else {
            bot.sendMessage(chat_id, "Valid commands:\n/relay1_on, /relay1_off\n/relay2_on, /relay2_off\n/relay3_on, /relay3_off\n/relay4_on, /relay4_off\n/relay_state", "");
        }
    }
}

void loop() {
    // Control Switches Manually
    button1.check();
    button2.check();
    button3.check();
    button4.check();

    // WiFi Reconnection and LED Blinking Logic
    if (WiFi.status() == WL_CONNECTED) {
        digitalWrite(LED_BUILTIN, HIGH); // LED stays ON when connected

        if (millis() > lastTimeBotRan + 1000) {
            int numNewMessages = bot.getUpdates(bot.last_message_received + 1);
            while (numNewMessages) {
                handleNewMessages(numNewMessages);
                numNewMessages = bot.getUpdates(bot.last_message_received + 1);
            }
            lastTimeBotRan = millis();
        }
    } 
    else {
        // Blink LED if WiFi Disconnected
        if (millis() - lastBlinkTime > 500) {
            digitalWrite(LED_BUILTIN, !digitalRead(LED_BUILTIN));
            lastBlinkTime = millis();
        }

        // Auto Reconnect Attempt every 10 seconds
        if (millis() - lastReconnectAttempt > 10000) {
            Serial.println("Reconnecting WiFi...");
            WiFi.disconnect();
            WiFi.begin(ssid, password);
            lastReconnectAttempt = millis();
        }
    }
}

// --- AceButton Events with Telegram Feedback ---

void button1Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) {
        relayStates[0] = true;
        digitalWrite(relayPins[0], LOW);
        Serial.println("Relay 1 ON via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 1: ON (Manual Switch)", "");
        }
    } 
    else if (eventType == AceButton::kEventReleased) {
        relayStates[0] = false;
        digitalWrite(relayPins[0], HIGH);
        Serial.println("Relay 1 OFF via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 1: OFF (Manual Switch)", "");
        }
    }
}

void button2Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) {
        relayStates[1] = true;
        digitalWrite(relayPins[1], LOW);
        Serial.println("Relay 2 ON via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 2: ON (Manual Switch)", "");
        }
    } 
    else if (eventType == AceButton::kEventReleased) {
        relayStates[1] = false;
        digitalWrite(relayPins[1], HIGH);
        Serial.println("Relay 2 OFF via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 2: OFF (Manual Switch)", "");
        }
    }
}

void button3Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) {
        relayStates[2] = true;
        digitalWrite(relayPins[2], LOW);
        Serial.println("Relay 3 ON via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 3: ON (Manual Switch)", "");
        }
    } 
    else if (eventType == AceButton::kEventReleased) {
        relayStates[2] = false;
        digitalWrite(relayPins[2], HIGH);
        Serial.println("Relay 3 OFF via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 3: OFF (Manual Switch)", "");
        }
    }
}

void button4Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
    if (eventType == AceButton::kEventPressed) {
        relayStates[3] = true;
        digitalWrite(relayPins[3], LOW);
        Serial.println("Relay 4 ON via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 4: ON (Manual Switch)", "");
        }
    } 
    else if (eventType == AceButton::kEventReleased) {
        relayStates[3] = false;
        digitalWrite(relayPins[3], HIGH);
        Serial.println("Relay 4 OFF via Switch");
        if (WiFi.status() == WL_CONNECTED) {
            bot.sendMessage(String(chatID), "Relay 4: OFF (Manual Switch)", "");
        }
    }
}