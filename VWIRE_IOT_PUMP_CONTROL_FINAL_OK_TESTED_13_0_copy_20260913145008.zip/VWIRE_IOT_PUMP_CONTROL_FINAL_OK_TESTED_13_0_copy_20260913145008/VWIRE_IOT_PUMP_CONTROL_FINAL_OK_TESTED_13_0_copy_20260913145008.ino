/*
  ============================================================
       VWIRE 3-DEVICE PUMP CONTROLLER
       CUSTOM ESP32 CAPTIVE PORTAL
       ESP32 BOARD VERSION 2.0.3
  ============================================================

  VWire Devices:
    V0 = START       GPIO19
    V1 = STOP        GPIO21
    V2 = AUTO MODE   GPIO22

  Local:
    AUTO BUTTON     GPIO23 -> GND
    FLOAT SENSOR    GPIO27 -> GND
    BOOT BUTTON     GPIO0  -> GND
    WIFI LED        GPIO2

  Relay:
    ACTIVE LOW

  Features:
    - Custom captive portal using WebServer + DNSServer
    - Nearby WiFi scan
    - Select WiFi SSID
    - Enter WiFi password
    - No WiFi SSID/password hard-coded
    - START pulse configurable 1-5 seconds
    - STOP pulse fixed 2 seconds
    - Float STOP immediately
    - Float remains active -> STOP every 5 seconds
    - AUTO MODE saved in NVS
    - AUTO ON before power failure -> START after 60 seconds
    - BOOT button opens configuration portal
    - WiFi credentials stored in NVS
  ============================================================
*/

#include <WiFi.h>
#include <WebServer.h>
#include <DNSServer.h>
#include <Preferences.h>
#include <Vwire.h>

// ============================================================
//                    VWIRE CREDENTIALS
// ============================================================

const char* AUTH_TOKEN = "iot_bcfyqkccPHgD22ta2CwlDbnOvmkyPgnj";
const char* DEVICE_ID  = "VU-9XNFAM";

// ============================================================
//                    PIN CONFIGURATION
// ============================================================

#define START_RELAY_PIN 19  // THIS IS FOR START RELAY
#define STOP_RELAY_PIN  21  // THIS IS FOR STOP RELAY 
#define AUTO_RELAY_PIN  22  // THIS IS FOR AUTO MODE ON OFF INTERNALLY 

#define AUTO_BUTTON_PIN 23  // THIS IS FOR AUTO MODE MANNUAL BUTTON TO GND
#define FLOAT_PIN       27  // THIS IS FOR FLOAT SENSOR TO GND TO STOP PUMP WHEN WATER OVERFLOWW

#define LED_PIN          2  // THIS IS WIFI LED ON BOARD OR EXTERNAL LED 
#define BOOT_BUTTON_PIN  0

// ============================================================
//                    RELAY LOGIC
// ============================================================

#define RELAY_ON  LOW
#define RELAY_OFF HIGH

// STOP relay fixed pulse
#define STOP_PULSE_TIME 2000UL

// Power reset AUTO start delay
#define AUTO_START_DELAY 60000UL

// Float repeated STOP delay
#define FLOAT_STOP_DELAY 5000UL

// Default START pulse
#define DEFAULT_START_TIME 2000UL

// Allowed START pulse range
#define MIN_START_TIME 1000UL
#define MAX_START_TIME 5000UL

// ============================================================
//                    CAPTIVE PORTAL
// ============================================================

WebServer server(80);
DNSServer dnsServer;

const byte DNS_PORT = 53;

IPAddress apIP(192, 168, 4, 1);

// Configuration AP name
const char* AP_SSID = "VWire-Pump-Setup";

// ============================================================
//                    NVS
// ============================================================

Preferences prefs;

// ============================================================
//                    WIFI SETTINGS
// ============================================================

String savedSSID = "";
String savedPassword = "";

bool configMode = false;

bool bootButtonPressed = false;
unsigned long bootButtonStart = 0;

// ============================================================
//                    PUMP VARIABLES
// ============================================================

bool autoMode = false;

// START pulse
bool startPulseActive = false;
unsigned long startPulseEnd = 0;

// STOP pulse
bool stopPulseActive = false;
unsigned long stopPulseEnd = 0;

// Configurable START pulse
unsigned long startPulseTime = DEFAULT_START_TIME;

// ============================================================
//                    AUTO POWER RESET
// ============================================================

bool bootAutoStartPending = false;
unsigned long bootAutoStartTime = 0;

// ============================================================
//                    FLOAT SENSOR
// ============================================================

bool floatActive = false;
unsigned long nextFloatStopTime = 0;

// ============================================================
//                    AUTO BUTTON
// ============================================================

bool lastButtonReading = HIGH;
bool buttonState = HIGH;
unsigned long lastDebounceTime = 0;

#define DEBOUNCE_TIME 50UL

// ============================================================
//                    WIFI LED
// ============================================================

unsigned long lastBlinkTime = 0;
unsigned long lastReconnectTime = 0;

bool ledState = LOW;

// ============================================================
//                    CONFIG PAGE HTML
// ============================================================

String makePage(String message = "")
{
  String html;

  html += "<!DOCTYPE html>";
  html += "<html>";
  html += "<head>";

  html += "<meta name='viewport' content='width=device-width,initial-scale=1'>";

  html += "<meta charset='UTF-8'>";

  html += "<title>VWire Pump Setup</title>";

  html += "<style>";

  html += "body{";
  html += "font-family:Arial,sans-serif;";
  html += "background:#f2f4f7;";
  html += "margin:0;";
  html += "padding:15px;";
  html += "}";

  html += ".card{";
  html += "max-width:500px;";
  html += "margin:auto;";
  html += "background:white;";
  html += "padding:22px;";
  html += "border-radius:18px;";
  html += "box-shadow:0 4px 20px rgba(0,0,0,.12);";
  html += "}";

  html += "h1{";
  html += "text-align:center;";
  html += "margin-top:5px;";
  html += "}";

  html += ".sub{";
  html += "text-align:center;";
  html += "color:#666;";
  html += "}";

  html += "label{";
  html += "font-weight:bold;";
  html += "display:block;";
  html += "margin-top:18px;";
  html += "}";

  html += "select,input{";
  html += "width:100%;";
  html += "box-sizing:border-box;";
  html += "padding:13px;";
  html += "margin-top:7px;";
  html += "border:1px solid #ccc;";
  html += "border-radius:10px;";
  html += "font-size:16px;";
  html += "}";

  html += "button{";
  html += "width:100%;";
  html += "padding:14px;";
  html += "margin-top:15px;";
  html += "border:0;";
  html += "border-radius:10px;";
  html += "font-size:16px;";
  html += "font-weight:bold;";
  html += "cursor:pointer;";
  html += "}";

  html += ".save{";
  html += "background:#111;";
  html += "color:white;";
  html += "}";

  html += ".scan{";
  html += "background:#e7e9ed;";
  html += "color:#111;";
  html += "}";

  html += ".danger{";
  html += "background:#eee;";
  html += "color:#b00020;";
  html += "}";

  html += ".info{";
  html += "background:#eef5ff;";
  html += "padding:12px;";
  html += "border-radius:10px;";
  html += "margin-top:15px;";
  html += "}";

  html += ".success{";
  html += "background:#eaf8ed;";
  html += "padding:12px;";
  html += "border-radius:10px;";
  html += "margin-top:15px;";
  html += "}";

  html += "</style>";

  html += "</head>";

  html += "<body>";

  html += "<div class='card'>";

  html += "<h1>⚙️ VWire Pump</h1>";

  html += "<div class='sub'>WiFi & Pump Configuration</div>";

  if (message.length() > 0)
  {
    html += "<div class='success'>";
    html += message;
    html += "</div>";
  }

  // ========================================================
  // WIFI SECTION
  // ========================================================

  html += "<form action='/save' method='POST'>";

  html += "<label>📶 WiFi Network</label>";

  html += "<select name='ssid' id='ssid'>";

  html += "<option value=''>Select WiFi Network</option>";

  int n = WiFi.scanNetworks();

  if (n > 0)
  {
    for (int i = 0; i < n; i++)
    {
      String ssid = WiFi.SSID(i);

      if (ssid.length() == 0)
        continue;

      html += "<option value='";
      html += ssid;
      html += "'";

      if (ssid == savedSSID)
        html += " selected";

      html += ">";

      html += ssid;

      html += " (";
      html += String(WiFi.RSSI(i));
      html += " dBm)";

      html += "</option>";
    }
  }

  html += "</select>";

  html += "<button type='button' class='scan' onclick='location.reload()'>";
  html += "🔍 SCAN NEARBY WIFI";
  html += "</button>";

  html += "<label>🔐 WiFi Password</label>";

  html += "<input type='password' name='password' placeholder='Enter WiFi password'>";

  // ========================================================
  // START TIME
  // ========================================================

  html += "<label>⏱ START Relay Pulse Time</label>";

  html += "<select name='startTime'>";

  for (int sec = 1; sec <= 5; sec++)
  {
    unsigned long value = sec * 1000UL;

    html += "<option value='";
    html += String(value);
    html += "'";

    if (startPulseTime == value)
      html += " selected";

    html += ">";

    html += String(sec);

    html += " second";

    if (sec > 1)
      html += "s";

    html += "</option>";
  }

  html += "</select>";

  html += "<div class='info'>";

  html += "START: GPIO19<br>";
  html += "STOP: GPIO21 (fixed 2 sec)<br>";
  html += "AUTO: GPIO22<br>";
  html += "FLOAT: GPIO27<br>";
  html += "AUTO Button: GPIO23";

  html += "</div>";

  html += "<button type='submit' class='save'>";
  html += "💾 SAVE & RESTART";
  html += "</button>";

  html += "</form>";

  // ========================================================
  // RESET WIFI
  // ========================================================

  html += "<form action='/reset' method='POST'>";

  html += "<button type='submit' class='danger'>";
  html += "🗑 CLEAR WIFI & RESET";
  html += "</button>";

  html += "</form>";

  html += "</div>";

  html += "</body>";

  html += "</html>";

  return html;
}

// ============================================================
//                    LOAD WIFI SETTINGS
// ============================================================

void loadWiFiSettings()
{
  prefs.begin("pump", false);

  savedSSID =
    prefs.getString("ssid", "");

  savedPassword =
    prefs.getString("pass", "");

  startPulseTime =
    prefs.getULong(
      "startTime",
      DEFAULT_START_TIME
    );

  // Safety limit
  if (startPulseTime < MIN_START_TIME ||
      startPulseTime > MAX_START_TIME)
  {
    startPulseTime = DEFAULT_START_TIME;
  }

  autoMode =
    prefs.getBool("auto", false);

  Serial.println();
  Serial.println("===== SAVED SETTINGS =====");

  Serial.print("SSID: ");

  if (savedSSID.length() > 0)
    Serial.println(savedSSID);
  else
    Serial.println("(NOT SET)");

  Serial.print("START pulse: ");
  Serial.print(startPulseTime / 1000);
  Serial.println(" sec");

  Serial.print("AUTO mode: ");
  Serial.println(
    autoMode ? "ON" : "OFF"
  );

  Serial.println("==========================");
}

// ============================================================
//                    START CONFIG PORTAL
// ============================================================

void startConfigPortal()
{
  configMode = true;

  Serial.println();
  Serial.println("======================================");
  Serial.println("      VWIRE CONFIGURATION MODE");
  Serial.println("======================================");

  WiFi.disconnect(true, true);

  delay(300);

  WiFi.mode(WIFI_AP);

  WiFi.softAPConfig(
    apIP,
    apIP,
    IPAddress(255, 255, 255, 0)
  );

  WiFi.softAP(AP_SSID);

  delay(500);

  dnsServer.start(
    DNS_PORT,
    "*",
    apIP
  );

  // --------------------------------------------------------
  // ROOT
  // --------------------------------------------------------

  server.on(
    "/",
    HTTP_GET,
    []()
    {
      server.send(
        200,
        "text/html",
        makePage()
      );
    }
  );

  // --------------------------------------------------------
  // SAVE
  // --------------------------------------------------------

  server.on(
    "/save",
    HTTP_POST,
    []()
    {
      String newSSID =
        server.arg("ssid");

      String newPassword =
        server.arg("password");

      String newStart =
        server.arg("startTime");

      if (newSSID.length() == 0)
      {
        server.send(
          200,
          "text/html",
          makePage(
            "⚠️ Please select a WiFi network."
          )
        );

        return;
      }

      unsigned long newStartTime =
        newStart.toInt();

      if (
        newStartTime < MIN_START_TIME ||
        newStartTime > MAX_START_TIME
      )
      {
        newStartTime =
          DEFAULT_START_TIME;
      }

      prefs.putString(
        "ssid",
        newSSID
      );

      prefs.putString(
        "pass",
        newPassword
      );

      prefs.putULong(
        "startTime",
        newStartTime
      );

      savedSSID = newSSID;
      savedPassword = newPassword;
      startPulseTime = newStartTime;

      Serial.println();
      Serial.println("WiFi configuration saved.");

      server.send(
        200,
        "text/html",
        "<html><body>"
        "<h2>Saved!</h2>"
        "<p>ESP32 will restart now...</p>"
        "</body></html>"
      );

      delay(1000);

      ESP.restart();
    }
  );

  // --------------------------------------------------------
  // RESET
  // --------------------------------------------------------

  server.on(
    "/reset",
    HTTP_POST,
    []()
    {
      prefs.clear();

      savedSSID = "";
      savedPassword = "";

      startPulseTime =
        DEFAULT_START_TIME;

      server.send(
        200,
        "text/html",
        "<html><body>"
        "<h2>WiFi settings cleared.</h2>"
        "<p>ESP32 will restart...</p>"
        "</body></html>"
      );

      delay(1000);

      ESP.restart();
    }
  );

  // --------------------------------------------------------
  // CAPTIVE PORTAL REDIRECT
  // --------------------------------------------------------

  server.onNotFound(
    []()
    {
      server.sendHeader(
        "Location",
        "http://192.168.4.1/",
        true
      );

      server.send(
        302,
        "text/plain",
        ""
      );
    }
  );

  server.begin();

  Serial.println();
  Serial.println("AP SSID:");
  Serial.println(AP_SSID);

  Serial.println("Open:");
  Serial.println("http://192.168.4.1");

  Serial.println();
}

// ============================================================
//                    CONFIG PORTAL LOOP
// ============================================================

void configPortalLoop()
{
  dnsServer.processNextRequest();

  server.handleClient();
}

// ============================================================
//                    CONNECT WIFI
// ============================================================

bool connectToSavedWiFi()
{
  if (savedSSID.length() == 0)
  {
    Serial.println(
      "No saved WiFi credentials."
    );

    return false;
  }

  Serial.println();
  Serial.println(
    "Connecting to saved WiFi..."
  );

  Serial.print("SSID: ");
  Serial.println(savedSSID);

  WiFi.mode(WIFI_STA);

  WiFi.begin(
    savedSSID.c_str(),
    savedPassword.c_str()
  );

  unsigned long startTime =
    millis();

  while (
    WiFi.status() != WL_CONNECTED &&
    millis() - startTime < 20000
  )
  {
    delay(250);

    Serial.print(".");
  }

  Serial.println();

  if (WiFi.status() == WL_CONNECTED)
  {
    Serial.println();
    Serial.println(
      "WiFi connected!"
    );

    Serial.print(
      "IP Address: "
    );

    Serial.println(
      WiFi.localIP()
    );

    return true;
  }

  Serial.println();
  Serial.println(
    "WiFi connection failed."
  );

  return false;
}

// ============================================================
//                    START PUMP
// ============================================================

void startPump()
{
  // Safety:
  // If float is active, do not START pump.

  if (digitalRead(FLOAT_PIN) == LOW)
  {
    Serial.println();
    Serial.println(
      "START BLOCKED - FLOAT ACTIVE"
    );

    return;
  }

  Serial.println();
  Serial.println(">>> PUMP START");

  // STOP OFF
  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_OFF
  );

  stopPulseActive = false;

  // START ON
  digitalWrite(
    START_RELAY_PIN,
    RELAY_ON
  );

  startPulseActive = true;

  startPulseEnd =
    millis() + startPulseTime;

  Serial.print(
    "START relay time: "
  );

  Serial.print(
    startPulseTime / 1000
  );

  Serial.println(
    " seconds"
  );
}

// ============================================================
//                    STOP PUMP
// ============================================================

void stopPump()
{
  Serial.println();
  Serial.println(">>> PUMP STOP");

  // Cancel pending Auto START
  bootAutoStartPending = false;

  // START OFF
  digitalWrite(
    START_RELAY_PIN,
    RELAY_OFF
  );

  startPulseActive = false;

  // STOP ON
  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_ON
  );

  stopPulseActive = true;

  stopPulseEnd =
    millis() + STOP_PULSE_TIME;
}

// ============================================================
//                    UPDATE PUMP PULSES
// ============================================================

void updatePumpPulses()
{
  unsigned long now =
    millis();

  // START pulse
  if (
    startPulseActive &&
    (long)(now - startPulseEnd) >= 0
  )
  {
    digitalWrite(
      START_RELAY_PIN,
      RELAY_OFF
    );

    startPulseActive = false;

    Serial.println(
      "START relay OFF"
    );
  }

  // STOP pulse
  if (
    stopPulseActive &&
    (long)(now - stopPulseEnd) >= 0
  )
  {
    digitalWrite(
      STOP_RELAY_PIN,
      RELAY_OFF
    );

    stopPulseActive = false;

    Serial.println(
      "STOP relay OFF"
    );
  }
}

// ============================================================
//                    AUTO MODE
// ============================================================

void setAutoMode(bool state)
{
  autoMode = state;

  // Save Auto Mode
  prefs.putBool(
    "auto",
    autoMode
  );

  // AUTO relay / indicator
  digitalWrite(
    AUTO_RELAY_PIN,
    autoMode
      ? RELAY_ON
      : RELAY_OFF
  );

  Serial.print(
    "AUTO MODE -> "
  );

  Serial.println(
    autoMode
      ? "ON"
      : "OFF"
  );

  // Update VWire dashboard
  Vwire.virtualSend(
    V2,
    autoMode ? 1 : 0
  );

  // If AUTO OFF,
  // cancel pending power-reset start
  if (!autoMode)
  {
    bootAutoStartPending = false;

    Serial.println(
      "Pending AUTO START cancelled."
    );
  }
}

// ============================================================
//                    VWIRE START
// ============================================================

VWIRE_RECEIVE(V0)
{
  int value =
    param.asInt();

  Serial.print(
    "V0 START -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );

  if (value == 1)
  {
    startPump();
  }
}

// ============================================================
//                    VWIRE STOP
// ============================================================

VWIRE_RECEIVE(V1)
{
  int value =
    param.asInt();

  Serial.print(
    "V1 STOP -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );

  if (value == 1)
  {
    stopPump();
  }
}

// ============================================================
//                    VWIRE AUTO
// ============================================================

VWIRE_RECEIVE(V2)
{
  int value =
    param.asInt();

  Serial.print(
    "V2 AUTO -> "
  );

  Serial.println(
    value ? "ON" : "OFF"
  );

  setAutoMode(
    value == 1
  );
}

// ============================================================
//                    VWIRE CONNECTED
// ============================================================

VWIRE_CONNECTED()
{
  Serial.println();
  Serial.println(
    "Connected to VWire!"
  );

  // Restore dashboard Auto state
  Vwire.virtualSend(
    V2,
    autoMode ? 1 : 0
  );
}

// ============================================================
//                    VWIRE DISCONNECTED
// ============================================================

VWIRE_DISCONNECTED()
{
  Serial.println(
    "Disconnected from VWire!"
  );
}

// ============================================================
//                    LOCAL AUTO BUTTON
// ============================================================

void checkAutoButton()
{
  bool reading =
    digitalRead(
      AUTO_BUTTON_PIN
    );

  if (
    reading !=
    lastButtonReading
  )
  {
    lastDebounceTime =
      millis();
  }

  if (
    millis() - lastDebounceTime >
    DEBOUNCE_TIME
  )
  {
    if (
      reading != buttonState
    )
    {
      buttonState = reading;

      if (buttonState == LOW)
      {
        Serial.println(
          "Local AUTO button pressed"
        );

        setAutoMode(
          !autoMode
        );
      }
    }
  }

  lastButtonReading =
    reading;
}

// ============================================================
//                    FLOAT SENSOR
// ============================================================

void checkFloatSensor()
{
  bool currentFloat =
    (
      digitalRead(
        FLOAT_PIN
      ) == LOW
    );

  // ----------------------------------------------------------
  // FLOAT BECAME ACTIVE
  // ----------------------------------------------------------

  if (
    currentFloat &&
    !floatActive
  )
  {
    floatActive = true;

    Serial.println();
    Serial.println(
      "================================"
    );

    Serial.println(
      "WATER FLOAT ACTIVE"
    );

    Serial.println(
      "FLOAT -> STOP"
    );

    Serial.println(
      "================================"
    );

    // Cancel Auto Start
    bootAutoStartPending =
      false;

    // Immediate STOP
    stopPump();

    // Next STOP after 5 seconds
    nextFloatStopTime =
      millis() +
      FLOAT_STOP_DELAY;
  }

  // ----------------------------------------------------------
  // FLOAT STILL ACTIVE
  // ----------------------------------------------------------

  else if (
    currentFloat &&
    floatActive
  )
  {
    unsigned long now =
      millis();

    if (
      (long)(
        now -
        nextFloatStopTime
      ) >= 0
    )
    {
      Serial.println();
      Serial.println(
        "FLOAT STILL ACTIVE -> STOP AGAIN"
      );

      stopPump();

      nextFloatStopTime =
        now +
        FLOAT_STOP_DELAY;
    }
  }

  // ----------------------------------------------------------
  // FLOAT BECAME INACTIVE
  // ----------------------------------------------------------

  else if (
    !currentFloat &&
    floatActive
  )
  {
    floatActive = false;

    nextFloatStopTime = 0;

    Serial.println();
    Serial.println(
      "FLOAT INACTIVE"
    );

    Serial.println(
      "Float timer reset"
    );
  }
}

// ============================================================
//                 POWER RESET AUTO START
// ============================================================

void checkBootAutoStart()
{
  if (!bootAutoStartPending)
    return;

  // AUTO turned OFF
  if (!autoMode)
  {
    bootAutoStartPending =
      false;

    return;
  }

  // Float active
  if (
    digitalRead(FLOAT_PIN) == LOW
  )
  {
    bootAutoStartPending =
      false;

    Serial.println(
      "AUTO START cancelled - FLOAT ACTIVE"
    );

    return;
  }

  unsigned long elapsed =
    millis() -
    bootAutoStartTime;

  if (
    elapsed >=
    AUTO_START_DELAY
  )
  {
    bootAutoStartPending =
      false;

    Serial.println();
    Serial.println(
      "================================"
    );

    Serial.println(
      "60 SECOND DELAY COMPLETED"
    );

    Serial.println(
      "AUTO MODE = ON"
    );

    Serial.println(
      "AUTOMATIC PUMP START"
    );

    Serial.println(
      "================================"
    );

    startPump();
  }
}

// ============================================================
//                    WIFI LED
// ============================================================

void updateWiFiLED()
{
  unsigned long now =
    millis();

  if (
    WiFi.status() ==
    WL_CONNECTED
  )
  {
    digitalWrite(
      LED_PIN,
      HIGH
    );
  }
  else
  {
    if (
      now - lastBlinkTime >=
      500
    )
    {
      lastBlinkTime =
        now;

      ledState =
        !ledState;

      digitalWrite(
        LED_PIN,
        ledState
      );
    }
  }
}

// ============================================================
//                    SETUP
// ============================================================

void setup()
{
  Serial.begin(115200);

  delay(300);

  Serial.println();
  Serial.println(
    "=========================================="
  );

  Serial.println(
    " VWIRE 3 DEVICE PUMP CONTROLLER"
  );

  Serial.println(
    " CUSTOM WIFI CAPTIVE PORTAL"
  );

  Serial.println(
    "=========================================="
  );

  // ========================================================
  // GPIO
  // ========================================================

  pinMode(
    LED_PIN,
    OUTPUT
  );

  pinMode(
    START_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    STOP_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    AUTO_RELAY_PIN,
    OUTPUT
  );

  pinMode(
    AUTO_BUTTON_PIN,
    INPUT_PULLUP
  );

  pinMode(
    FLOAT_PIN,
    INPUT_PULLUP
  );

  pinMode(
    BOOT_BUTTON_PIN,
    INPUT_PULLUP
  );

  // ========================================================
  // RELAYS OFF FIRST
  // ========================================================

  digitalWrite(
    START_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    STOP_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    AUTO_RELAY_PIN,
    RELAY_OFF
  );

  digitalWrite(
    LED_PIN,
    LOW
  );

  // ========================================================
  // LOAD NVS
  // ========================================================

  loadWiFiSettings();

  // Restore AUTO output
  digitalWrite(
    AUTO_RELAY_PIN,
    autoMode
      ? RELAY_ON
      : RELAY_OFF
  );

  // ========================================================
  // CHECK BOOT BUTTON
  // ========================================================

  Serial.println();
  Serial.println(
    "Hold BOOT button for 3 seconds"
  );

  Serial.println(
    "to open WiFi configuration."
  );

  unsigned long bootCheckStart =
    millis();

  while (
    millis() -
    bootCheckStart <
    3500
  )
  {
    if (
      digitalRead(
        BOOT_BUTTON_PIN
      ) == LOW
    )
    {
      bootButtonPressed = true;

      Serial.println(
        "BOOT button detected..."
      );

      break;
    }

    delay(10);
  }

  // ========================================================
  // CONFIG MODE
  // ========================================================

  if (bootButtonPressed)
  {
    startConfigPortal();

    return;
  }

  // ========================================================
  // NO WIFI SAVED
  // ========================================================

  if (
    savedSSID.length() == 0
  )
  {
    Serial.println();
    Serial.println(
      "No WiFi saved."
    );

    startConfigPortal();

    return;
  }

  // ========================================================
  // CONNECT TO SAVED WIFI
  // ========================================================

  bool wifiOK =
    connectToSavedWiFi();

  // ========================================================
  // CONNECTION FAILED
  // ========================================================

  if (!wifiOK)
  {
    Serial.println();
    Serial.println(
      "Could not connect to saved WiFi."
    );

    Serial.println(
      "Starting configuration portal..."
    );

    startConfigPortal();

    return;
  }

  // ========================================================
  // POWER RESET AUTO START
  // ========================================================

  if (autoMode)
  {
    bootAutoStartPending =
      true;

    bootAutoStartTime =
      millis();

    Serial.println();
    Serial.println(
      "=========================================="
    );

    Serial.println(
      "AUTO MODE WAS ON BEFORE POWER RESET"
    );

    Serial.println(
      "AUTO START AFTER 60 SECONDS"
    );

    Serial.println(
      "=========================================="
    );
  }

  // ========================================================
  // FLOAT AT BOOT
  // ========================================================

  if (
    digitalRead(
      FLOAT_PIN
    ) == LOW
  )
  {
    Serial.println();
    Serial.println(
      "FLOAT ACTIVE AT BOOT"
    );

    bootAutoStartPending =
      false;

    floatActive = true;

    stopPump();

    nextFloatStopTime =
      millis() +
      FLOAT_STOP_DELAY;
  }

  // ========================================================
  // VWIRE
  // ========================================================

  WiFi.mode(WIFI_STA);

  Vwire.logTo(Serial);

  Vwire.config(
    AUTH_TOKEN,
    DEVICE_ID
  );

  Vwire.begin(
    savedSSID.c_str(),
    savedPassword.c_str()
  );
}

// ============================================================
//                    LOOP
// ============================================================

void loop()
{
  // ========================================================
  // CONFIGURATION MODE
  // ========================================================

  if (configMode)
  {
    configPortalLoop();

    return;
  }

  unsigned long now =
    millis();

  // ========================================================
  // PUMP PULSES
  // ========================================================

  updatePumpPulses();

  // ========================================================
  // POWER RESET AUTO START
  // ========================================================

  checkBootAutoStart();

  // ========================================================
  // LOCAL AUTO BUTTON
  // ========================================================

  checkAutoButton();

  // ========================================================
  // FLOAT
  // ========================================================

  checkFloatSensor();

  // ========================================================
  // WIFI / VWIRE
  // ========================================================

  if (
    WiFi.status() ==
    WL_CONNECTED
  )
  {
    digitalWrite(
      LED_PIN,
      HIGH
    );

    Vwire.run();
  }
  else
  {
    // ------------------------------------------------------
    // WIFI LED BLINK
    // ------------------------------------------------------

    if (
      now -
      lastBlinkTime >=
      500
    )
    {
      lastBlinkTime =
        now;

      ledState =
        !ledState;

      digitalWrite(
        LED_PIN,
        ledState
      );
    }

    // ------------------------------------------------------
    // RECONNECT
    // ------------------------------------------------------

    if (
      now -
      lastReconnectTime >=
      10000
    )
    {
      lastReconnectTime =
        now;

      Serial.println(
        "WiFi disconnected. Reconnecting..."
      );

      WiFi.disconnect();

      WiFi.begin(
        savedSSID.c_str(),
        savedPassword.c_str()
      );
    }
  }
}