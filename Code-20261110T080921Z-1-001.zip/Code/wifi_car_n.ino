#include <WiFi.h>
#include <WebServer.h>

// ======================================================
// MOTOR PINS
// ======================================================

// ENA1 and ENA2 are NOT physically connected.
// L298N ENA/ENB jumpers are connected.



const int IP1 = 26;
const int IP2 = 25;

const int IP3 = 33;
const int IP4 = 32;


// ======================================================
// LED PINS
// ======================================================

const int ledf1 = 18;
const int ledf2 = 19;

const int ledb1 = 22;
const int ledb2 = 23;


// ======================================================
// WIFI
// ======================================================

const char* ssid = "ESP32_CAR";
const char* password = "12345678";

WebServer server(80);


// ======================================================
// SAFETY TIMEOUT
// ======================================================

unsigned long lastCommandTime = 0;

const unsigned long commandTimeout = 500;


// ======================================================
// LED MODE
// ======================================================

// 0 = AUTO MODE
// 1 = MANUAL MODE

int ledMode = 0;

bool allLedsOn = false;


// ======================================================
// LED FUNCTIONS
// ======================================================

void allLedsOff() {

  digitalWrite(ledf1, LOW);
  digitalWrite(ledf2, LOW);
  digitalWrite(ledb1, LOW);
  digitalWrite(ledb2, LOW);
}


void allLedsOnFunction() {

  digitalWrite(ledf1, HIGH);
  digitalWrite(ledf2, HIGH);
  digitalWrite(ledb1, HIGH);
  digitalWrite(ledb2, HIGH);
}


void updateManualLEDs() {

  if (ledMode == 1) {

    if (allLedsOn) {
      allLedsOnFunction();
    }
    else {
      allLedsOff();
    }
  }
}


// ======================================================
// MOTOR STOP
// ======================================================
// IMPORTANT:
// ENA/ENB jumpers are connected on L298N.
// Therefore ENA1/ENA2 cannot stop the motors.
//
// We stop the motors by setting IN1-IN4 LOW.
// ======================================================

void stopCar() {

  digitalWrite(IP1, LOW);
  digitalWrite(IP2, LOW);

  digitalWrite(IP3, LOW);
  digitalWrite(IP4, LOW);


  // AUTO MODE
  if (ledMode == 0) {

    allLedsOff();
  }

  // MANUAL MODE
  else {

    updateManualLEDs();
  }
}


// ======================================================
// MOTOR FUNCTIONS
// ======================================================

void forward() {

  digitalWrite(IP1, HIGH);
  digitalWrite(IP2, LOW);

  digitalWrite(IP3, HIGH);
  digitalWrite(IP4, LOW);


  if (ledMode == 0) {

    allLedsOff();

    digitalWrite(ledf1, HIGH);
    digitalWrite(ledf2, HIGH);
  }

  else {

    updateManualLEDs();
  }
}


void backward() {

  digitalWrite(IP1, LOW);
  digitalWrite(IP2, HIGH);

  digitalWrite(IP3, LOW);
  digitalWrite(IP4, HIGH);


  if (ledMode == 0) {

    allLedsOff();

    digitalWrite(ledb1, HIGH);
    digitalWrite(ledb2, HIGH);
  }

  else {

    updateManualLEDs();
  }
}


void right() {

  digitalWrite(IP1, LOW);
  digitalWrite(IP2, HIGH);

  digitalWrite(IP3, HIGH);
  digitalWrite(IP4, LOW);


  if (ledMode == 0) {

    allLedsOff();

    digitalWrite(ledf2, HIGH);
    digitalWrite(ledb2, HIGH);
  }

  else {

    updateManualLEDs();
  }
}


void left() {

  digitalWrite(IP1, HIGH);
  digitalWrite(IP2, LOW);

  digitalWrite(IP3, LOW);
  digitalWrite(IP4, HIGH);


  if (ledMode == 0) {

    allLedsOff();

    digitalWrite(ledf1, HIGH);
    digitalWrite(ledb1, HIGH);
  }

  else {

    updateManualLEDs();
  }
}


// ======================================================
// WEB PAGE
// ======================================================

const char webpage[] PROGMEM = R"rawliteral(

<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<title>ESP32 Robot Controller</title>


<style>

/* ================= GENERAL ================= */

* {

  box-sizing: border-box;

  user-select: none;

  -webkit-user-select: none;

  -webkit-touch-callout: none;

}


body {

  margin: 0;

  background:
    radial-gradient(circle at top, #1d2935, #080b0e 70%);

  color: white;

  font-family: Arial, sans-serif;

  text-align: center;

  min-height: 100vh;

  overflow: hidden;

  touch-action: none;

}


/* ================= HEADER ================= */

.header {

  padding-top: 25px;

}


.header h1 {

  margin: 0;

  font-size: 27px;

  letter-spacing: 1px;

}


.subtitle {

  margin-top: 6px;

  color: #777;

  font-size: 13px;

}


/* ================= STATUS ================= */

.status {

  display: inline-block;

  margin-top: 20px;

  padding: 10px 25px;

  border-radius: 30px;

  background: #151a1f;

  border: 1px solid #333;

  color: #00ff88;

  font-size: 15px;

  font-weight: bold;

  letter-spacing: 1px;

}


/* ================= CONTROLLER ================= */

.controller {

  width: 310px;

  max-width: 95vw;

  margin: 30px auto 0;

}


/* ================= BUTTON ================= */

.control-btn {

  width: 85px;

  height: 85px;

  margin: 6px;

  border: none;

  border-radius: 22px;

  background:
    linear-gradient(145deg, #252c33, #151a1f);

  color: white;

  font-size: 34px;

  font-weight: bold;

  box-shadow:

    0 7px 15px rgba(0,0,0,0.5),

    inset 0 1px 1px rgba(255,255,255,0.05);

  transition:
    transform 0.08s,
    background 0.08s;

  -webkit-tap-highlight-color: transparent;

  touch-action: none;

}


.control-btn.active {

  background: #00a86b;

  transform: scale(0.92);

  box-shadow:

    0 0 25px rgba(0,255,136,0.35);

}


/* ================= STOP ================= */

.stop {

  background:
    linear-gradient(145deg, #e63946, #a4161a);

  font-size: 28px;

}


.stop:active {

  transform: scale(0.92);

  background: #ff3030;

}


/* ================= LED SECTION ================= */

.led-section {

  margin-top: 20px;

  width: 320px;

  max-width: 95vw;

  margin-left: auto;

  margin-right: auto;

}


.led-title {

  color: #777;

  font-size: 13px;

  letter-spacing: 1px;

  margin-bottom: 12px;

}


/* ================= MODE BUTTONS ================= */

.mode-container {

  display: flex;

  justify-content: center;

  gap: 10px;

}


.mode-btn {

  width: 135px;

  height: 45px;

  border: none;

  border-radius: 14px;

  background: #151a1f;

  border: 1px solid #333;

  color: #aaa;

  font-size: 14px;

  font-weight: bold;

}


.mode-btn.active {

  background: #00a86b;

  color: white;

  border-color: #00a86b;

}


/* ================= ALL LED BUTTON ================= */

.all-led-btn {

  margin-top: 12px;

  width: 280px;

  height: 50px;

  border: none;

  border-radius: 15px;

  background:
    linear-gradient(145deg, #252c33, #151a1f);

  color: white;

  font-size: 16px;

  font-weight: bold;

}


.all-led-btn.on {

  background: #00a86b;

  box-shadow: 0 0 20px rgba(0,255,136,0.35);

}


/* ================= INFO ================= */

.info {

  margin-top: 15px;

  color: #777;

  font-size: 12px;

  line-height: 1.5;

}


/* ================= FOOTER ================= */

.footer {

  position: fixed;

  bottom: 10px;

  width: 100%;

  color: #444;

  font-size: 11px;

  letter-spacing: 1px;

}

</style>

</head>


<body>


<!-- ================= HEADER ================= -->

<div class="header">

  <h1>ESP32 ROBOT</h1>

  <div class="subtitle">

    WiFi Remote Controller

  </div>


  <div class="status" id="status">

    STOPPED

  </div>

</div>


<!-- ================= CONTROLLER ================= -->

<div class="controller">


  <!-- FORWARD -->

  <div>

    <button

      class="control-btn"

      id="forward">

      &#8593;

    </button>

  </div>


  <!-- LEFT / STOP / RIGHT -->

  <div>

    <button

      class="control-btn"

      id="left">

      &#8592;

    </button>


    <button

      class="control-btn stop"

      id="stop">

      &#9632;

    </button>


    <button

      class="control-btn"

      id="right">

      &#8594;

    </button>

  </div>


  <!-- BACKWARD -->

  <div>

    <button

      class="control-btn"

      id="backward">

      &#8595;

    </button>

  </div>


</div>


<!-- ================= LED CONTROL ================= -->

<div class="led-section">

  <div class="led-title">

    LED LIGHT CONTROL

  </div>


  <div class="mode-container">

    <button

      class="mode-btn active"

      id="autoMode">

      AUTO

    </button>


    <button

      class="mode-btn"

      id="manualMode">

      MANUAL

    </button>

  </div>


  <button

    class="all-led-btn"

    id="allLed">

    ALL LEDs OFF

  </button>

</div>


<div class="info">

  HOLD TO MOVE

  <br>

  AUTO: LEDs follow movement

  <br>

  MANUAL: Control all LEDs

</div>


<div class="footer">

  ESP32 WiFi Robot Controller

</div>


<script>


// ======================================================
// MOVEMENT VARIABLES
// ======================================================

let moveInterval = null;

let currentDirection = null;


// ======================================================
// LED VARIABLES
// ======================================================

let currentLedMode = "auto";

let allLedState = false;


// ======================================================
// START MOVEMENT
// ======================================================

function startMove(direction) {

  if (currentDirection === direction) {

    return;

  }


  if (moveInterval !== null) {

    clearInterval(moveInterval);

    moveInterval = null;

  }


  currentDirection = direction;


  const button =
    document.getElementById(direction);

  button.classList.add("active");


  document.getElementById("status").innerHTML =

    direction.toUpperCase();


  fetch("/" + direction)

    .catch(() => {});


  moveInterval = setInterval(function() {

    fetch("/" + direction)

      .catch(() => {});

  }, 250);

}


// ======================================================
// STOP MOVEMENT
// ======================================================

function stopMove() {

  if (moveInterval !== null) {

    clearInterval(moveInterval);

    moveInterval = null;

  }


  if (currentDirection !== null) {

    const button =
      document.getElementById(currentDirection);

    button.classList.remove("active");

  }


  currentDirection = null;


  document.getElementById("status").innerHTML =

    "STOPPED";


  fetch("/stop")

    .catch(() => {});

}


// ======================================================
// BUTTON SETUP
// ======================================================

function setupButton(id, direction) {

  const button =
    document.getElementById(id);


  // ================= TOUCH =================

  button.addEventListener(

    "touchstart",

    function(event) {

      event.preventDefault();

      startMove(direction);

    },

    { passive: false }

  );


  button.addEventListener(

    "touchend",

    function(event) {

      event.preventDefault();

      stopMove();

    },

    { passive: false }

  );


  button.addEventListener(

    "touchcancel",

    function(event) {

      event.preventDefault();

      stopMove();

    },

    { passive: false }

  );


  // ================= MOUSE =================

  button.addEventListener(

    "mousedown",

    function(event) {

      event.preventDefault();

      startMove(direction);

    }

  );


  button.addEventListener(

    "mouseup",

    function(event) {

      event.preventDefault();

      stopMove();

    }

  );


  button.addEventListener(

    "mouseleave",

    function() {

      stopMove();

    }

  );

}


// ======================================================
// AUTO LED MODE
// ======================================================

document

  .getElementById("autoMode")

  .addEventListener("click", function() {

    currentLedMode = "auto";


    document

      .getElementById("autoMode")

      .classList.add("active");


    document

      .getElementById("manualMode")

      .classList.remove("active");


    fetch("/ledauto")

      .catch(() => {});

  });


// ======================================================
// MANUAL LED MODE
// ======================================================

document

  .getElementById("manualMode")

  .addEventListener("click", function() {

    currentLedMode = "manual";


    document

      .getElementById("manualMode")

      .classList.add("active");


    document

      .getElementById("autoMode")

      .classList.remove("active");


    fetch("/ledmanual")

      .catch(() => {});

  });


// ======================================================
// ALL LED BUTTON
// ======================================================

document

  .getElementById("allLed")

  .addEventListener("click", function() {


    if (currentLedMode !== "manual") {

      return;

    }


    allLedState = !allLedState;


    const button =
      document.getElementById("allLed");


    if (allLedState) {

      button.innerHTML = "ALL LEDs ON";

      button.classList.add("on");


      fetch("/ledon")

        .catch(() => {});

    }

    else {

      button.innerHTML = "ALL LEDs OFF";

      button.classList.remove("on");


      fetch("/ledoff")

        .catch(() => {});

    }

  });


// ======================================================
// CREATE MOVEMENT BUTTONS
// ======================================================

setupButton("forward", "forward");

setupButton("backward", "backward");

setupButton("left", "left");

setupButton("right", "right");


// ======================================================
// STOP BUTTON
// ======================================================

document

  .getElementById("stop")

  .addEventListener(

    "click",

    function() {

      stopMove();

    }

  );


// ======================================================
// BROWSER SAFETY
// ======================================================

window.addEventListener(

  "blur",

  function() {

    stopMove();

  }

);


</script>

</body>

</html>

)rawliteral";


// ======================================================
// SERVER HANDLERS
// ======================================================

void handleRoot() {

  server.sendHeader(
    "Cache-Control",
    "no-cache, no-store, must-revalidate"
  );

  server.sendHeader(
    "Pragma",
    "no-cache"
  );

  server.sendHeader(
    "Expires",
    "0"
  );


  server.send(
    200,
    "text/html; charset=UTF-8",
    webpage
  );

}


// ======================================================
// MOVEMENT HANDLERS
// ======================================================

void handleForward() {

  forward();

  lastCommandTime = millis();

  server.send(
    200,
    "text/plain",
    "FORWARD"
  );

}


void handleBackward() {

  backward();

  lastCommandTime = millis();

  server.send(
    200,
    "text/plain",
    "BACKWARD"
  );

}


void handleLeft() {

  left();

  lastCommandTime = millis();

  server.send(
    200,
    "text/plain",
    "LEFT"
  );

}


void handleRight() {

  right();

  lastCommandTime = millis();

  server.send(
    200,
    "text/plain",
    "RIGHT"
  );

}


void handleStop() {

  stopCar();

  lastCommandTime = millis();

  server.send(
    200,
    "text/plain",
    "STOP"
  );

}


// ======================================================
// LED MODE HANDLERS
// ======================================================

void handleLedAuto() {

  ledMode = 0;

  allLedsOff();

  server.send(
    200,
    "text/plain",
    "AUTO"
  );

}


void handleLedManual() {

  ledMode = 1;

  updateManualLEDs();

  server.send(
    200,
    "text/plain",
    "MANUAL"
  );

}


void handleLedOn() {

  ledMode = 1;

  allLedsOn = true;

  allLedsOnFunction();

  server.send(
    200,
    "text/plain",
    "LED ON"
  );

}


void handleLedOff() {

  ledMode = 1;

  allLedsOn = false;

  allLedsOff();

  server.send(
    200,
    "text/plain",
    "LED OFF"
  );

}


// ======================================================
// SETUP
// ======================================================

void setup() {

  Serial.begin(115200);


  // ================= MOTOR PINS =================

  pinMode(IP1, OUTPUT);
  pinMode(IP2, OUTPUT);

  pinMode(IP3, OUTPUT);
  pinMode(IP4, OUTPUT);


  digitalWrite(IP1, LOW);
  digitalWrite(IP2, LOW);
  digitalWrite(IP3, LOW);
  digitalWrite(IP4, LOW);
  // ================= LED PINS =================

  pinMode(ledf1, OUTPUT);
  pinMode(ledf2, OUTPUT);

  pinMode(ledb1, OUTPUT);
  pinMode(ledb2, OUTPUT);


  // Start motors and LEDs OFF

  stopCar();


  // ================= WIFI =================

  WiFi.mode(WIFI_AP);

  WiFi.setSleep(false);


  WiFi.softAP(
    ssid,
    password
  );


  Serial.println();

  Serial.println("==============================");

  Serial.println("ESP32 WIFI ROBOT");

  Serial.println("==============================");

  Serial.print("WiFi Name: ");

  Serial.println(ssid);

  Serial.print("IP Address: ");

  Serial.println(
    WiFi.softAPIP()
  );

  Serial.println();


  // ================= SERVER ROUTES =================

  server.on(
    "/",
    handleRoot
  );


  server.on(
    "/forward",
    handleForward
  );


  server.on(
    "/backward",
    handleBackward
  );


  server.on(
    "/left",
    handleLeft
  );


  server.on(
    "/right",
    handleRight
  );


  server.on(
    "/stop",
    handleStop
  );


  // ================= LED ROUTES =================

  server.on(
    "/ledauto",
    handleLedAuto
  );


  server.on(
    "/ledmanual",
    handleLedManual
  );


  server.on(
    "/ledon",
    handleLedOn
  );


  server.on(
    "/ledoff",
    handleLedOff
  );


  // ================= START SERVER =================

  server.begin();

  Serial.println("Web server started!");

}


// ======================================================
// LOOP
// ======================================================

void loop() {

  server.handleClient();


  // ================= SAFETY TIMEOUT =================

  if (
    millis() - lastCommandTime
    > commandTimeout
  ) {

    stopCar();

  }

}