
int bulb1 = 0;
int bulb2 = 1;
int bulb3 = 2;
int bulb4 = 3;
int bulb5 = 4;
int bulb6 = 5;
int bulb7 = 6;
int bulb8 = 7;



void setup() {
  
   pinMode(bulb1,OUTPUT);
   pinMode(bulb2,OUTPUT);
   pinMode(bulb3,OUTPUT);
   pinMode(bulb4,OUTPUT);
   pinMode(bulb5,OUTPUT);
   pinMode(bulb6,OUTPUT);
   pinMode(bulb7,OUTPUT);
   pinMode(bulb8,OUTPUT);
   
}

void loop() 
{
  
 effect_1();
 effect_1();
  
 effect_2();
 effect_2();
  
 effect_3();
 effect_3();
  
 effect_4();
 effect_4();
 
 effect_5();
 effect_5();


 effect_6();
 effect_6();


 effect_7();
 effect_7();

 effect_8();
 effect_8();
 
 effect_9();
 effect_9();

 effect_10();
 effect_10();

 effect_11();
 effect_11();

 effect_12();
 effect_12();

 effect_13();
 effect_13();

 effect_14();
 effect_14();

 effect_15();
 effect_15();


 
 
}

/////////////pattern 1///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_1()
{
  int t=150;
 
  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
 

  //////////////////////////////////
  
  
  
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);
   


  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
 

  //////////////////////////////////
  
  
  
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);
 
}

/////////////pattern 2///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_2()
{
  int t=150;
 
  digitalWrite(bulb1,HIGH);
  delay(t);
  digitalWrite(bulb1,LOW);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8,HIGH);
   delay(t);
 
  digitalWrite(bulb1, LOW);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8, LOW);


///////////////////////////////////////////

  digitalWrite(bulb1,HIGH);
  delay(t);
  digitalWrite(bulb1,LOW);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8,HIGH);
  delay(t);
 
  digitalWrite(bulb1, LOW);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8, LOW);
 
////////////////////////////////////////

  digitalWrite(bulb1,HIGH);
  delay(t);
  digitalWrite(bulb1,LOW);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8,HIGH);
  delay(t);
 
  digitalWrite(bulb1, LOW);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  digitalWrite(bulb6,LOW);
  digitalWrite(bulb7,LOW);
  digitalWrite(bulb8, LOW);
   
}


/////////////pattern 3///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_3()
{
  int t=150;
 
  digitalWrite(bulb1,LOW);
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb8,LOW);
  delay(t);
 
  digitalWrite(bulb1, HIGH);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb8, HIGH);


//////////////////////////////////////

  digitalWrite(bulb1,LOW);
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb8,LOW);
  delay(t);
 
  digitalWrite(bulb1, HIGH);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb8, HIGH);


///////////////////////////////////////////

 digitalWrite(bulb1,LOW);
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb8,LOW);
   delay(t);
 
digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);


}

/////////////pattern 4///////////////////////////////////////////////////////////////////////////////////////////////////KKKKKKKKKKKKKK
void effect_4()
{
  int t=150;

  digitalWrite(bulb1, HIGH );

  digitalWrite(bulb3,HIGH);
  
  digitalWrite(bulb5,HIGH);

   digitalWrite(bulb7,HIGH);

  
 
  digitalWrite(bulb2,LOW);
  
  digitalWrite(bulb4,LOW);
  
  digitalWrite(bulb6,LOW);
  
  digitalWrite(bulb8,LOW);
  
  delay(t);
////////////////
 digitalWrite(bulb1, LOW );

  digitalWrite(bulb3,LOW);
 
  digitalWrite(bulb5,LOW);
 
  digitalWrite(bulb7,LOW);
 
  
  digitalWrite(bulb2,HIGH);
  
  digitalWrite(bulb4,HIGH);

  digitalWrite(bulb6,HIGH);
  
  digitalWrite(bulb8,HIGH);
  
  
  delay(t);

///////////////////////////////////////////////////////////////////


  digitalWrite(bulb1, HIGH );

  digitalWrite(bulb3,HIGH);
  
  digitalWrite(bulb5,HIGH);

  digitalWrite(bulb7,HIGH);

  
 
  digitalWrite(bulb2,LOW);
  
  digitalWrite(bulb4,LOW);
  
  digitalWrite(bulb6,LOW);
  
  digitalWrite(bulb8,LOW);
  
  delay(t);
////////////////
 digitalWrite(bulb1, LOW );

  digitalWrite(bulb3,LOW);
 
  digitalWrite(bulb5,LOW);
 
  digitalWrite(bulb7,LOW);
 
  
  digitalWrite(bulb2,HIGH);
  
  digitalWrite(bulb4,HIGH);

  digitalWrite(bulb6,HIGH);
  
  digitalWrite(bulb8,HIGH);
  
  
  delay(t);


  
  digitalWrite(bulb1, HIGH );

  digitalWrite(bulb3,HIGH);
  
  digitalWrite(bulb5,HIGH);

   digitalWrite(bulb7,HIGH);

  
 
  digitalWrite(bulb2,LOW);
  
  digitalWrite(bulb4,LOW);
  
  digitalWrite(bulb6,LOW);
  
  digitalWrite(bulb8,LOW);
  
  delay(t);
////////////////
 digitalWrite(bulb1, LOW );

  digitalWrite(bulb3,LOW);
 
  digitalWrite(bulb5,LOW);
 
   digitalWrite(bulb7,LOW);
 
  
  digitalWrite(bulb2,HIGH);
  
  digitalWrite(bulb4,HIGH);

  digitalWrite(bulb6,HIGH);
  
  digitalWrite(bulb8,HIGH);
  
  
  delay(t);

   digitalWrite(bulb1, HIGH );

  digitalWrite(bulb3,HIGH);
  
  digitalWrite(bulb5,HIGH);

  digitalWrite(bulb7,HIGH);

  
 
  digitalWrite(bulb2,LOW);
  
  digitalWrite(bulb4,LOW);
  
  digitalWrite(bulb6,LOW);
  
  digitalWrite(bulb8,LOW);
  
  delay(t);
////////////////
 digitalWrite(bulb1, LOW );

  digitalWrite(bulb3,LOW);
 
  digitalWrite(bulb5,LOW);
 
  digitalWrite(bulb7,LOW);
 
  
  digitalWrite(bulb2,HIGH);
  
  digitalWrite(bulb4,HIGH);

  digitalWrite(bulb6,HIGH);
  
  digitalWrite(bulb8,HIGH);
  
  
  delay(t);

digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);

  delay(t);


}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 5///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_5()
{
  int t=150;

  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
  
  
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);
  


 
  digitalWrite(bulb8,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb1,HIGH);
  delay(t);


  digitalWrite(bulb8,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb1,LOW);
  delay(t);



digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
  
  
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);
  


 
  digitalWrite(bulb8,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb1,HIGH);
  delay(t);


  digitalWrite(bulb8,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb1,LOW);
  delay(t);




digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);


}

/////////////pattern 6///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_6()
{
  int t=150;

  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  delay(t);
  

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb8, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb6, LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  delay(t);

  ////////////////


  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  delay(t);
  

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb8, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb6, LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  delay(t);

  //////////////

  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  delay(t);
  

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb8, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb6, LOW);
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  delay(t);
}


/////////////pattern 7///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_7()
{
  int t=150;

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb8, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  delay(t);
  

  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb6, HIGH);
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  delay(t);



  digitalWrite(bulb1, LOW );
  digitalWrite(bulb8, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb5,LOW);
  delay(t);
  

  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb6, HIGH);
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb5,HIGH);
  delay(t);
  
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 8///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_8()
{
  int t=200;


digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
delay(t);

digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

delay(t);


digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
delay(t);

digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

delay(t);



digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
delay(t);

digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

delay(t);



digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
delay(t);

digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

delay(t);


}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 9///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_9()
{
  int t=150;

  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb1, LOW );
  delay(t);

  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb2, LOW );
  delay(t);

  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

   digitalWrite(bulb7,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

   digitalWrite(bulb8,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

  

  digitalWrite(bulb7, LOW );
  delay(t);

  digitalWrite(bulb8, LOW );
  delay(t);

  
  digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb7, HIGH );
  delay(t);

  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb5 ,HIGH);
  digitalWrite(bulb7, LOW );
  delay(t);

 digitalWrite(bulb4,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

   

  digitalWrite(bulb2, LOW );
  delay(t);

  digitalWrite(bulb1, LOW );
  delay(t);



////////////////////////////



  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb1, LOW );
  delay(t);

  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb2, LOW );
  delay(t);

  digitalWrite(bulb5,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

  digitalWrite(bulb6,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

  digitalWrite(bulb7,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

   digitalWrite(bulb8,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

  

digitalWrite(bulb7, LOW );
  delay(t);

digitalWrite(bulb8, LOW );
  delay(t);

  
digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb7, HIGH );
  delay(t);

digitalWrite(bulb6,HIGH);
  digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb5 ,HIGH);
  digitalWrite(bulb7, LOW );
  delay(t);

 digitalWrite(bulb4,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

 digitalWrite(bulb3,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

   digitalWrite(bulb2,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

   digitalWrite(bulb1,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

   

digitalWrite(bulb2, LOW );
  delay(t);

digitalWrite(bulb1, LOW );
  delay(t);


//////////////////////////////////////


  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb1, LOW );
  delay(t);

  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb2, LOW );
  delay(t);

 digitalWrite(bulb5,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

 digitalWrite(bulb6,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

   digitalWrite(bulb7,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

   digitalWrite(bulb8,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

  

digitalWrite(bulb7, LOW );
  delay(t);

digitalWrite(bulb8, LOW );
  delay(t);

  
digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb7, HIGH );
  delay(t);

digitalWrite(bulb6,HIGH);
  digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb5 ,HIGH);
  digitalWrite(bulb7, LOW );
  delay(t);

 digitalWrite(bulb4,HIGH);
  digitalWrite(bulb6, LOW );
  delay(t);

 digitalWrite(bulb3,HIGH);
  digitalWrite(bulb5, LOW );
  delay(t);

   digitalWrite(bulb2,HIGH);
  digitalWrite(bulb4, LOW );
  delay(t);

   digitalWrite(bulb1,HIGH);
  digitalWrite(bulb3, LOW );
  delay(t);

   

digitalWrite(bulb2, LOW );
  delay(t);

digitalWrite(bulb1, LOW );
  delay(t);

  

}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 10///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_10()
{
  int t=150;

  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb1, HIGH );
  delay(t);

  digitalWrite(bulb4,LOW);
  digitalWrite(bulb2, HIGH );
  delay(t);

  digitalWrite(bulb5,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

  digitalWrite(bulb6,LOW);
  digitalWrite(bulb4, HIGH );
  delay(t);

   digitalWrite(bulb7,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb8,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

  

digitalWrite(bulb7, HIGH );
  delay(t);

digitalWrite(bulb8, HIGH );
  delay(t);

  
digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb7, LOW );
  delay(t);

digitalWrite(bulb6,LOW);
  digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb5 ,LOW);
  digitalWrite(bulb7, HIGH );
  delay(t);

 digitalWrite(bulb4,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

 digitalWrite(bulb3,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb2,LOW);
  digitalWrite(bulb4, HIGH);
  delay(t);

   digitalWrite(bulb1,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

   

digitalWrite(bulb2, HIGH );
  delay(t);

digitalWrite(bulb1, HIGH );
  delay(t);


//////////////////////////////////////////


  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb1, HIGH );
  delay(t);

  digitalWrite(bulb4,LOW);
  digitalWrite(bulb2, HIGH );
  delay(t);

 digitalWrite(bulb5,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

 digitalWrite(bulb6,LOW);
  digitalWrite(bulb4, HIGH );
  delay(t);

   digitalWrite(bulb7,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb8,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

  

digitalWrite(bulb7, HIGH );
  delay(t);

digitalWrite(bulb8, HIGH );
  delay(t);

  
digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb7, LOW );
  delay(t);

digitalWrite(bulb6,LOW);
  digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb5 ,LOW);
  digitalWrite(bulb7, HIGH );
  delay(t);

 digitalWrite(bulb4,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

 digitalWrite(bulb3,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb2,LOW);
  digitalWrite(bulb4, HIGH);
  delay(t);

   digitalWrite(bulb1,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

   

digitalWrite(bulb2, HIGH );
  delay(t);

digitalWrite(bulb1, HIGH );
  delay(t);


  ////////////////////////////////////////


  
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  
  digitalWrite(bulb3,LOW);
  digitalWrite(bulb1, HIGH );
  delay(t);

  digitalWrite(bulb4,LOW);
  digitalWrite(bulb2, HIGH );
  delay(t);

 digitalWrite(bulb5,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

 digitalWrite(bulb6,LOW);
  digitalWrite(bulb4, HIGH );
  delay(t);

   digitalWrite(bulb7,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb8,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

  

digitalWrite(bulb7, HIGH );
  delay(t);

digitalWrite(bulb8, HIGH );
  delay(t);

  
digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb7, LOW );
  delay(t);

digitalWrite(bulb6,LOW);
  digitalWrite(bulb8, HIGH );
  delay(t);

  digitalWrite(bulb5 ,LOW);
  digitalWrite(bulb7, HIGH );
  delay(t);

 digitalWrite(bulb4,LOW);
  digitalWrite(bulb6, HIGH );
  delay(t);

 digitalWrite(bulb3,LOW);
  digitalWrite(bulb5, HIGH );
  delay(t);

   digitalWrite(bulb2,LOW);
  digitalWrite(bulb4, HIGH);
  delay(t);

   digitalWrite(bulb1,LOW);
  digitalWrite(bulb3, HIGH );
  delay(t);

   

digitalWrite(bulb2, HIGH );
  delay(t);

digitalWrite(bulb1, HIGH );
  delay(t);


}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 11///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_11()
{
  int t=150;

  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
 

  //////////////////////////////////
  
  digitalWrite(bulb8,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
   digitalWrite(bulb5,LOW);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
    digitalWrite(bulb1, LOW );
  delay(t);




  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);
 

  //////////////////////////////////
  
  digitalWrite(bulb8,LOW);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
   digitalWrite(bulb5,LOW);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
    digitalWrite(bulb1, LOW );
  delay(t);

}
  
  
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 12///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_12()
{
  int t=150;

  digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb8,HIGH);
  delay(t);


///

  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
////

  digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);

////

  digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);


////

  digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);
  digitalWrite(bulb3,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);



  digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
 
  digitalWrite(bulb3,HIGH);
  delay(t);


 digitalWrite(bulb1, HIGH );
  delay(t);
   digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);

   digitalWrite(bulb1, HIGH );
  delay(t);
  

digitalWrite(bulb1, LOW);
digitalWrite(bulb2,LOW);
digitalWrite(bulb3,LOW);
digitalWrite(bulb4,LOW);
digitalWrite(bulb5,LOW);
digitalWrite(bulb6,LOW);
digitalWrite(bulb7,LOW);
digitalWrite(bulb8, LOW);

/////////////////////////////////////////



}  
   

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 13///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_13()
{
  int t=150;

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);


///

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);

  ////////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);

///////////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);


  ///////////

   digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);

 ///////////

      digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);

 digitalWrite(bulb1, LOW );
  delay(t);

  //////////////


  


digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
  delay(t);




  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
  digitalWrite(bulb7,HIGH);
  delay(t);
  digitalWrite(bulb8,LOW);
  delay(t);


///

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);
  digitalWrite(bulb6,HIGH);
  delay(t);
  digitalWrite(bulb7,LOW);
  delay(t);
////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);
  digitalWrite(bulb5,HIGH);
  delay(t);
  digitalWrite(bulb6,LOW);
  delay(t);

  ////////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);
   digitalWrite(bulb4,HIGH);
  delay(t);
  digitalWrite(bulb5,LOW);
  delay(t);

///////////

  digitalWrite(bulb1, LOW );
  delay(t);
   digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);
  digitalWrite(bulb3,HIGH);
  delay(t);
   digitalWrite(bulb4,LOW);
  delay(t);


  ///////////

  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb2,HIGH);
  delay(t);
 
  digitalWrite(bulb3,LOW);
  delay(t);

 ///////////

  digitalWrite(bulb1, LOW );
  delay(t);
  digitalWrite(bulb1, HIGH );
  delay(t);
  digitalWrite(bulb2,LOW);
  delay(t);
  digitalWrite(bulb1, LOW );
  delay(t);

  //////////////


  


digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);
  delay(t);


}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 14///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_14()
{
  int t=150;

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

  digitalWrite(bulb1, HIGH );
  digitalWrite(bulb5, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
   digitalWrite(bulb3,HIGH);
   digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb8, HIGH );
  delay(t);



  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

   digitalWrite(bulb1, HIGH );
  digitalWrite(bulb5, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
   digitalWrite(bulb3,HIGH);
   digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb8, HIGH );
  delay(t);



  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

   digitalWrite(bulb1, HIGH );
  digitalWrite(bulb5, HIGH );
  delay(t);
  digitalWrite(bulb2,HIGH);
  digitalWrite(bulb6, HIGH );
  delay(t);
   digitalWrite(bulb3,HIGH);
   digitalWrite(bulb7, HIGH );
  delay(t);
  digitalWrite(bulb4,HIGH);
  digitalWrite(bulb8, HIGH );
  delay(t);
 
  


  digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);



}


  ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////pattern 15///////////////////////////////////////////////////////////////////////////////////////////////////
void effect_15()
{
  int t=150;

  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

   digitalWrite(bulb4, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
   digitalWrite(bulb2,HIGH);
   digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb5, HIGH );
  delay(t);

/////////////////////////


  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

   digitalWrite(bulb4, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
   digitalWrite(bulb2,HIGH);
   digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb5, HIGH );
  delay(t);




  digitalWrite(bulb1, LOW );
  digitalWrite(bulb5, LOW );
  delay(t);
  digitalWrite(bulb2,LOW);
  digitalWrite(bulb6, LOW );
  delay(t);
   digitalWrite(bulb3,LOW);
   digitalWrite(bulb7, LOW );
  delay(t);
  digitalWrite(bulb4,LOW);
  digitalWrite(bulb8, LOW );
  delay(t);

   digitalWrite(bulb4, HIGH );
  digitalWrite(bulb8, HIGH );
  delay(t);
  digitalWrite(bulb3,HIGH);
  digitalWrite(bulb7, HIGH );
  delay(t);
   digitalWrite(bulb2,HIGH);
   digitalWrite(bulb6, HIGH );
  delay(t);
  digitalWrite(bulb1,HIGH);
  digitalWrite(bulb5, HIGH );
  delay(t);


  


digitalWrite(bulb1, HIGH);
digitalWrite(bulb2,HIGH);
digitalWrite(bulb3,HIGH);
digitalWrite(bulb4,HIGH);
digitalWrite(bulb5,HIGH);
digitalWrite(bulb6,HIGH);
digitalWrite(bulb7,HIGH);
digitalWrite(bulb8, HIGH);


}
