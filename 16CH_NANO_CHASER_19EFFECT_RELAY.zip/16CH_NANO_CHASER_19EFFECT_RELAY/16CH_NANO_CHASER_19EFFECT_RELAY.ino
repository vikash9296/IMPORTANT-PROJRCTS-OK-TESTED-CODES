#include <EEPROM.h>

// रिले पिंस (IN1 से IN16 तक Arduino के पिन 2 से 17 पर)
const int relayPins[16] = {2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17};

// पोटेंशियोमीटर (A4) और पुश-बटन (A5)
const int speedPotPin = A4;   
const int modeButtonPin = A5; 

int currentMode = 1;          // गिनती 1 से शुरू
const int totalModes = 19;    // कुल 19 मोड्स

unsigned long lastStepTime = 0;
int stepIndex = 0;

// EEPROM एड्रेस
const int eeAddressMode = 0;
const int eeAddressStep = 2; 
const int eeAddressAuto = 4;  // ऑटो-मोड स्टेट सेव करने के लिए नया एड्रेस

// ऑटो-चेंज मोड के लिए वेरिएबल्स
bool isAutoMode = false;
unsigned long lastAutoChangeTime = 0;
const unsigned long autoChangeInterval = 30000; // 30 सेकंड

// लॉन्ग प्रेस (2.5 सेकंड) के लिए वेरिएबल्स
unsigned long buttonDownTime = 0;
bool buttonPressHandled = false;
int lastButtonState = HIGH;
int buttonState = HIGH;
unsigned long lastDebounceTime = 0;
unsigned long debounceDelay = 50; 

// मोड 4 के लिए अलग-अलग स्टेप्स
int leftStep = 0;
int rightStep = 15;

// एक्यूमुलेटर के लिए स्टेट वेरिएबल्स
bool fillingState = true;     
bool accDirection = true;     

// पार्किंग/फिलिंग के लिए वेरिएबल्स
int fillLimit = 15;          
int revFillLimit = 0;        
bool parkMergeState = true;  

// मोड 8 के लिए वेरिएबल्स
int centerLeftLimit = 7;     
int centerRightLimit = 8;    
int centerStep = 0;

// मोड 9 के लिए वेरिएबल्स
int parkedLeftEnd = -1;      
int parkedRightEnd = 16;     
int chaserLeft = 7;          
int chaserRight = 8;         

// मोड 10 के लिए स्टेट वेरिएबल
bool blinkState = false;

// मोड 11 के लिए स्टेट वेरिएबल
bool oddEvenState = false;

// मोड 12 के लिए वेरिएबल्स
bool mode12Filling = true;     
bool mode12Direction = true;   
int mode12Step = 0;
int mode12BlinkCount = 0;
bool mode12BlinkState = false;

// मोड 13 के लिए वेरिएबल्स
bool mode13OddTurn = true;     
int mode13BlinkCount = 0;
bool mode13BlinkPhase = false; 

// मोड 14 के लिए वेरिएबल्स
int mode14Step = 0;            
bool mode14Dir = true;         
int mode14BlinkCount = 0;

// मोड 15 के लिए वेरिएबल्स
bool mode15Dir = true;         
bool mode15Fill = true;        
int mode15Step = 0;            
int mode15BlinkCount = 0;
bool mode15BlinkState = false;

// मोड 16 के लिए वेरिएबल्स
int mode16Pos = 0;             
bool mode16Dir = true;         

// मोड 17 के लिए वेरिएबल्स
int mode17Step = 0;            

// मोड 19 के लिए वेरिएबल्स
int mode19Step = 0;            

// allOff फंक्शन की डिक्लेरेशन
void allOff();
void resetVariables();
void runMode(int modeNo, int spd);
void saveStateToEEPROM();

void setup() {
  for (int i = 0; i < 16; i++) {
    pinMode(relayPins[i], OUTPUT);
    digitalWrite(relayPins[i], HIGH); // रिले एक्टिव-LOW होने के कारण शुरू में बंद रहेंगी
  }
  
  pinMode(modeButtonPin, INPUT_PULLUP);
  randomSeed(analogRead(A0));

  // 1. EEPROM से पिछला मोड, स्टेप और ऑटो-स्टेट पढ़ना
  EEPROM.get(eeAddressMode, currentMode);
  EEPROM.get(eeAddressStep, stepIndex);
  
  byte savedAutoState = EEPROM.read(eeAddressAuto);
  if (savedAutoState == 1) {
    isAutoMode = true;
  } else {
    isAutoMode = false;
  }

  // सेफ्टी चेक
  if (currentMode < 1 || currentMode > totalModes) {
    currentMode = 1;
    stepIndex = 0;
    isAutoMode = false;
  }
  
  lastAutoChangeTime = millis(); // टाइमर रिफ्रेश ताकि लाइट आते ही तुरंत टाइम काउंट न हो जाए
}

void loop() {
  // 1. A4 से स्पीड पढ़ना (30ms से 250ms तक)
  int potSpeed = analogRead(speedPotPin);
  int spd = map(potSpeed, 0, 1023, 30, 250);

  // ग्रुप इफेक्ट्स के लिए थोड़ा बेस डिले जोड़ना
  if (currentMode >= 4 && currentMode < 10) {
    spd = spd + 30; 
  } else if (currentMode >= 12 && currentMode < 16) {
    spd = 120; 
  }

  // 2. ऑटो-चेंज मोड लॉजिक (हर 30 सेकंड में अगला मोड)
  if (isAutoMode) {
    if (millis() - lastAutoChangeTime >= autoChangeInterval) {
      lastAutoChangeTime = millis();
      currentMode++;
      if (currentMode > totalModes) {
        currentMode = 1;
      }
      resetVariables();
      allOff();
      saveStateToEEPROM(); 
    }
  }

  // 3. बटन रीडिंग और लॉन्ग प्रेस / शॉर्ट प्रेस का हिसाब
  int reading = digitalRead(modeButtonPin);

  if (reading != lastButtonState) {
    lastDebounceTime = millis(); 
  }

  if ((millis() - lastDebounceTime) > debounceDelay) {
    if (reading != buttonState) {
      buttonState = reading;
      
      if (buttonState == LOW) {
        buttonDownTime = millis();
        buttonPressHandled = false;
      } else {
        if (!buttonPressHandled) {
          if (isAutoMode) {
            isAutoMode = false; // मैनुअल मोड पर वापस आना
          }
          currentMode++;
          if (currentMode > totalModes) {
            currentMode = 1; 
          }
          resetVariables();
          allOff();
          saveStateToEEPROM(); 
        }
      }
    }
  }
  lastButtonState = reading;

  // 4. चेक करो कि क्या बटन को 2.5 सेकंड तक दबाकर रखा गया है (لॉन्ग प्रेस)
  if (buttonState == LOW && !buttonPressHandled) {
    if (millis() - buttonDownTime >= 2500) { 
      buttonPressHandled = true; 
      isAutoMode = true;         
      lastAutoChangeTime = millis();

      // कन्फर्मेशन के लिए सारी एलईडी दो बार एक साथ ब्लिंक करेंगी
      for (int b = 0; b < 2; b++) {
        allOff();
        delay(150);
        for (int i = 0; i < 16; i++) {
          digitalWrite(relayPins[i], LOW);
        }
        delay(150);
      }
      allOff();
      resetVariables();
      saveStateToEEPROM();
    }
  }

  // 5. चुने हुए मोड को चलाना
  runMode(currentMode, spd);
}

// EEPROM में मोड, स्टेप और ऑटो-स्टेट सेव करने का फंक्शन
void saveStateToEEPROM() {
  int storedMode;
  EEPROM.get(eeAddressMode, storedMode);
  byte storedAuto = EEPROM.read(eeAddressAuto);
  byte currentAutoVal = isAutoMode ? 1 : 0;
  
  // तभी राइट करें जब डेटा बदला हो (सेफ्टी के लिए)
  if (storedMode != currentMode || storedAuto != currentAutoVal) {
    EEPROM.put(eeAddressMode, currentMode);
    EEPROM.put(eeAddressStep, stepIndex);
    EEPROM.write(eeAddressAuto, currentAutoVal);
  }
}

void resetVariables() {
  if (currentMode == 2) {
    stepIndex = 15; 
  } else {
    stepIndex = 0;  
  }
  leftStep = 0;
  rightStep = 15;
  fillingState = true;
  accDirection = true;
  fillLimit = 15;
  revFillLimit = 0;
  parkMergeState = true;
  centerLeftLimit = 7;
  centerRightLimit = 8;
  centerStep = 0;
  parkedLeftEnd = -1;
  parkedRightEnd = 16;
  blinkState = false;
  oddEvenState = false;
  
  mode12Filling = true;
  mode12Direction = true;
  mode12Step = 0;
  mode12BlinkCount = 0;

  mode13OddTurn = true;
  mode13BlinkCount = 0;

  mode14Step = 0;
  mode14Dir = true;
  mode14BlinkCount = 0;

  mode15Dir = true;
  mode15Fill = true;
  mode15Step = 0;
  mode15BlinkCount = 0;

  mode16Pos = 0;
  mode16Dir = true;

  mode17Step = 0;
  mode19Step = 0;
  
  saveStateToEEPROM(); 
}

void runMode(int modeNo, int spd) {
  if (millis() - lastStepTime < spd) return;
  lastStepTime = millis();

  switch (modeNo) {
    case 1: { 
      if (fillingState) {
        digitalWrite(relayPins[stepIndex], LOW); 
        stepIndex++; 
        if (stepIndex >= 16) { fillingState = false; stepIndex = 0; } 
      } else {
        digitalWrite(relayPins[stepIndex], HIGH); 
        stepIndex++; 
        if (stepIndex >= 16) { fillingState = true; stepIndex = 0; allOff(); } 
      }
      break;
    }

    case 2: { 
      if (fillingState) {
        digitalWrite(relayPins[stepIndex], LOW); 
        stepIndex--; 
        if (stepIndex < 0) { fillingState = false; stepIndex = 15; } 
      } else {
        digitalWrite(relayPins[stepIndex], HIGH); 
        stepIndex--; 
        if (stepIndex < 0) { fillingState = true; stepIndex = 15; allOff(); } 
      }
      break;
    }

    case 3: { 
      if (accDirection) {
        if (fillingState) {
          digitalWrite(relayPins[stepIndex], LOW); 
          stepIndex++; 
          if (stepIndex >= 16) { fillingState = false; stepIndex = 0; } 
        } else {
          digitalWrite(relayPins[stepIndex], HIGH); 
          stepIndex++; 
          if (stepIndex >= 16) { fillingState = true; stepIndex = 15; allOff(); accDirection = false; } 
        }
      } else {
        if (fillingState) {
          digitalWrite(relayPins[stepIndex], LOW); 
          stepIndex--; 
          if (stepIndex < 0) { fillingState = false; stepIndex = 15; } 
        } else {
          digitalWrite(relayPins[stepIndex], HIGH); 
          stepIndex--; 
          if (stepIndex < 0) { fillingState = true; stepIndex = 0; allOff(); accDirection = true; } 
        }
      }
      break;
    }

    case 4: {
      allOff();
      int gSize = 2; 
      for (int i = 0; i < gSize; i++) {
        int pos = leftStep + i;
        if (pos < 16) digitalWrite(relayPins[pos], LOW);
      }
      for (int i = 0; i < gSize; i++) {
        int pos = rightStep - i;
        if (pos >= 0) digitalWrite(relayPins[pos], LOW);
      }
      leftStep++;
      if (leftStep > (16 - gSize)) leftStep = 0; 
      rightStep--;
      if (rightStep < (gSize - 1)) rightStep = 15; 
      break;
    }

    case 5: {
      for (int i = 0; i < 16; i++) {
        if (i > fillLimit) digitalWrite(relayPins[i], LOW); 
        else digitalWrite(relayPins[i], HIGH);
      }
      digitalWrite(relayPins[stepIndex], LOW); 
      stepIndex++;
      if (stepIndex > fillLimit) {
        stepIndex = 0; 
        fillLimit--;   
        if (fillLimit < 0) { allOff(); fillLimit = 15; }
      }
      break;
    }

    case 6: {
      for (int i = 0; i < 16; i++) {
        if (i < revFillLimit) digitalWrite(relayPins[i], LOW); 
        else digitalWrite(relayPins[i], HIGH);
      }
      digitalWrite(relayPins[15 - stepIndex], LOW); 
      stepIndex++;
      if (stepIndex > (15 - revFillLimit)) {
        stepIndex = 0; 
        revFillLimit++; 
        if (revFillLimit > 15) { allOff(); revFillLimit = 0; }
      }
      break;
    }

    case 7: {
      if (parkMergeState) {
        for (int i = 0; i < 16; i++) {
          if (i > fillLimit) digitalWrite(relayPins[i], LOW); 
          else digitalWrite(relayPins[i], HIGH); 
        }
        digitalWrite(relayPins[stepIndex], LOW); 
        stepIndex++;
        if (stepIndex > fillLimit) { 
          stepIndex = 0; 
          fillLimit--; 
          if (fillLimit < 0) { allOff(); fillLimit = 15; parkMergeState = false; } 
        }
      } else {
        for (int i = 0; i < 16; i++) {
          if (i < revFillLimit) digitalWrite(relayPins[i], LOW); 
          else digitalWrite(relayPins[i], HIGH); 
        }
        digitalWrite(relayPins[15 - stepIndex], LOW); 
        stepIndex++;
        if (stepIndex > (15 - revFillLimit)) { 
          stepIndex = 0; 
          revFillLimit++; 
          if (revFillLimit > 15) { allOff(); revFillLimit = 0; parkMergeState = true; } 
        }
      }
      break;
    }

    case 8: {
      for (int i = 0; i < 16; i++) {
        if (i > centerLeftLimit && i < centerRightLimit) {
          digitalWrite(relayPins[i], LOW); 
        } else {
          digitalWrite(relayPins[i], HIGH);
        }
      }
      int currentLeftPos = centerStep;                  
      int currentRightPos = 15 - centerStep;            
      if (currentLeftPos <= centerLeftLimit) digitalWrite(relayPins[currentLeftPos], LOW);
      if (currentRightPos >= centerRightLimit) digitalWrite(relayPins[currentRightPos], LOW);
      centerStep++;
      if (centerStep > centerLeftLimit) {
        centerStep = 0;
        centerLeftLimit--;   
        centerRightLimit++;  
        if (centerLeftLimit < 0) {
          allOff();
          centerLeftLimit = 7;
          centerRightLimit = 8;
        }
      }
      break;
    }

    case 9: {
      for (int i = 0; i < 16; i++) {
        if (i <= parkedLeftEnd || i >= parkedRightEnd) {
          digitalWrite(relayPins[i], LOW); 
        } else {
          digitalWrite(relayPins[i], HIGH);
        }
      }
      if (chaserLeft >= 0 && chaserLeft < 16) digitalWrite(relayPins[chaserLeft], LOW);
      if (chaserRight >= 0 && chaserRight < 16) digitalWrite(relayPins[chaserRight], LOW);
      chaserLeft--;
      chaserRight++;
      if (chaserLeft < (parkedLeftEnd + 1)) {
        parkedLeftEnd++;   
        parkedRightEnd--;  
        chaserLeft = 7;
        chaserRight = 8;
        if (parkedLeftEnd >= 7) {
          allOff();
          parkedLeftEnd = -1;
          parkedRightEnd = 16;
        }
      }
      break;
    }

    case 10: {
      blinkState = !blinkState; 
      for (int i = 0; i < 16; i++) {
        if (blinkState) digitalWrite(relayPins[i], LOW);  
        else digitalWrite(relayPins[i], HIGH); 
      }
      break;
    }

    case 11: {
      oddEvenState = !oddEvenState; 
      for (int i = 0; i < 16; i++) {
        if (oddEvenState) {
          if (i % 2 == 0) digitalWrite(relayPins[i], LOW);
          else digitalWrite(relayPins[i], HIGH);
        } else {
          if (i % 2 != 0) digitalWrite(relayPins[i], LOW);
          else digitalWrite(relayPins[i], HIGH);
        }
      }
      break;
    }

    case 12: {
      int targetPin = mode12Direction ? mode12Step : (15 - mode12Step);
      if (mode12Filling) {
        digitalWrite(relayPins[targetPin], LOW);
        mode12Step++;
        if (mode12Step >= 16) {
          mode12Filling = false; 
          mode12Step = 0;
          mode12BlinkCount = 0;
        }
      } else {
        if (mode12BlinkCount < 3) {
          mode12BlinkState = !mode12BlinkState;
          if (mode12BlinkState) digitalWrite(relayPins[targetPin], LOW);
          else {
            digitalWrite(relayPins[targetPin], HIGH);
            mode12BlinkCount++;
          }
        } else {
          digitalWrite(relayPins[targetPin], HIGH); 
          mode12BlinkState = false;
          mode12BlinkCount = 0;
          mode12Step++;
          if (mode12Step >= 16) {
            mode12Filling = true;     
            mode12Step = 0;
            mode12Direction = !mode12Direction;  
            allOff();
          }
        }
      }
      break;
    }

    case 13: {
      if (mode13BlinkCount < 6) {
        mode13BlinkPhase = !mode13BlinkPhase;
        for (int i = 0; i < 16; i++) {
          if (mode13OddTurn) {
            if (i % 2 == 0) digitalWrite(relayPins[i], mode13BlinkPhase ? HIGH : LOW);
          } else {
            if (i % 2 != 0) digitalWrite(relayPins[i], mode13BlinkPhase ? HIGH : LOW);
          }
        }
        mode13BlinkCount++;
      } else {
        allOff();
        for (int i = 0; i < 16; i++) {
          if (mode13OddTurn) {
            if (i % 2 == 0) digitalWrite(relayPins[i], LOW);  
          } else {
            if (i % 2 != 0) digitalWrite(relayPins[i], LOW);  
          }
        }
        mode13BlinkCount = 0;
        mode13OddTurn = !mode13OddTurn;
      }
      break;
    }

    case 14: {
      for (int i = 0; i < 16; i++) digitalWrite(relayPins[i], LOW);
      int activePin = mode14Dir ? mode14Step : (15 - mode14Step);
      static bool m14Toggle = false;
      m14Toggle = !m14Toggle;
      if (m14Toggle) digitalWrite(relayPins[activePin], HIGH);
      else {
        digitalWrite(relayPins[activePin], LOW);
        mode14BlinkCount++;
      }
      if (mode14BlinkCount >= 3) {
        mode14BlinkCount = 0;
        mode14Step++;
        if (mode14Step >= 16) {
          mode14Step = 0;
          mode14Dir = !mode14Dir; 
        }
      }
      break;
    }

    case 15: {
      int targetPin = mode15Dir ? mode15Step : (15 - mode15Step);
      if (mode15Fill) {
        if (mode15BlinkCount < 3) {
          mode15BlinkState = !mode15BlinkState;
          if (mode15BlinkState) digitalWrite(relayPins[targetPin], LOW);
          else {
            digitalWrite(relayPins[targetPin], HIGH);
            mode15BlinkCount++;
          }
        } else {
          digitalWrite(relayPins[targetPin], LOW); 
          mode15BlinkState = false;
          mode15BlinkCount = 0;
          mode15Step++;
          if (mode15Step >= 16) {
            mode15Fill = false; 
            mode15Step = 0;
          }
        }
      } else {
        if (mode15BlinkCount < 3) {
          mode15BlinkState = !mode15BlinkState;
          if (mode15BlinkState) digitalWrite(relayPins[targetPin], HIGH);
          else {
            digitalWrite(relayPins[targetPin], LOW);
            mode15BlinkCount++;
          }
        } else {
          digitalWrite(relayPins[targetPin], HIGH); 
          mode15BlinkState = false;
          mode15BlinkCount = 0;
          mode15Step++;
          if (mode15Step >= 16) {
            mode15Fill = true;      
            mode15Step = 0;
            mode15Dir = !mode15Dir; 
            allOff();
          }
        }
      }
      break;
    }

    case 16: {
      allOff(); 
      digitalWrite(relayPins[mode16Pos], LOW);
      if (mode16Dir) {
        mode16Pos++;
        if (mode16Pos >= 15) mode16Dir = false; 
      } else {
        mode16Pos--;
        if (mode16Pos <= 0) mode16Dir = true; 
      }
      break;
    }

    case 17: {
      allOff();
      for (int i = 0; i < 16; i++) {
        if ((i % 3) == mode17Step) digitalWrite(relayPins[i], LOW);
      }
      mode17Step++;
      if (mode17Step >= 3) mode17Step = 0; 
      break;
    }

    case 18: {
      allOff(); 
      int sparkleCount = random(3, 6); 
      for (int k = 0; k < sparkleCount; k++) {
        int randomPin = random(0, 16);
        digitalWrite(relayPins[randomPin], LOW);
      }
      break;
    }

    case 19: {
      allOff();
      int leftCenter = 7 - mode19Step;
      int rightCenter = 8 + mode19Step;
      if (leftCenter >= 0) digitalWrite(relayPins[leftCenter], LOW);
      if (rightCenter < 16) digitalWrite(relayPins[rightCenter], LOW);
      mode19Step++;
      if (mode19Step > 8) {
        mode19Step = 0; 
        allOff();
      }
      break;
    }
  }
}

void allOff() {
  for (int i = 0; i < 16; i++) {
    digitalWrite(relayPins[i], HIGH);
  }
}