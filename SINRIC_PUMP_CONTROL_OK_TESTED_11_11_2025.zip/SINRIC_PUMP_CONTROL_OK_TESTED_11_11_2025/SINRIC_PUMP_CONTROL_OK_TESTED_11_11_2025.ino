/*
  PumpController_Final_Fresh_BY_VIKASH_KUMAR_11_11_2025
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "c7303938-59fa-4ad2-a3de-e62d9bae9cec"
#define APP_SECRET    "c41c8855-b93b-496c-bf27-43f0f72c2dc8-4e754444-82cd-4acb-bb2c-c9cfe22b9b13"
#define DEVICE_ID_1   "6889cacbedeca866fe96e2ee"  // Pump ON
#define DEVICE_ID_2   "6889caffddd2551252ba8a70"  // Pump OFF
#define DEVICE_ID_3   "6890c55fedeca866fe994705"  // Auto Mode


// ------------------- Pins -------------------
#define RELAY1_PIN      19   // for motor start name in sinric app MOTOR
#define RELAY2_PIN      21  // for motor stop name in sinric app PUMP OFF
#define AUTO_MODE_LED   22  // this is auto mode on and off internally in sinric app AUTO MODE
#define WIFI_LED_PIN    2   // for wifi status LED
#define MANUAL_BTN_PIN  27  // this used for float sensor normally open to GND this trigger pump off automaticaly when water tank overflow
#define AUTO_TOGGLE_BTN 23  // Auto mode toggle mannaul push button to GND
#define BOOT_BTN_PIN    0   // On-board BOOT button (hold >5s to factory-reset Local wifi ap name to default and internet password reset WiFi/AP)

// ------------------- Constants -------------------
#define HOLD_TIME       5000    // ms (5s)
#define PULSE_TIME      2000    // ms (2s)
#define AUTO_DELAY      40000   // ms (40s)
#define DNS_PORT        53
#define WIFI_RETRY_MS   5000

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
unsigned long btnPressStart = 0;

bool bootBtnPressed = false;
unsigned long bootBtnStart = 0;

unsigned long lastReconnectAttempt = 0;
bool apModeActive = false;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH); // OFF (active-low)
}

void pulseRelay(int pin, int timeMs = PULSE_TIME) {
  digitalWrite(pin, LOW);   // ON
  delay(timeMs);
  digitalWrite(pin, HIGH);  // OFF
  Serial.printf("Relay %d pulsed for %d ms\n", pin, timeMs);
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();

  Serial.println("Loaded settings:");
  Serial.printf(" WiFi SSID: '%s'\n", wifi_ssid.c_str());
  Serial.printf(" AP Name: '%s'\n", ap_name.c_str());
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false);
  preferences.clear();
  preferences.end();

  preferences.begin("ap", false);
  preferences.clear();
  preferences.end();
}

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Auto Mode ON → Waiting AUTO_DELAY, then triggering Relay1...");
    delay(AUTO_DELAY);
    pulseRelay(RELAY1_PIN);

    // Notify app after auto trigger if WiFi available
    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      delay(300);
      sw1.sendPowerStateEvent(false);
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) {
    pulseRelay(RELAY1_PIN);
    Serial.println("Pump ON triggered from app");
  }
  else if (deviceId == DEVICE_ID_2) {
    pulseRelay(RELAY2_PIN);
    Serial.println("Pump OFF triggered from app");
  }
  else if (deviceId == DEVICE_ID_3) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    Serial.printf("Auto Mode %s from app\n", autoMode ? "Enabled" : "Disabled");
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
  Serial.println("SinricPro connected.");
}

// ================= Web Page (Captive Portal) =================
String escapeHTML(const String &s) {
  String r = s;
  r.replace("&", "&amp;");
  r.replace("<", "&lt;");
  r.replace(">", "&gt;");
  r.replace("\"", "&quot;");
  r.replace("'", "&#39;");
  return r;
}

void handleControlPage() {
  // placeholders
  String curApName = ap_name.length() ? ap_name : String(DEFAULT_AP_NAME);
  String curApPass = ap_pass.length() ? ap_pass : String(DEFAULT_AP_PASS);
  String curWifi = wifi_ssid.length() ? wifi_ssid : String("");

  String html = "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>body{font-family:Arial;text-align:center;background:#eef2ff;padding:8px;}button,input{padding:12px;margin:6px;width:90%;font-size:16px;border:none;border-radius:8px;}h1{color:#002b80;}</style>";

  // JS flash effect only used by AP buttons (gold flash then simple redirect)
  html += "<script>"
          "function flashRedirect(btn, url){"
          "  var orig = btn.style.backgroundColor || '';"
          "  btn.style.backgroundColor = '#FFD700';"
          "  setTimeout(function(){ window.location.href = url; }, 100);"
          "  setTimeout(function(){ btn.style.backgroundColor = orig; }, 200);"
          "}"
          "</script>";

  html += "</head><body><h1>Pump Controller</h1><h3>Local Wifi AP Settings</h3>";
  html += "<form action='/save' method='POST'>";
  html += "<input name='apname' placeholder='AP Name' value='" + escapeHTML(curApName) + "'><br>";
  html += "<input name='apass' placeholder='AP Password' value='" + escapeHTML(curApPass) + "'><br>";
  html += "<h3>Home WiFi (for Internet)</h3>";
  html += "<input name='ssid' placeholder='WiFi SSID' value='" + escapeHTML(curWifi) + "'><br>";
  html += "<input name='pass' type='password' placeholder='WiFi Password'><br>";
  html += "<button style='background:#007BFF;color:white;'>Save Settings (AP + WiFi)</button></form><hr>";

  html += "<h3>Manual Local Wifi Control</h3>";
  // Use flashRedirect for AP buttons to show gold flash before redirect
  html += "<button style='background:#4CAF50;color:white;' onclick=\"flashRedirect(this,'/relay1')\">Start Pump</button><br>";
  html += "<button style='background:#f44336;color:white;' onclick=\"flashRedirect(this,'/relay2')\">Stop Pump</button><br>";
  html += autoMode ? "<button style='background:#2196F3;color:white;' onclick=\"flashRedirect(this,'/auto/off')\">Disable Auto Mode</button>"
                  : "<button style='background:#2196F3;color:white;' onclick=\"flashRedirect(this,'/auto/on')\">Enable Auto Mode</button>";
  html += "<p><b>Auto Mode:</b> " + String(autoMode ? "Enabled" : "Disabled") + "</p>";
  html += "<p>WiFi Status: " + String(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected / AP Mode") + "</p>";
  html += "<p><small>To restore factory AP & clear credentials press BOOT button >5s</small></p>";
  html += "</body></html>";

  server.send(200, "text/html", html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);
  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(true);
    delay(300);
    sw1.sendPowerStateEvent(false);
  }
  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);
  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    sw2.sendPowerStateEvent(true);
    delay(300);
    sw2.sendPowerStateEvent(false);
  }
  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleAutoOn() {
  autoMode = true;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, HIGH);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(true);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleAutoOff() {
  autoMode = false;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, LOW);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(false);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void registerWebHandlers() {
  // Common captive portal detection paths
  server.on("/generate_204", []() { handleControlPage(); });
  server.on("/hotspot-detect.html", []() { handleControlPage(); });
  server.on("/connecttest.txt", []() { handleControlPage(); });

  server.on("/", handleControlPage);
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);

  server.on("/save", HTTP_POST, []() {
    bool changed = false;
    if (server.hasArg("apname")) {
      String an = server.arg("apname");
      if (an.length()) { saveApCredentials(an, ap_pass.length()? ap_pass : String(DEFAULT_AP_PASS)); ap_name = an; changed = true; }
    }
    if (server.hasArg("apass")) {
      String apw = server.arg("apass");
      if (apw.length()) { saveApCredentials(ap_name.length()? ap_name : String(DEFAULT_AP_NAME), apw); ap_pass = apw; changed = true; }
    }
    if (server.hasArg("ssid")) {
      String s = server.arg("ssid");
      if (s.length()) { saveWifiCredentials(s, wifi_pass.length()? wifi_pass : String("")); wifi_ssid = s; changed = true; }
    }
    if (server.hasArg("pass")) {
      String p = server.arg("pass");
      if (p.length()) { saveWifiCredentials(wifi_ssid.length()? wifi_ssid : String(""), p); wifi_pass = p; changed = true; }
    }

    if (!changed) {
      server.send(400, "text/html", "<h2 style='color:red;'>No values provided. Fill at least one field.</h2>");
      return;
    }

    server.send(200, "text/html", "<h2 style='color:blue;'>Saved! Restarting to apply settings...</h2>");
    delay(1500);
    ESP.restart();
  });

  // Not found handler: redirect to captive portal root (forces popup)
  server.onNotFound([]() {
    String hostHeader = server.hostHeader();
    if (!isIp(hostHeader)) {
      server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString(), true);
      server.send(302, "text/plain", "");
      return;
    }
    handleControlPage();
  });
}

// ================= AP Mode =================
void startAPMode(const char* apName, const char* apPass) {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(apName, apPass);
  IPAddress IP = WiFi.softAPIP();

  // Start DNS server to capture all domain requests and point to ESP IP
  dnsServer.start(DNS_PORT, "*", IP);

  registerWebHandlers();
  server.begin();
  apModeActive = true;
  digitalWrite(WIFI_LED_PIN, LOW);
  Serial.println("⚙ Captive portal started at: " + IP.toString());
}

// ================= WiFi Handling =================
void WiFiEvent(WiFiEvent_t event) {
  switch (event) {
    case SYSTEM_EVENT_STA_CONNECTED:
      Serial.println("Connected to WiFi!");
      break;
    case SYSTEM_EVENT_STA_GOT_IP:
      Serial.print("Got IP: "); Serial.println(WiFi.localIP());
      digitalWrite(WIFI_LED_PIN, HIGH);
      break;
    case SYSTEM_EVENT_STA_DISCONNECTED:
      Serial.println("WiFi disconnected!");
      digitalWrite(WIFI_LED_PIN, LOW); // <-- FIX 1
      break;
    default: break;
  }
}

void connectToWiFiAndStartAP() {
  // Load settings
  loadSavedSettings();

  String useAPName = ap_name.length() ? ap_name : String(DEFAULT_AP_NAME);
  String useAPPass = ap_pass.length() ? ap_pass : String(DEFAULT_AP_PASS);

  // Start AP immediately so portal is always available
  startAPMode(useAPName.c_str(), useAPPass.c_str());

  if (wifi_ssid.length() && wifi_pass.length()) {
    WiFi.onEvent(WiFiEvent);
    Serial.printf("Attempting to connect to WiFi SSID: %s\n", wifi_ssid.c_str());
    WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());

    unsigned long startAttempt = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 10000) {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("✅ Wi-Fi connected!");
    apModeActive = true; // keep AP for portal as required
  } else {
    Serial.println("❌ Wi-Fi not connected (AP portal active).");
    apModeActive = true;
  }
}

// ================= OTA =================
void setupOTA() {
  ArduinoOTA.setHostname("PumpController_OTA");
  ArduinoOTA.begin();
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  digitalWrite(WIFI_LED_PIN, LOW);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  pinMode(AUTO_TOGGLE_BTN, INPUT_PULLUP); // <-- यह लाइन D23 को इनपुट बनाती है

  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadSavedSettings();
  restoreAutoMode();
  connectToWiFiAndStartAP();

  setupOTA();
  setupSinricPro();
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();

  if (apModeActive) dnsServer.processNextRequest();

  // --- NEW: Manual Auto Mode toggle on D23 (Simple Logic) ---
  // यह D23 के लिए नया, सबसे आसान लॉजिक है
  if (digitalRead(AUTO_TOGGLE_BTN) == LOW) {
    // 1. बटन दबा है
    autoMode = !autoMode; // टॉगल करो
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW); // LED बदलो

    // 2. सेटिंग्स सेव करो
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    
    Serial.printf("Auto Mode toggled manually -> %s\n", autoMode ? "ON" : "OFF");

    // 3. Sinric Pro को अपडेट करो
    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
      sw3.sendPowerStateEvent(autoMode);
    }
    
    // 4. बाउंसिंग रोकें और 1 प्रेस = 1 टॉगल पक्का करें
    delay(200); // छोटा सा डिले
    while(digitalRead(AUTO_TOGGLE_BTN) == LOW) {
      delay(10); // जब तक बटन दबा है, यहीं रुको
    }
    // अब बटन छोड़ दिया गया है, लूप जारी रहेगा
  }
  // --- END of new logic ---


  // --- यह आपका पुराना D27 बटन का लॉजिक है (FIX 2) ---
  // Manual button long-press -> Stop Pump
  if (digitalRead(MANUAL_BTN_PIN) == LOW) { // <-- FIX 2 (MANAL से MANUAL)
    if (!btnPressed) { btnPressed = true; btnPressStart = millis(); }
    else if (millis() - btnPressStart >= HOLD_TIME) {
      Serial.println("Manual button held 5s → Stop Pump");
      pulseRelay(RELAY2_PIN);
      if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        sw2.sendPowerStateEvent(true);
        delay(300);
        sw2.sendPowerStateEvent(false);
      }
      btnPressed = false;
      while (digitalRead(MANUAL_BTN_PIN) == LOW) delay(10);
    }
  } else btnPressed = false;

  // --- यह आपका पुराना D0 बटन का लॉजिक है (कुछ भी नहीं बदला) ---
  // Boot button long-press -> Reset WiFi & AP to defaults
  if (digitalRead(BOOT_BTN_PIN) == LOW) {
    if (!bootBtnPressed) { bootBtnPressed = true; bootBtnStart = millis(); }
    else if (millis() - bootBtnStart >= HOLD_TIME) {
      Serial.println("⚠ Boot button held 5s → Clearing WiFi & AP credentials (factory defaults)");
      clearAllCredentials();
      delay(500);
      ESP.restart();
    }
  } else bootBtnPressed = false;

  // --- यह आपका पुराना WiFi Reconnect लॉजिक है (कुछ भी नहीं बदला) ---
  // WiFi reconnect logic (attempt every WIFI_RETRY_MS if disconnected)
  if (WiFi.status() != WL_CONNECTED && millis() - lastReconnectAttempt > WIFI_RETRY_MS) {
    Serial.println("WiFi lost, retrying station connect...");
    if (wifi_ssid.length() && wifi_pass.length()) {
      WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    }
    lastReconnectAttempt = millis();
  }

  // --- यह आपका पुराना SinricPro Reconnect लॉजिक है (कुछ भी नहीं बदला) ---
  // SinricPro auto reconnect if WiFi ok
  static unsigned long lastSinricTry = 0;
  if (WiFi.status() == WL_CONNECTED && !SinricPro.isConnected() && millis() - lastSinricTry > 5000) {
    Serial.println("Reconnecting SinricPro...");
    SinricPro.begin(APP_KEY, APP_SECRET);
    lastSinricTry = millis();
  }
}