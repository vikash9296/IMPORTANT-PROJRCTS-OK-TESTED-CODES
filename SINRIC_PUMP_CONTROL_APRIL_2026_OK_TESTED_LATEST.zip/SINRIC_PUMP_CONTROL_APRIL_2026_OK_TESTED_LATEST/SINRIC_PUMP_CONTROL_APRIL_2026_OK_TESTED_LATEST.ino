/*
  PumpController_Final_Fresh_BY_VIKASH_KUMAR_12_04_2026
  --------------------------------------------------
  ESP32 BOARD VERSION...2.0.3 THIS IS ALL IN ONE IOT SINRIC PRO AND LOCAL WEBPAGE PUMP CONTROL NORMAL MOTOR AND SUMBIRSIBBLE MOTOR BOTH MOTOR SELECT BY WEBPAGE
*/

#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "4100bfe8-ea8a-464d-b268-97fb70ae2912"
#define APP_SECRET    "4090f94e-62d1-4226-93e8-bed0586df4d7-8a7015a4-76a4-4cc1-a47f-c9df04a7c7d9"
#define DEVICE_ID_1   "69d5e200a221de78792ef92e" // device id in sinric app (MOTOR)
#define DEVICE_ID_2   "69d5e24d52800e7ce3616dcb" // device id in sinric app (PUMP OFF)
#define DEVICE_ID_3   "69d5e22ca221de78792ef956" // device id in sinric app (AUTO MODE)

// ------------------- Pins -------------------
#define RELAY1_PIN      19 // this is for motor start relay name in sinric pro app (MOTOR)
#define RELAY2_PIN      21 // this is for motor stop relay name in sinric pro app (PUMP OFF)
#define AUTO_MODE_LED   22 // this is for auto mode enable disable internally also connect a auto mode status led in this pin
#define WIFI_LED_PIN    2 // this is for wifi indicator led
#define MANUAL_BTN_PIN  27 // this is for water float sensor input pullup to GND when water tank over motor stop automatically
#define AUTO_TOGGLE_BTN 23 // this is for auto mode enable disable mannual push button to GND 
#define BOOT_BTN_PIN    0 // if the boot button press for 10 second erase local wifi name and password and internet wifi 

// ------------------- Constants -------------------
#define HOLD_TIME          5000
#define PULSE_TIME         2000
#define AUTO_DELAY         60000
#define DNS_PORT           53
#define WIFI_RETRY_MS      5000
#define WIFI_SCAN_INTERVAL 30000

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
bool bootBtnPressed = false;
bool apModeActive = false;

bool isTriggerMode = true; // TRUE = Pulse (Submersible), FALSE = Toggle (Normal)
bool r1_state = false;
bool r2_state = false;

unsigned long btnPressStart = 0;
unsigned long bootBtnStart = 0;
unsigned long lastReconnectAttempt = 0;
unsigned long lastWiFiScanMs = 0;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

int relayPulseMs = PULSE_TIME;
int wifiScanCount = 0;

IPAddress apIP(192, 168, 4, 1);
IPAddress netMsk(255, 255, 255, 0);

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

String escapeHTML(const String &s) {
  String r = s;
  r.replace("&", "&amp;");
  r.replace("<", "&lt;");
  r.replace(">", "&gt;");
  r.replace("\"", "&quot;");
  r.replace("'", "&#39;");
  return r;
}

String boolJson(bool value) {
  return value ? "true" : "false";
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH);
}

void pulseRelay(int pin, int timeMs = PULSE_TIME) {
  if (isTriggerMode) {
    digitalWrite(pin, LOW);
    delay(relayPulseMs);
    digitalWrite(pin, HIGH);
    Serial.printf("Relay %d pulsed for %d ms (Trigger Mode)\n", pin, relayPulseMs);
  } else {
    if (pin == RELAY1_PIN) {
      r1_state = !r1_state;
      digitalWrite(pin, r1_state ? LOW : HIGH);
    } else if (pin == RELAY2_PIN) {
      r2_state = !r2_state;
      digitalWrite(pin, r2_state ? LOW : HIGH);
    }
    Serial.printf("Relay %d Toggled (Toggle Mode)\n", pin);
  }
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();

  preferences.begin("settings", true);
  isTriggerMode = preferences.getBool("isTrigger", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void saveOpMode(bool trigger) {
  preferences.begin("settings", false);
  preferences.putBool("isTrigger", trigger);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false); preferences.clear(); preferences.end();
  preferences.begin("ap", false); preferences.clear(); preferences.end();
  preferences.begin("settings", false); preferences.clear(); preferences.end();
}

void loadRelayPulseTime() {
  preferences.begin("settings", true);
  relayPulseMs = preferences.getInt("pulseMs", PULSE_TIME);
  preferences.end();

  if (relayPulseMs < 1000 || relayPulseMs > 5000) {
    relayPulseMs = PULSE_TIME;
  }
}

void saveRelayPulseTime(int ms) {
  preferences.begin("settings", false);
  preferences.putInt("pulseMs", ms);
  preferences.end();
}

// ================= WiFi Scan =================
void scanWiFiOnce() {
  WiFi.scanDelete();
  wifiScanCount = WiFi.scanNetworks();
  if (wifiScanCount < 0) wifiScanCount = 0;
  lastWiFiScanMs = millis();
  Serial.printf("WiFi scan found %d networks\n", wifiScanCount);
}

void ensureWiFiScan() {
  if (wifiScanCount <= 0 || millis() - lastWiFiScanMs > WIFI_SCAN_INTERVAL) {
    scanWiFiOnce();
  }
}

String buildWifiOptions(String current) {
  String opt = "";
  for (int i = 0; i < wifiScanCount; i++) {
    String s = WiFi.SSID(i);
    if (s.length() == 0) continue;
    opt += "<option value='" + escapeHTML(s) + "'";
    if (s == current) opt += " selected";
    opt += ">" + escapeHTML(s) + "</option>";
  }
  return opt;
}

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Power Reset: Auto Mode is ON. Waiting 60s...");
    delay(AUTO_DELAY);
    pulseRelay(RELAY1_PIN);
    if (WiFi.status() == WL_CONNECTED && SinricPro.isConnected()) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      if (isTriggerMode) {
        delay(300);
        sw1.sendPowerStateEvent(false);
      }
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) {
    pulseRelay(RELAY1_PIN);
  } else if (deviceId == DEVICE_ID_2) {
    pulseRelay(RELAY2_PIN);
  } else if (deviceId == DEVICE_ID_3) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
}

// ================= CAPTIVE PORTAL HANDLERS =================
bool isCaptive() {
  if (!server.hostHeader().equals(apIP.toString()) && !server.hostHeader().endsWith(".local")) return true;
  return false;
}

void handleNotFound() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", "");
  } else {
    server.send(404, "text/plain", "Not Found");
  }
}

// ================= Status API =================
void handleStatus() {
  String json = "{";
  json += "\"autoMode\":" + boolJson(autoMode) + ",";
  json += "\"wifiConnected\":" + boolJson(WiFi.status() == WL_CONNECTED) + ",";
  json += "\"modeLabel\":\"" + String(isTriggerMode ? "Trigger / Submersible" : "Toggle / Normal") + "\",";
  json += "\"autoLabel\":\"" + String(autoMode ? "Enabled" : "Disabled") + "\",";
  json += "\"wifiLabel\":\"" + String(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected") + "\",";
  json += "\"motorLogic\":\"" + String(isTriggerMode ? "Trigger Pulse" : "Toggle Output") + "\",";
  json += "\"pulseSec\":" + String(relayPulseMs / 1000);
  json += "}";
  server.send(200, "application/json", json);
}

// ================= Web Page =================
void handleControlPage() {
  if (isCaptive()) {
    server.sendHeader("Location", String("http://") + apIP.toString(), true);
    server.send(302, "text/plain", "");
    return;
  }

  ensureWiFiScan();

  String curApName = ap_name.length() ? ap_name : DEFAULT_AP_NAME;
  String curApPass = ap_pass.length() ? ap_pass : DEFAULT_AP_PASS;
  String curWifi = wifi_ssid;
  String wifiSelectLabel = wifiScanCount > 0 ? "-- Select Nearby WiFi --" : "-- No Nearby WiFi Found --";

  String html = "<!doctype html><html lang='en'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<meta name='theme-color' content='#0f172a'><title>Pump Controller</title>";
  html += "<style>";
  html += ":root{--panel:rgba(10,19,35,0.86);--panelSoft:rgba(15,25,45,0.74);--line:rgba(255,255,255,0.12);--text:#ebf2ff;--muted:#9fb0d1;--accent:#56c2ff;--accent2:#7c5cff;--ok:#23c483;--stop:#ff6b6b;--warn:#ffbf47;--shadow:0 24px 60px rgba(0,0,0,0.35);}";
  html += "*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}";
  html += "body{margin:0;font-family:'Segoe UI Variable','Segoe UI',Tahoma,sans-serif;background:radial-gradient(circle at top left,#143865 0%,#07111f 45%,#02060d 100%);color:var(--text);min-height:100vh;}";
  html += "body:before,body:after{content:'';position:fixed;border-radius:50%;filter:blur(12px);opacity:.32;pointer-events:none;}";
  html += "body:before{width:210px;height:210px;background:#2dd4bf;top:-60px;left:-70px;}";
  html += "body:after{width:250px;height:250px;background:#8b5cf6;right:-90px;top:90px;}";
  html += ".shell{width:min(100% - 14px,1100px);margin:0 auto;padding:12px 0 24px;position:relative;z-index:1;}";
  html += ".hero{background:linear-gradient(135deg,rgba(86,194,255,0.22),rgba(124,92,255,0.18));border:1px solid rgba(255,255,255,0.16);box-shadow:var(--shadow);border-radius:24px;padding:18px 16px 16px;position:relative;overflow:hidden;}";
  html += ".hero:before{content:'';position:absolute;inset:0;background:linear-gradient(120deg,rgba(255,255,255,0.10),transparent 48%);pointer-events:none;}";
  html += "h1{margin:0;font-size:28px;line-height:1.08;font-weight:800;letter-spacing:.2px;}";
  html += ".pillRow{display:grid;grid-template-columns:1fr;gap:8px;margin-top:14px;}";
  html += ".pill{padding:11px 12px;border-radius:16px;background:rgba(255,255,255,0.10);border:1px solid rgba(255,255,255,0.12);font-size:13px;font-weight:700;color:#eef4ff;text-align:center;}";
  html += ".pill.info{background:rgba(86,194,255,0.16);border-color:rgba(86,194,255,0.28);}";
  html += ".pill.success{background:rgba(35,196,131,0.16);border-color:rgba(35,196,131,0.28);}";
  html += ".pill.warn{background:rgba(255,191,71,0.16);border-color:rgba(255,191,71,0.30);}";
  html += ".grid{display:grid;gap:14px;margin-top:14px;}";
  html += ".card{background:var(--panel);backdrop-filter:blur(18px);border:1px solid var(--line);box-shadow:var(--shadow);border-radius:22px;padding:16px;}";
  html += ".card h2{margin:0 0 12px;font-size:18px;}";
  html += ".stack{display:grid;gap:14px;}";
  html += ".modeCard{padding:14px;border-radius:18px;background:var(--panelSoft);border:1px solid rgba(255,255,255,0.08);}";
  html += ".label{display:block;margin:0 0 7px;font-size:12px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:#b8c7e6;}";
  html += "input,select,button{width:100%;border-radius:15px;border:1px solid rgba(255,255,255,0.10);font-size:16px;transition:transform .16s ease,box-shadow .16s ease,background .16s ease,border-color .16s ease;}";
  html += "input,select{padding:15px 16px;background:rgba(255,255,255,0.07);color:var(--text);outline:none;appearance:none;}";
  html += "input::placeholder{color:#92a6cb;}";
  html += "option{color:#08111f;}";
  html += "select{background-image:linear-gradient(45deg,transparent 50%,#c9d8f7 50%),linear-gradient(135deg,#c9d8f7 50%,transparent 50%);background-position:calc(100% - 22px) calc(50% - 3px),calc(100% - 16px) calc(50% - 3px);background-size:6px 6px,6px 6px;background-repeat:no-repeat;padding-right:40px;}";
  html += "input:focus,select:focus{border-color:rgba(86,194,255,0.58);box-shadow:0 0 0 3px rgba(86,194,255,0.14);}";
  html += ".split{display:grid;gap:12px;}";
  html += ".passWrap{position:relative;}";
  html += ".toggleBtn{position:absolute;right:10px;top:50%;transform:translateY(-50%);width:auto;border:none;background:rgba(255,255,255,0.08);color:#dce7ff;padding:8px 10px;border-radius:11px;font-size:12px;font-weight:700;cursor:pointer;}";
  html += ".toggleBtn:hover{background:rgba(255,255,255,0.16);}";
  html += ".saveBtn{padding:16px 18px;border:none;cursor:pointer;font-weight:800;letter-spacing:.2px;background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;box-shadow:0 16px 28px rgba(86,194,255,0.20);}";
  html += ".saveBtn:hover{transform:translateY(-1px);}";
  html += ".scanRow{display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap;}";
  html += ".scanInfo{font-size:12px;color:var(--muted);font-weight:700;}";
  html += ".miniBtn{width:auto;padding:12px 14px;border:none;background:rgba(255,255,255,0.10);color:#eef4ff;font-size:13px;font-weight:700;cursor:pointer;}";
  html += ".quickGrid{display:grid;grid-template-columns:repeat(3,minmax(82px,1fr));gap:8px;justify-items:center;}";
  html += ".actionBtn{aspect-ratio:1/1;width:100%;max-width:122px;padding:10px;border:none;border-radius:50%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;color:#fff;box-shadow:0 16px 26px rgba(0,0,0,0.22);cursor:pointer;}";
  html += ".actionBtn strong{display:block;font-size:12px;font-weight:800;letter-spacing:.3px;line-height:1.18;}";
  html += ".actionBtn span{display:block;font-size:9px;font-weight:700;opacity:.86;margin-top:6px;line-height:1.25;max-width:72px;}";
  html += ".start{background:linear-gradient(135deg,#1aa36f,#2bd58f);}";
  html += ".stop{background:linear-gradient(135deg,#e14b4b,#ff7b6b);}";
  html += ".switchBtn{gap:8px;}";
  html += ".switchTrack{width:58px;height:30px;border-radius:999px;background:rgba(255,255,255,0.20);border:1px solid rgba(255,255,255,0.18);position:relative;box-shadow:inset 0 3px 10px rgba(0,0,0,0.18);}";
  html += ".switchKnob{width:20px;height:20px;border-radius:50%;background:#fff;position:absolute;top:4px;left:5px;box-shadow:0 8px 16px rgba(0,0,0,0.18);transition:transform .22s ease;}";
  html += ".switchBtn.auto-on{background:linear-gradient(135deg,#1783e7,#6b7cff);}";
  html += ".switchBtn.auto-on .switchKnob{transform:translateX(24px);}";
  html += ".switchBtn.auto-off{background:linear-gradient(135deg,#e0a10d,#ffcc66);color:#101623;}";
  html += ".statusPanel{margin-top:16px;padding:14px;border-radius:18px;background:linear-gradient(180deg,rgba(255,255,255,0.08),rgba(255,255,255,0.04));border:1px solid rgba(255,255,255,0.08);}";
  html += ".statusRow{display:flex;justify-content:space-between;gap:10px;padding:10px 0;border-bottom:1px solid rgba(255,255,255,0.08);font-size:13px;}";
  html += ".statusRow:last-child{border-bottom:none;padding-bottom:0;}";
  html += ".statusKey{color:#afc0e1;}";
  html += ".statusVal{font-weight:800;text-align:right;}";
  html += "@media (min-width:640px){.shell{width:min(100% - 22px,1100px);padding:16px 0 28px;}.hero{padding:22px 20px 18px;}.pillRow{grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;}.split{grid-template-columns:repeat(2,minmax(0,1fr));}.quickGrid{gap:12px;}.actionBtn{max-width:148px;padding:14px;}.actionBtn strong{font-size:14px;}.actionBtn span{font-size:10px;max-width:88px;}.switchTrack{width:68px;height:36px;}.switchKnob{width:24px;height:24px;}.switchBtn.auto-on .switchKnob{transform:translateX(33px);}}";
  html += "@media (min-width:920px){body:before{width:240px;height:240px;}body:after{width:280px;height:280px;}.shell{width:min(100% - 28px,1120px);padding:20px 0 34px;}.hero{padding:26px 24px 20px;border-radius:28px;}h1{font-size:31px;}.grid{grid-template-columns:minmax(0,1.06fr) minmax(340px,.94fr);gap:18px;}.card{padding:20px;}.quickGrid{gap:16px;}.actionBtn{max-width:178px;padding:18px;}.actionBtn strong{font-size:17px;}.actionBtn span{font-size:12px;max-width:108px;}.switchTrack{width:86px;height:46px;}.switchKnob{width:34px;height:34px;top:5px;left:7px;}.switchBtn.auto-on .switchKnob{transform:translateX(38px);}}";
  html += "</style>";

  html += "<script>";
  html += "function toggleField(id,btnId){var x=document.getElementById(id);var b=document.getElementById(btnId);var show=x.type==='password';x.type=show?'text':'password';b.textContent=show?'Hide':'Show';}";
  html += "function flashRedirect(btn,url){btn.style.opacity='0.78';btn.style.transform='scale(0.98)';setTimeout(function(){location.href=url;},160);}";

  html += "function setPill(id,text,kind){var el=document.getElementById(id);if(!el)return;el.className='pill '+kind;el.textContent=text;}";
  html += "function setText(id,text){var el=document.getElementById(id);if(el) el.textContent=text;}";
  html += "function renderAutoButton(enabled){var btn=document.getElementById('autoBtn');if(!btn)return;btn.className='actionBtn switchBtn '+(enabled?'auto-on':'auto-off');btn.setAttribute('data-url',enabled?'/auto/off':'/auto/on');var label=btn.querySelector('.switchLabel');if(label) label.textContent=enabled?'ON - Tap to Disable':'OFF - Tap to Enable';}";
  html += "function refreshStatus(){fetch('/status',{cache:'no-store'}).then(function(r){return r.json();}).then(function(data){setPill('modePill','Mode: '+data.modeLabel,'info');setPill('autoPill','Auto Mode: '+data.autoLabel,data.autoMode?'success':'warn');setPill('wifiPill','WiFi: '+data.wifiLabel,data.wifiConnected?'success':'warn');setText('statusAuto',data.autoLabel);setText('statusWiFi',data.wifiLabel);setText('statusMode',data.motorLogic);setText('statusPulse',data.pulseSec+' Sec');renderAutoButton(data.autoMode);}).catch(function(){});}";
  html += "window.addEventListener('load',function(){setTimeout(refreshStatus,500);setInterval(refreshStatus,2500);});";
  html += "document.addEventListener('visibilitychange',function(){if(!document.hidden) refreshStatus();});";
  html += "</script></head><body>";

  html += "<div class='shell'>";
  html += "<div class='hero'>";
  html += "<h1>Pump Controller</h1>";
  html += "<div class='pillRow'>";
  html += "<div id='modePill' class='pill info'>Mode: " + String(isTriggerMode ? "Trigger / Submersible" : "Toggle / Normal") + "</div>";
  html += "<div id='autoPill' class='pill " + String(autoMode ? "success" : "warn") + "'>Auto Mode: " + String(autoMode ? "Enabled" : "Disabled") + "</div>";
  html += "<div id='wifiPill' class='pill " + String(WiFi.status() == WL_CONNECTED ? "success" : "warn") + "'>WiFi: " + String(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected") + "</div>";
  html += "</div></div>";

  html += "<div class='grid'>";

  html += "<div class='card'>";
  html += "<h2>Configuration</h2>";
  html += "<div class='stack'>";

  html += "<div class='modeCard'>";
  html += "<span class='label'>Operation Mode</span>";
  html += "<form action='/setMode' method='POST'>";
  html += "<select name='mode' onchange='this.form.submit()'>";
  html += "<option value='trigger'" + String(isTriggerMode ? " selected" : "") + ">Trigger Mode (Submersible Motor)</option>";
  html += "<option value='toggle'" + String(!isTriggerMode ? " selected" : "") + ">Toggle Mode (Normal Motor)</option>";
  html += "</select></form></div>";

  html += "<form action='/save' method='POST' class='stack'>";

  html += "<div>";
  html += "<span class='label'>Local WiFi AP Settings</span>";
  html += "<div class='split'>";
  html += "<input name='apname' placeholder='AP Name' value='" + escapeHTML(curApName) + "'>";
  html += "<div class='passWrap'><input id='ap_pwd' name='apass' type='password' placeholder='AP Password' value='" + escapeHTML(curApPass) + "'><button class='toggleBtn' type='button' id='ap_toggle' onclick='toggleField(\"ap_pwd\",\"ap_toggle\")'>Show</button></div>";
  html += "</div></div>";

  html += "<div>";
  html += "<span class='label'>Home WiFi Settings</span>";
  html += "<div class='scanRow'><span class='scanInfo'>Nearby WiFi: " + String(wifiScanCount) + " found</span><button type='button' class='miniBtn' onclick='location.reload()'>Refresh Nearby WiFi</button></div>";
  html += "<select name='ssid_select' onchange='document.getElementById(\"ssidin\").value=this.value'><option value=''>" + wifiSelectLabel + "</option>" + buildWifiOptions(curWifi) + "</select>";
  html += "<input id='ssidin' name='ssid' placeholder='WiFi SSID' value='" + escapeHTML(curWifi) + "'>";
  html += "<div class='passWrap'><input id='pwd' name='pass' type='password' placeholder='WiFi Password'><button class='toggleBtn' type='button' id='wifi_toggle' onclick='toggleField(\"pwd\",\"wifi_toggle\")'>Show</button></div>";
  html += "</div>";

  html += "<div>";
  html += "<span class='label'>Relay Pulse Time</span>";
  html += "<select name='pulse'>";
  for (int i = 1; i <= 5; i++) {
    int ms = i * 1000;
    html += "<option value='" + String(ms) + "'";
    if (relayPulseMs == ms) html += " selected";
    html += ">" + String(i) + " Second</option>";
  }
  html += "</select></div>";

  html += "<button class='saveBtn'>Save Settings</button>";
  html += "</form>";
  html += "</div>";
  html += "</div>";

  html += "<div class='card'>";
  html += "<h2>Manual Quick Control</h2>";

  html += "<div class='quickGrid'>";
  html += "<button class='actionBtn start' onclick='flashRedirect(this,\"/relay1\")'><strong>START PUMP</strong><span> Start</span></button>";
  html += "<button class='actionBtn stop' onclick='flashRedirect(this,\"/relay2\")'><strong>STOP PUMP</strong><span> Stop</span></button>";

  if (autoMode) {
    html += "<button id='autoBtn' data-url='/auto/off' class='actionBtn switchBtn auto-on' onclick='flashRedirect(this,this.getAttribute(\"data-url\"))'><strong>AUTO MODE</strong><div class='switchTrack'><div class='switchKnob'></div></div><span class='switchLabel'>ON - Tap to Disable</span></button>";
  } else {
    html += "<button id='autoBtn' data-url='/auto/on' class='actionBtn switchBtn auto-off' onclick='flashRedirect(this,this.getAttribute(\"data-url\"))'><strong>AUTO MODE</strong><div class='switchTrack'><div class='switchKnob'></div></div><span class='switchLabel'>OFF - Tap to Enable</span></button>";
  }

  html += "</div>";

  html += "<div class='statusPanel'>";
  html += "<div class='statusRow'><span class='statusKey'>Auto Mode</span><span id='statusAuto' class='statusVal'>" + String(autoMode ? "Enabled" : "Disabled") + "</span></div>";
  html += "<div class='statusRow'><span class='statusKey'>WiFi Status</span><span id='statusWiFi' class='statusVal'>" + String(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected") + "</span></div>";
  html += "<div class='statusRow'><span class='statusKey'>Motor Logic</span><span id='statusMode' class='statusVal'>" + String(isTriggerMode ? "Trigger Pulse" : "Toggle Output") + "</span></div>";
  html += "<div class='statusRow'><span class='statusKey'>Pulse Time</span><span id='statusPulse' class='statusVal'>" + String(relayPulseMs / 1000) + " Sec</span></div>";
  html += "</div>";

  html += "</div>";
  html += "</div>";
  html += "</div></body></html>";

  server.send(200, "text/html", html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);
  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(isTriggerMode ? true : r1_state);
    if (isTriggerMode) {
      delay(300);
      sw1.sendPowerStateEvent(false);
    }
  }
  server.sendHeader("Location", "/", true);
  server.send(302, "text/plain", "");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);
  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    sw2.sendPowerStateEvent(false);
  }
  server.sendHeader("Location", "/", true);
  server.send(302, "text/plain", "");
}

void handleSetMode() {
  if (server.hasArg("mode")) {
    isTriggerMode = (server.arg("mode") == "trigger");
    saveOpMode(isTriggerMode);
    digitalWrite(RELAY1_PIN, HIGH);
    digitalWrite(RELAY2_PIN, HIGH);
    r1_state = false;
    r2_state = false;
  }
  server.sendHeader("Location", "/", true);
  server.send(302, "text/plain", "");
}

void handleAutoOn() {
  autoMode = true;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, HIGH);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(true);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "text/plain", "");
}

void handleAutoOff() {
  autoMode = false;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, LOW);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
    sw3.sendPowerStateEvent(false);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "text/plain", "");
}

void registerWebHandlers() {
  server.on("/", handleControlPage);
  server.on("/generate_204", handleControlPage);
  server.on("/fwlink", handleControlPage);
  server.on("/status", handleStatus);
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);
  server.on("/setMode", HTTP_POST, handleSetMode);

  server.on("/save", HTTP_POST, []() {
    if (server.hasArg("apname")) saveApCredentials(server.arg("apname"), server.arg("apass"));
    if (server.hasArg("ssid") && server.arg("ssid").length()) saveWifiCredentials(server.arg("ssid"), server.arg("pass"));
    if (server.hasArg("ssid_select") && server.arg("ssid_select").length()) saveWifiCredentials(server.arg("ssid_select"), server.arg("pass"));
    if (server.hasArg("pulse")) saveRelayPulseTime(server.arg("pulse").toInt());

    server.send(200, "text/html", "<!doctype html><html><head><meta name='viewport' content='width=device-width, initial-scale=1'><style>body{font-family:Segoe UI,Arial,sans-serif;background:#07111f;color:#fff;display:grid;place-items:center;min-height:100vh;margin:0}div{padding:24px;border-radius:18px;background:#12233f;text-align:center;box-shadow:0 18px 40px rgba(0,0,0,.35)}</style></head><body><div><h2>Saved</h2><p>Restarting device...</p></div></body></html>");
    delay(1500);
    ESP.restart();
  });

  server.onNotFound(handleNotFound);
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);

  pinMode(WIFI_LED_PIN, OUTPUT);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);
  pinMode(AUTO_TOGGLE_BTN, INPUT_PULLUP);

  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadSavedSettings();
  loadRelayPulseTime();

  WiFi.mode(WIFI_AP_STA);
  WiFi.softAPConfig(apIP, apIP, netMsk);
  WiFi.softAP(ap_name.length() ? ap_name.c_str() : DEFAULT_AP_NAME,
              ap_pass.length() ? ap_pass.c_str() : DEFAULT_AP_PASS);
  WiFi.setSleep(false);

  if (wifi_ssid.length()) {
    WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
  }

  scanWiFiOnce();

  dnsServer.start(DNS_PORT, "*", apIP);
  registerWebHandlers();
  server.begin();
  apModeActive = true;

  ArduinoOTA.begin();
  setupSinricPro();
  restoreAutoMode();
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();

  if (apModeActive) dnsServer.processNextRequest();

  if (digitalRead(AUTO_TOGGLE_BTN) == LOW) {
    autoMode = !autoMode;
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();

    if (WiFi.status() == WL_CONNECTED) {
      SinricProSwitch &sw3 = SinricPro[DEVICE_ID_3];
      sw3.sendPowerStateEvent(autoMode);
    }

    delay(200);
    while (digitalRead(AUTO_TOGGLE_BTN) == LOW) delay(10);
  }

  if (digitalRead(MANUAL_BTN_PIN) == LOW) {
    if (!btnPressed) {
      btnPressed = true;
      btnPressStart = millis();
    } else if (millis() - btnPressStart >= HOLD_TIME) {
      pulseRelay(RELAY2_PIN);
      if (WiFi.status() == WL_CONNECTED) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        sw2.sendPowerStateEvent(true);
        if (isTriggerMode) {
          delay(300);
          sw2.sendPowerStateEvent(false);
        }
      }
      btnPressed = false;
      while (digitalRead(MANUAL_BTN_PIN) == LOW) delay(10);
    }
  } else {
    btnPressed = false;
  }

  if (digitalRead(BOOT_BTN_PIN) == LOW) {
    if (!bootBtnPressed) {
      bootBtnPressed = true;
      bootBtnStart = millis();
    } else if (millis() - bootBtnStart >= HOLD_TIME) {
      clearAllCredentials();
      delay(500);
      ESP.restart();
    }
  } else {
    bootBtnPressed = false;
  }

  if (WiFi.status() != WL_CONNECTED && millis() - lastReconnectAttempt > 10000) {
    if (wifi_ssid.length()) WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    lastReconnectAttempt = millis();
  }

  digitalWrite(WIFI_LED_PIN, (WiFi.status() == WL_CONNECTED) ? HIGH : LOW);
}
