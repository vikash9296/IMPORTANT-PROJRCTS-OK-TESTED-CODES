// ================== Libraries ==================
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <ArduinoOTA.h>
#include <SinricPro.h>
#include <SinricProSwitch.h>
#include <DNSServer.h>

// ------------------- Sinric Pro Credentials -------------------
#define APP_KEY       "c7303938-59fa-4ad2-a3de-e62d9bae9cec"
#define APP_SECRET    "c41c8855-b93b-496c-bf27-43f0f72c2dc8-4e754444-82cd-4acb-bb2c-c9cfe22b9b13"
#define DEVICE_ID_1   "6889cacbedeca866fe96e2ee"  // Pump ON
#define DEVICE_ID_2   "6889caffddd2551252ba8a70"  // Pump OFF
#define DEVICE_3_ID   "6890c55fedeca866fe994705"  // Auto Mode

// ------------------- Pins -------------------
#define RELAY1_PIN     19
#define RELAY2_PIN     21
#define AUTO_MODE_LED  22
#define WIFI_LED_PIN   2
#define MANUAL_BTN_PIN 27
#define BOOT_BTN_PIN   0   // On-board BOOT button (long-press to factory-reset WiFi/AP)

// ------------------- Constants -------------------
#define HOLD_TIME      5000
#define PULSE_TIME     2000
#define AUTO_DELAY     40000
#define DNS_PORT       53
#define WIFI_RETRY_MS  5000

// ------------------- Defaults -------------------
const char* DEFAULT_AP_NAME = "PumpController_AP";
const char* DEFAULT_AP_PASS = "12345678";

// ------------------- Globals -------------------
Preferences preferences;
WebServer server(80);
DNSServer dnsServer;

bool autoMode = false;
bool btnPressed = false;
unsigned long btnPressStart = 0;

bool bootBtnPressed = false;
unsigned long bootBtnStart = 0;

unsigned long lastReconnectAttempt = 0;
bool apModeActive = false;

String wifi_ssid = "";
String wifi_pass = "";
String ap_name = "";
String ap_pass = "";

// ================= Helper =================
bool isIp(String str) {
  for (unsigned int i = 0; i < str.length(); i++) {
    int c = str.charAt(i);
    if (c != '.' && (c < '0' || c > '9')) return false;
  }
  return true;
}

// ================= Relay Control =================
void setupRelay(int pin) {
  pinMode(pin, OUTPUT);
  digitalWrite(pin, HIGH); // OFF (active-low)
}

void pulseRelay(int pin, int time = PULSE_TIME) {
  digitalWrite(pin, LOW);
  delay(time);
  digitalWrite(pin, HIGH);
  Serial.printf("Relay %d pulsed for %d ms\n", pin, time);
}

// ================= Preferences Helpers =================
void loadSavedSettings() {
  preferences.begin("wifi", true);
  wifi_ssid = preferences.getString("ssid", "");
  wifi_pass = preferences.getString("pass", "");
  preferences.end();

  preferences.begin("ap", true);
  ap_name = preferences.getString("apname", "");
  ap_pass = preferences.getString("appass", "");
  preferences.end();

  Serial.println("Loaded settings:");
  Serial.printf(" WiFi SSID: '%s'\n", wifi_ssid.c_str());
  Serial.printf(" AP Name: '%s'\n", ap_name.c_str());
}

void saveWifiCredentials(const String &s, const String &p) {
  preferences.begin("wifi", false);
  preferences.putString("ssid", s);
  preferences.putString("pass", p);
  preferences.end();
}

void saveApCredentials(const String &name, const String &pass) {
  preferences.begin("ap", false);
  preferences.putString("apname", name);
  preferences.putString("appass", pass);
  preferences.end();
}

void clearAllCredentials() {
  preferences.begin("wifi", false);
  preferences.clear(); // clear wifi namespace
  preferences.end();

  preferences.begin("ap", false);
  preferences.clear(); // clear ap namespace
  preferences.end();
}

// ================= Preferences (Auto Mode) =================
void restoreAutoMode() {
  preferences.begin("settings", true);
  autoMode = preferences.getBool("autoMode", false);
  preferences.end();

  digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);

  if (autoMode) {
    Serial.println("Auto Mode ON → Waiting AUTO_DELAY, then triggering Relay1...");
    delay(AUTO_DELAY);
    pulseRelay(RELAY1_PIN);

    // Notify app after automatic trigger
    if (WiFi.status() == WL_CONNECTED) {
      SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
      sw1.sendPowerStateEvent(true);
      delay(300);
      sw1.sendPowerStateEvent(false);
    }
  }
}

// ================= Sinric Pro =================
bool onPowerState(const String &deviceId, bool &state) {
  if (deviceId == DEVICE_ID_1) {
    pulseRelay(RELAY1_PIN);
    Serial.println("Pump ON triggered from app");
  }
  else if (deviceId == DEVICE_ID_2) {
    pulseRelay(RELAY2_PIN);
    Serial.println("Pump OFF triggered from app");
  }
  else if (deviceId == DEVICE_3_ID) {
    autoMode = state;
    preferences.begin("settings", false);
    preferences.putBool("autoMode", autoMode);
    preferences.end();
    digitalWrite(AUTO_MODE_LED, autoMode ? HIGH : LOW);
    Serial.printf("Auto Mode %s from app\n", autoMode ? "Enabled" : "Disabled");
  }
  return true;
}

void setupSinricPro() {
  SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
  SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
  SinricProSwitch &sw3 = SinricPro[DEVICE_3_ID];

  sw1.onPowerState(onPowerState);
  sw2.onPowerState(onPowerState);
  sw3.onPowerState(onPowerState);

  SinricPro.restoreDeviceStates(false);
  SinricPro.begin(APP_KEY, APP_SECRET);
  Serial.println("SinricPro connected.");
}

// ================= Web Page (Captive Portal) =================
String escapeHTML(const String &s) {
  String r = s;
  r.replace("&", "&amp;");
  r.replace("<", "&lt;");
  r.replace(">", "&gt;");
  r.replace("\"", "&quot;");
  r.replace("'", "&#39;");
  return r;
}

void handleControlPage() {
  // Show current values as placeholders
  String curApName = ap_name.length() ? ap_name : String(DEFAULT_AP_NAME);
  String curApPass = ap_pass.length() ? ap_pass : String(DEFAULT_AP_PASS);
  String curWifi = wifi_ssid.length() ? wifi_ssid : String("");

  String html = "<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>";
  html += "<style>body{font-family:Arial;text-align:center;background:#eef2ff;padding:8px;}button,input{padding:12px;margin:6px;width:90%;font-size:16px;border:none;border-radius:8px;}h1{color:#002b80;}</style>";
  html += "</head><body><h1>Pump Controller</h1><h3>Local AP Settings</h3>";
  html += "<form action='/save' method='POST'>";
  html += "<input name='apname' placeholder='AP Name' value='" + escapeHTML(curApName) + "'><br>";
  html += "<input name='apass' placeholder='AP Password' value='" + escapeHTML(curApPass) + "'><br>";
  html += "<h3>Home WiFi (for Internet)</h3>";
  html += "<input name='ssid' placeholder='WiFi SSID' value='" + escapeHTML(curWifi) + "'><br>";
  html += "<input name='pass' type='password' placeholder='WiFi Password'><br>";
  html += "<button style='background:#007BFF;color:white;'>Save Settings (AP + WiFi)</button></form><hr>";
  html += "<h3>Manual Local Control</h3>";
  html += "<button style='background:#4CAF50;color:white;' onclick=\"location.href='/relay1'\">Start Pump</button><br>";
  html += "<button style='background:#f44336;color:white;' onclick=\"location.href='/relay2'\">Stop Pump</button><br>";
  html += autoMode ? "<button style='background:#2196F3;color:white;' onclick=\"location.href='/auto/off'\">Disable Auto Mode</button>"
                   : "<button style='background:#2196F3;color:white;' onclick=\"location.href='/auto/on'\">Enable Auto Mode</button>";
  html += "<p><b>Auto Mode:</b> " + String(autoMode ? "Enabled" : "Disabled") + "</p>";
  html += "<p>WiFi Status: " + String(WiFi.status() == WL_CONNECTED ? "Connected" : "Not Connected / AP Mode") + "</p>";
  html += "<p><small>To restore factory AP & clear credentials press BOOT button >5s</small></p>";
  html += "</body></html>";
  server.send(200, "text/html", html);
}

// ================= Web Handlers =================
void handleRelay1() {
  pulseRelay(RELAY1_PIN);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw1 = SinricPro[DEVICE_ID_1];
    sw1.sendPowerStateEvent(true);
    delay(300);
    sw1.sendPowerStateEvent(false);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleRelay2() {
  pulseRelay(RELAY2_PIN);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
    sw2.sendPowerStateEvent(true);
    delay(300);
    sw2.sendPowerStateEvent(false);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleAutoOn() {
  autoMode = true;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", true);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, HIGH);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_3_ID];
    sw3.sendPowerStateEvent(true);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void handleAutoOff() {
  autoMode = false;
  preferences.begin("settings", false);
  preferences.putBool("autoMode", false);
  preferences.end();
  digitalWrite(AUTO_MODE_LED, LOW);

  if (WiFi.status() == WL_CONNECTED) {
    SinricProSwitch &sw3 = SinricPro[DEVICE_3_ID];
    sw3.sendPowerStateEvent(false);
  }

  server.sendHeader("Location", "/", true);
  server.send(302, "");
}

void registerWebHandlers() {
  server.on("/generate_204", []() { handleControlPage(); });
  server.on("/hotspot-detect.html", []() { handleControlPage(); });
  server.on("/connecttest.txt", []() { handleControlPage(); });

  server.on("/", handleControlPage);
  server.on("/relay1", handleRelay1);
  server.on("/relay2", handleRelay2);
  server.on("/auto/on", handleAutoOn);
  server.on("/auto/off", handleAutoOff);

  server.on("/save", HTTP_POST, []() {
    // Update only the fields that are present (non-empty)
    bool changed = false;

    if (server.hasArg("apname")) {
      String an = server.arg("apname");
      if (an.length()) { saveApCredentials(an, ap_pass.length()? ap_pass : String(DEFAULT_AP_PASS)); ap_name = an; changed = true; }
    }
    if (server.hasArg("apass")) {
      String apw = server.arg("apass");
      if (apw.length()) { saveApCredentials(ap_name.length()? ap_name : String(DEFAULT_AP_NAME), apw); ap_pass = apw; changed = true; }
    }
    if (server.hasArg("ssid")) {
      String s = server.arg("ssid");
      if (s.length()) { saveWifiCredentials(s, wifi_pass.length()? wifi_pass : String("")); wifi_ssid = s; changed = true; }
    }
    if (server.hasArg("pass")) {
      String p = server.arg("pass");
      if (p.length()) { saveWifiCredentials(wifi_ssid.length()? wifi_ssid : String(""), p); wifi_pass = p; changed = true; }
    }

    // If nothing provided, show error
    if (!changed) {
      server.send(400, "text/html", "<h2 style='color:red;'>No values provided. Fill at least one field.</h2>");
      return;
    }

    server.send(200, "text/html", "<h2 style='color:blue;'>Saved! Restarting to apply settings...</h2>");
    delay(1500);
    ESP.restart();
  });

  server.onNotFound([]() {
    String hostHeader = server.hostHeader();
    if (!isIp(hostHeader)) {
      server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString(), true);
      server.send(302, "text/plain", "");
      return;
    }
    handleControlPage();
  });
}

// ================= AP Mode =================
void startAPMode(const char* apName, const char* apPass) {
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(apName, apPass);
  IPAddress IP = WiFi.softAPIP();
  dnsServer.start(DNS_PORT, "*", IP);
  registerWebHandlers();
  server.begin();
  apModeActive = true;
  digitalWrite(WIFI_LED_PIN, LOW);
  Serial.println("⚙ Captive portal started at: " + IP.toString());
}

// ================= WiFi Handling =================
void WiFiEvent(WiFiEvent_t event) {
  switch (event) {
    case SYSTEM_EVENT_STA_CONNECTED:
      Serial.println("Connected to WiFi!");
      break;
    case SYSTEM_EVENT_STA_GOT_IP:
      Serial.print("Got IP: "); Serial.println(WiFi.localIP());
      digitalWrite(WIFI_LED_PIN, HIGH);
      break;
    case SYSTEM_EVENT_STA_DISCONNECTED:
      Serial.println("WiFi disconnected!");
      digitalWrite(WIFI_LED_PIN, LOW);
      break;
    default: break;
  }
}

void connectToWiFiAndStartAP() {
  // Load settings (already loaded in setup, but safe)
  loadSavedSettings();

  String useAPName = ap_name.length() ? ap_name : String(DEFAULT_AP_NAME);
  String useAPPass = ap_pass.length() ? ap_pass : String(DEFAULT_AP_PASS);

  // Start AP immediately (so user always has portal to change AP/WiFi)
  startAPMode(useAPName.c_str(), useAPPass.c_str());

  if (wifi_ssid.length() && wifi_pass.length()) {
    // Attempt station connect
    WiFi.onEvent(WiFiEvent);
    Serial.printf("Attempting to connect to WiFi SSID: %s\n", wifi_ssid.c_str());
    WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());

    unsigned long startAttempt = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - startAttempt < 10000) {
      delay(500);
      Serial.print(".");
    }
    Serial.println();
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("✅ Wi-Fi connected!");
    apModeActive = true; // keep AP running for portal as per requirement
  } else {
    Serial.println("❌ Wi-Fi not connected (AP portal active).");
    apModeActive = true;
  }
}

// ================= OTA =================
void setupOTA() {
  ArduinoOTA.setHostname("PumpController_OTA");
  ArduinoOTA.begin();
}

// ================= Setup =================
void setup() {
  Serial.begin(115200);
  pinMode(WIFI_LED_PIN, OUTPUT);
  digitalWrite(WIFI_LED_PIN, LOW);
  pinMode(AUTO_MODE_LED, OUTPUT);
  pinMode(MANUAL_BTN_PIN, INPUT_PULLUP);
  pinMode(BOOT_BTN_PIN, INPUT_PULLUP);

  setupRelay(RELAY1_PIN);
  setupRelay(RELAY2_PIN);

  loadSavedSettings();
  restoreAutoMode();
  connectToWiFiAndStartAP();

  setupOTA();
  setupSinricPro();
}

// ================= Loop =================
void loop() {
  ArduinoOTA.handle();
  SinricPro.handle();
  server.handleClient();
  if (apModeActive) dnsServer.processNextRequest();

  // Manual button long-press -> Stop Pump
  if (digitalRead(MANUAL_BTN_PIN) == LOW) {
    if (!btnPressed) { btnPressed = true; btnPressStart = millis(); }
    else if (millis() - btnPressStart >= HOLD_TIME) {
      Serial.println("Manual button held 5s → Stop Pump");
      pulseRelay(RELAY2_PIN);
      if (WiFi.status() == WL_CONNECTED) {
        SinricProSwitch &sw2 = SinricPro[DEVICE_ID_2];
        sw2.sendPowerStateEvent(true);
        delay(300);
        sw2.sendPowerStateEvent(false);
      }
      btnPressed = false;
      while (digitalRead(MANUAL_BTN_PIN) == LOW) delay(10);
    }
  } else btnPressed = false;

  // Boot button long-press -> Reset WiFi & AP to defaults
  if (digitalRead(BOOT_BTN_PIN) == LOW) {
    if (!bootBtnPressed) { bootBtnPressed = true; bootBtnStart = millis(); }
    else if (millis() - bootBtnStart >= HOLD_TIME) {
      Serial.println("⚠ Boot button held 5s → Clearing WiFi & AP credentials (factory defaults)");
      clearAllCredentials(); // clears wifi & ap namespaces
      delay(500);
      ESP.restart();
    }
  } else bootBtnPressed = false;

  // WiFi reconnect logic (attempt every WIFI_RETRY_MS if disconnected)
  if (WiFi.status() != WL_CONNECTED && millis() - lastReconnectAttempt > WIFI_RETRY_MS) {
    Serial.println("WiFi lost, retrying station connect...");
    // try station connect only if saved credentials exist
    if (wifi_ssid.length() && wifi_pass.length()) {
      WiFi.begin(wifi_ssid.c_str(), wifi_pass.c_str());
    }
    lastReconnectAttempt = millis();
  }

  // SinricPro auto reconnect if WiFi ok
  static unsigned long lastSinricTry = 0;
  if (WiFi.status() == WL_CONNECTED && !SinricPro.isConnected() && millis() - lastSinricTry > 5000) {
    Serial.println("Reconnecting SinricPro...");
    SinricPro.begin(APP_KEY, APP_SECRET);
    lastSinricTry = millis();
  }
}