/**********************************************************************************
 *  TITLE: ESP RainMaker + IR + Switch control Fan Speed using ESP32 (Feedback + no WiFi control + EEPROM)
 *  Click on the following links to learn more. 
 *  YouTube Video: https://youtu.be/O1hGvJiHM0Y
 *  Related Blog : https://iotcircuithub.com/esp32-iot-project-using-alexa-google-home/
 *  
 *  This code is provided free for project purpose and fair use only.
 *  Please do mail us to techstudycell@gmail.com if you want to use it commercially.
 *  Copyrighted © by Tech StudyCell
 *  
 *  Preferences--> Aditional boards Manager URLs : 
 *  http://arduino.esp8266.com/stable/package_esp8266com_index.json,https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
 *  
 *  Download Board ESP32 (2.0.5) : https://github.com/espressif/arduino-esp32
 *
 *  Download the libraries 
 *  IRremote Library (4.5.0): https://github.com/Arduino-IRremote/Arduino-IRremote
 *  AceButton Library (1.10.1): https://github.com/bxparks/AceButton
 **********************************************************************************/

// define the Node Name
char nodeName[] = "ESP32_Fan";

// define the Device Names
char deviceName[] = "Fan";

//Update the HEX code of IR Remote buttons 0x<HEX CODE>
#define IR_Fan_Power  0x6996F300
#define IR_Fan_Up     0x6897F300
#define IR_Fan_Down   0x718EF300
 
#include "RMaker.h"
#include "WiFi.h"
#include "WiFiProv.h"
#include <IRremote.hpp>
#include <Preferences.h>
#include <AceButton.h>
using namespace ace_button;

Preferences pref;

const char *service_name = "PROV_SmartFan";
const char *pop = "TSC123RFV3";


// define the GPIO connected with Relays and switches
static uint8_t FanRelay1 = 5;  //D19
static uint8_t FanRelay2 = 18;  //D18
static uint8_t FanRelay3 = 19;  //D5

static uint8_t FanSwitch1 = 13;  //D13
static uint8_t FanSwitch2 = 12;  //D12
static uint8_t FanSwitch3 = 14;  //D14
static uint8_t FanSwitch4 = 27;  //D27

static uint8_t SwitchPin = 26;  //D26

static uint8_t gpio_reset  = 0 ;   // Press BOOT to reset WiFi Details
static uint8_t wifiLed     = 2 ;   //D2
static uint8_t IR_RECV_PIN = 35;   // D35 (IR receiver pin)

int currSpeed = 0;

// Relay State
bool toggleState = LOW; //Define integer to remember the toggle state for relay 5

bool fanSpeed_0 = LOW;
bool fanSpeed_1 = LOW; 
bool fanSpeed_2 = LOW; 
bool fanSpeed_3 = LOW; 
bool fanSpeed_4 = LOW; 

int wifiFlag = 0;
bool first_run = true;

ButtonConfig config5;
AceButton button5(&config5);

void handleEvent5(AceButton*, uint8_t, uint8_t);

//The framework provides some standard device types like switch, lightbulb, fan, temperature sensor.
static Fan my_fan(deviceName);

void sysProvEvent(arduino_event_t *sys_event)
{
    switch (sys_event->event_id) {      
        case ARDUINO_EVENT_PROV_START:
#if CONFIG_IDF_TARGET_ESP32
        Serial.printf("\nProvisioning Started with name \"%s\" and PoP \"%s\" on BLE\n", service_name, pop);
        printQR(service_name, pop, "ble");
#else
        Serial.printf("\nProvisioning Started with name \"%s\" and PoP \"%s\" on SoftAP\n", service_name, pop);
        printQR(service_name, pop, "softap");
#endif        
        break;
        case ARDUINO_EVENT_WIFI_STA_CONNECTED:
        Serial.printf("\nConnected to Wi-Fi!\n");
        digitalWrite(wifiLed, true);
        break;
    }
}

void write_callback(Device *device, Param *param, const param_val_t val, void *priv_data, write_ctx_t *ctx)
{
  const char *device_name = device->getDeviceName();
  const char *param_name = param->getParamName();
  
     
  if(strcmp(device_name, deviceName) == 0) {
    if (strcmp(param_name, "Power") == 0)
    {
      Serial.printf("Received Fan power = %s for %s - %s\n", val.val.b ? "true" : "false", device_name, param_name);
      toggleState = val.val.b;
      (toggleState == false) ? fanSpeedControl(0) : fanSpeedControl(currSpeed);
      param->updateAndReport(val);
      pref.putBool("Fan_Power", toggleState);
    }  
    if (strcmp(param_name, ESP_RMAKER_DEF_SPEED_NAME) == 0)
    {
      Serial.printf("\nReceived value = %d for %s - %s\n", val.val.i, device_name, param_name);
      currSpeed = val.val.i;
      if(toggleState == 1){
        fanSpeedControl(currSpeed);
      }
      param->updateAndReport(val);
      pref.putInt("Fan_Speed", currSpeed);
    }
 }
}

void ir_remote() {
  if (IrReceiver.decode()) {
    uint32_t irCode = IrReceiver.decodedIRData.decodedRawData;
    Serial.print("IR Code Received: 0x");
    Serial.println(irCode, HEX);

    switch (irCode) {
      case IR_Fan_Power:
        Serial.println("IR: Power Button Pressed");
        if (toggleState == 0) {
          fanSpeedControl(currSpeed); // turn ON
        } else {
          fanSpeedControl(0);         // turn OFF
        }
        toggleState = !toggleState;
        pref.putBool("Fan_Power", toggleState);
        my_fan.updateAndReportParam(ESP_RMAKER_DEF_POWER_NAME, toggleState);
        delay(100);
        break;
      case IR_Fan_Up:
        Serial.println("IR: Fan Speed UP Button Pressed");
        if(currSpeed < 4 && toggleState == 1){
            currSpeed = currSpeed + 1;
            fanSpeedControl(currSpeed);
            pref.putInt("Fan_Speed", currSpeed);
            my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
            delay(100); 
            } 
        else {
          Serial.println("Fan already at maximum speed or OFF");
          }
        break;

      case IR_Fan_Down:
        Serial.println("IR: Fan Speed DOWN Button Pressed");
        if(currSpeed > 0 && toggleState == 1){
              currSpeed = currSpeed - 1;
              fanSpeedControl(currSpeed);
              pref.putInt("Fan_Speed", currSpeed);
              my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
              delay(100); 
            } 
        else {
          Serial.println("Fan already at minimum speed or OFF");
        }
        break;

      default:
        Serial.println("IR: Unknown Button Pressed");
        break;
    }

    IrReceiver.resume();
  }
}

void getRelayState()
{
  currSpeed = pref.getInt("Fan_Speed", 0);
  my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
  delay(200);
  toggleState = pref.getBool("Fan_Power", 0);
  if(toggleState == 1 && currSpeed > 0){
    fanSpeedControl(currSpeed); 
  }  
  my_fan.updateAndReportParam(ESP_RMAKER_DEF_POWER_NAME, toggleState);
  delay(200);
}  

void setup()
{
  Serial.begin(115200);
  //Open namespace in read-write mode
  pref.begin("Relay_State", false);
  
  pinMode(FanRelay1, OUTPUT);
  pinMode(FanRelay2, OUTPUT);
  pinMode(FanRelay3, OUTPUT);

  pinMode(wifiLed, OUTPUT);

  pinMode(SwitchPin, INPUT_PULLUP);
  pinMode(FanSwitch1, INPUT_PULLUP);
  pinMode(FanSwitch2, INPUT_PULLUP);
  pinMode(FanSwitch3, INPUT_PULLUP);
  pinMode(FanSwitch4, INPUT_PULLUP);
  pinMode(gpio_reset, INPUT);

  //During Starting all Relays should TURN OFF
  digitalWrite(FanRelay1, HIGH);
  digitalWrite(FanRelay2, HIGH);
  digitalWrite(FanRelay3, HIGH);

  digitalWrite(wifiLed, LOW);

  config5.setEventHandler(button5Handler);

  button5.init(SwitchPin);

  //irrecv.enableIRIn(); // Enabling IR sensor
  IrReceiver.begin(IR_RECV_PIN);
  Serial.println("IR Receiver started");

  Node my_node;    
  my_node = RMaker.initNode(nodeName);

  
  //Standard switch device
  my_fan.addCb(write_callback);

  //Define Param Fan Speed
  Param speed(ESP_RMAKER_DEF_SPEED_NAME, ESP_RMAKER_PARAM_SPEED, value(0), 
             PROP_FLAG_READ | PROP_FLAG_WRITE);
  speed.addBounds(value(0), value(4), value(1));
  speed.addUIType(ESP_RMAKER_UI_SLIDER);
  my_fan.addParam(speed);

  //Add switch device to the node   
  my_node.addDevice(my_fan); 
  
  delay(1000);

  //This is optional 
  RMaker.enableOTA(OTA_USING_PARAMS);
  //If you want to enable scheduling, set time zone for your region using setTimeZone(). 
  //The list of available values are provided here https://rainmaker.espressif.com/docs/time-service.html
  // RMaker.setTimeZone("Asia/Shanghai");
  // Alternatively, enable the Timezone service and let the phone apps set the appropriate timezone
  RMaker.enableTZService();
  RMaker.enableSchedule();

  Serial.printf("\nStarting ESP-RainMaker\n");
  RMaker.start();

    WiFi.onEvent(sysProvEvent);
#if CONFIG_IDF_TARGET_ESP32
    WiFiProv.beginProvision(WIFI_PROV_SCHEME_BLE, WIFI_PROV_SCHEME_HANDLER_FREE_BTDM, WIFI_PROV_SECURITY_1, pop, service_name);
#else
    WiFiProv.beginProvision(WIFI_PROV_SCHEME_SOFTAP, WIFI_PROV_SCHEME_HANDLER_NONE, WIFI_PROV_SECURITY_1, pop, service_name);
#endif

  delay(200);
  
  getRelayState(); //fetch data from NVS Flash Memory
}

void loop()
{  
  // Read GPIO0 (external button to reset device
  if(digitalRead(gpio_reset) == LOW) { //Push button pressed
    Serial.printf("Reset Button Pressed!\n");
    // Key debounce handling
    delay(100);
    int startTime = millis();
    while(digitalRead(gpio_reset) == LOW) delay(50);
    int endTime = millis();

    if ((endTime - startTime) > 10000) {
      // If key pressed for more than 10secs, reset all
      Serial.printf("Reset to factory.\n");
      RMakerFactoryReset(2);
    } else if ((endTime - startTime) > 3000) {
      Serial.printf("Reset Wi-Fi.\n");
      // If key pressed for more than 3secs, but less than 10, reset Wi-Fi
      RMakerWiFiReset(2);
    }
  }
  delay(100);

  if (WiFi.status() != WL_CONNECTED)
  {
    //Serial.println("WiFi Not Connected");
    digitalWrite(wifiLed, false);
  }
  else
  {
    //Serial.println("WiFi Connected");
    digitalWrite(wifiLed, true);
  }

  //Control Switches Manualy
  button5.check(); 
  
  fanRegularor(); //Control Fan Speed Manualy

  ir_remote(); //IR remote Control
}

void fanRegularor(){
  if (digitalRead(FanSwitch1) == HIGH && digitalRead(FanSwitch2) == HIGH && digitalRead(FanSwitch3) == HIGH && digitalRead(FanSwitch4) == HIGH  && fanSpeed_0 == LOW)
  {
    if(first_run == false){
      currSpeed = 0;
      if(toggleState == 1){
        fanSpeedControl(currSpeed); 
      }
      pref.putInt("Fan_Speed", currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
    }    
    fanSpeed_1 = LOW;
    fanSpeed_2 = LOW;
    fanSpeed_3 = LOW;
    fanSpeed_4 = LOW;
    fanSpeed_0 = HIGH;
  }
  if (digitalRead(FanSwitch1) == LOW && fanSpeed_1 == LOW)
  {
    if(first_run == false){
      currSpeed = 1;
      if(toggleState == 1){
        fanSpeedControl(currSpeed); 
      }
      pref.putInt("Fan_Speed", currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
    }
    fanSpeed_1 = HIGH;
    fanSpeed_2 = LOW;
    fanSpeed_3 = LOW;
    fanSpeed_4 = LOW;
    fanSpeed_0 = LOW;
  }
  if (digitalRead(FanSwitch2) == LOW && digitalRead(FanSwitch3) == HIGH && fanSpeed_2 == LOW)
  {
    if(first_run == false){
      currSpeed = 2;
      if(toggleState == 1){
        fanSpeedControl(currSpeed); 
      }
      pref.putInt("Fan_Speed", currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
    }
    fanSpeed_1 = LOW;
    fanSpeed_2 = HIGH;
    fanSpeed_3 = LOW;
    fanSpeed_4 = LOW;
    fanSpeed_0 = LOW;
  }
  if (digitalRead(FanSwitch2) == LOW && digitalRead(FanSwitch3) == LOW && fanSpeed_3 == LOW)
  {
    if(first_run == false){
      currSpeed = 3;
      if(toggleState == 1){
        fanSpeedControl(currSpeed); 
      }
      pref.putInt("Fan_Speed", currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
    }
    fanSpeed_1 = LOW;
    fanSpeed_2 = LOW;
    fanSpeed_3 = HIGH;
    fanSpeed_4 = LOW;
    fanSpeed_0 = LOW;
  }
  if (digitalRead(FanSwitch4) == LOW  && fanSpeed_4 == LOW)
  {
    if(first_run == false){
      currSpeed = 4;
      if(toggleState == 1){
        fanSpeedControl(currSpeed); 
      }
      pref.putInt("Fan_Speed", currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
    }
    fanSpeed_1 = LOW;
    fanSpeed_2 = LOW;
    fanSpeed_3 = LOW;
    fanSpeed_4 = HIGH;
    fanSpeed_0 = LOW;
  }
  first_run = false;
}

void fanSpeedControl(int fanSpeed){
   switch(fanSpeed){
    case 0:
      digitalWrite(FanRelay1, HIGH);
      digitalWrite(FanRelay2, HIGH);
      digitalWrite(FanRelay3, HIGH);        
    break;
    case 1:
      digitalWrite(FanRelay1, HIGH);
      digitalWrite(FanRelay2, HIGH);
      digitalWrite(FanRelay3, HIGH);
      delay(500);
      digitalWrite(FanRelay1, LOW);
    break;
    case 2:
      digitalWrite(FanRelay1, HIGH);
      digitalWrite(FanRelay2, HIGH);
      digitalWrite(FanRelay3, HIGH);
      delay(500);
      digitalWrite(FanRelay2, LOW);
    break;
    case 3:
      digitalWrite(FanRelay1, HIGH);
      digitalWrite(FanRelay2, HIGH);
      digitalWrite(FanRelay3, HIGH);
      delay(500);
      digitalWrite(FanRelay1, LOW);
      digitalWrite(FanRelay2, LOW);
    break;
    case 4:
      digitalWrite(FanRelay1, HIGH);
      digitalWrite(FanRelay2, HIGH);
      digitalWrite(FanRelay3, HIGH);
      delay(500);
      digitalWrite(FanRelay3, LOW);
    break;          
    default : break;         
   } 
}

void button5Handler(AceButton* button, uint8_t eventType, uint8_t buttonState) {
  Serial.println("EVENT1");
  switch (eventType) {
    case AceButton::kEventPressed:
      Serial.println("kEventPressed");
      toggleState = 1;
      fanSpeedControl(currSpeed);
      pref.putBool("Fan_Power", toggleState);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_POWER_NAME, toggleState);
      break;
    case AceButton::kEventReleased:
      Serial.println("kEventReleased");
      toggleState = 0;
      fanSpeedControl(0);
      pref.putBool("Fan_Power", toggleState);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_SPEED_NAME, currSpeed);
      my_fan.updateAndReportParam(ESP_RMAKER_DEF_POWER_NAME, toggleState); 
      break;
  }
}
